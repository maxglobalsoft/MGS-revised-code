/**
 * MGS — MongoDB → PostgreSQL Migration Script
 * ─────────────────────────────────────────────
 * Run ONCE after setting up the new Express backend.
 * Copies all data from the old MongoDB to PostgreSQL via Prisma.
 *
 * Usage:
 *   1. Make sure .env has both DATABASE_URL (PostgreSQL) and MONGO_URL + MONGO_DB_NAME
 *   2. Run: npx ts-node migrate-from-mongo.ts
 *
 * Safe to re-run: uses upsert everywhere — will not duplicate data.
 */

import 'dotenv/config';
import { MongoClient } from 'mongodb';
import { PrismaClient, Role } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

const MONGO_URL    = process.env.MONGO_URL    ?? '';
const MONGO_DB     = process.env.MONGO_DB_NAME ?? process.env.DB_NAME ?? 'mgs_db';

// All generic collections that map to the collection_items table
const GENERIC_COLLECTIONS = [
  'services',
  'industries',
  'portfolioCategories',
  'portfolioItems',
  'caseStudies',
  'caseStudyCategories',
  'valuesItems',
  'technologies',
  'testimonials',
  'clients',
  'teamMembers',
  'jobs',
  'reviews',
  'serviceCards',
  'serviceIndustries',
  'recentProjects',
  'whyMgsBlocks',
  'certifications',
];

function mapRole(role: string): Role {
  if (role === 'super_admin') return Role.SUPER_ADMIN;
  if (role === 'SUPER_ADMIN') return Role.SUPER_ADMIN;
  return Role.EDITOR;
}

function cleanDoc(doc: Record<string, unknown>): Record<string, unknown> {
  // Remove MongoDB internal fields
  const { _id, __v, ...rest } = doc as any;
  return rest;
}

async function main() {
  if (!MONGO_URL) {
    console.error('❌  MONGO_URL not set in .env — aborting.');
    process.exit(1);
  }

  console.log('🔗  Connecting to MongoDB…');
  const mongoClient = new MongoClient(MONGO_URL);
  await mongoClient.connect();
  const db = mongoClient.db(MONGO_DB);
  console.log(`✅  Connected to MongoDB database: ${MONGO_DB}`);

  // ── 1. USERS ───────────────────────────────────────────────────────────────
  console.log('\n📦  Migrating users…');
  const users = await db.collection('users').find({}).toArray();
  let userCount = 0;
  for (const u of users) {
    // Password may already be hashed (bcrypt) or plain — detect by $ prefix
    const passwordHash = (u.password_hash ?? u.hashed_password ?? u.password ?? '');
    const isHashed = typeof passwordHash === 'string' && passwordHash.startsWith('$2');
    const finalHash = isHashed ? passwordHash : await bcrypt.hash(passwordHash || 'ChangeMe@2026', 12);

    await prisma.user.upsert({
      where: { email: u.email },
      update: { name: u.name ?? null, role: mapRole(u.role ?? 'editor') },
      create: {
        id:           u.id ?? u._id?.toString(),
        email:        u.email,
        passwordHash: finalHash,
        name:         u.name ?? null,
        role:         mapRole(u.role ?? 'editor'),
      },
    });
    userCount++;
  }
  console.log(`   ✅  ${userCount} users migrated`);

  // ── 2. SETTINGS ────────────────────────────────────────────────────────────
  console.log('\n📦  Migrating settings…');
  const settings = await db.collection('settings').findOne({});
  if (settings) {
    const data = cleanDoc(settings as any);
    await prisma.settings.upsert({
      where:  { id: 1 },
      update: { data },
      create: { id: 1, data },
    });
    console.log('   ✅  Settings migrated');
  } else {
    console.log('   ⚠️   No settings document found — skipping');
  }

  // ── 3. SECTIONS ────────────────────────────────────────────────────────────
  console.log('\n📦  Migrating sections…');
  const sections = await db.collection('sections').find({}).toArray();
  let sectionCount = 0;
  for (const s of sections) {
    const key  = s.key as string;
    const data = cleanDoc(s as any);
    await prisma.section.upsert({
      where:  { key },
      update: { data },
      create: { key, data },
    });
    sectionCount++;
  }
  console.log(`   ✅  ${sectionCount} sections migrated`);

  // ── 4. PAGE META ───────────────────────────────────────────────────────────
  console.log('\n📦  Migrating page meta…');
  const pageMetas = await db.collection('pageMeta').find({}).toArray();
  let metaCount = 0;
  for (const m of pageMetas) {
    const slug = m.slug as string;
    const data = cleanDoc(m as any);
    await prisma.pageMeta.upsert({
      where:  { slug },
      update: { data },
      create: { slug, data },
    });
    metaCount++;
  }
  console.log(`   ✅  ${metaCount} page meta records migrated`);

  // ── 5. STATIC PAGES ────────────────────────────────────────────────────────
  console.log('\n📦  Migrating static pages…');
  const pages = await db.collection('pages').find({}).toArray();
  let pageCount = 0;
  for (const pg of pages) {
    await prisma.page.upsert({
      where:  { slug: pg.slug },
      update: {
        title:           pg.title ?? '',
        body:            pg.body ?? pg.content ?? '',
        metaTitle:       pg.meta_title ?? pg.metaTitle ?? null,
        metaDescription: pg.meta_description ?? pg.metaDescription ?? null,
        visible:         pg.visible !== false,
        order:           pg.order ?? 0,
      },
      create: {
        id:              pg.id ?? pg._id?.toString(),
        slug:            pg.slug,
        title:           pg.title ?? '',
        body:            pg.body ?? pg.content ?? '',
        metaTitle:       pg.meta_title ?? pg.metaTitle ?? null,
        metaDescription: pg.meta_description ?? pg.metaDescription ?? null,
        visible:         pg.visible !== false,
        order:           pg.order ?? 0,
      },
    });
    pageCount++;
  }
  console.log(`   ✅  ${pageCount} static pages migrated`);

  // ── 6. GENERIC COLLECTIONS → collection_items ──────────────────────────────
  console.log('\n📦  Migrating generic collections…');
  let collectionItemCount = 0;
  for (const collName of GENERIC_COLLECTIONS) {
    const docs = await db.collection(collName).find({}).toArray();
    if (docs.length === 0) {
      console.log(`   ⚠️   ${collName}: empty — skipping`);
      continue;
    }
    for (const doc of docs) {
      const id   = (doc.id ?? doc._id?.toString()) as string;
      const slug = (doc.slug ?? null) as string | null;
      const data = cleanDoc(doc as any);
      await prisma.collectionItem.upsert({
        where:  { id },
        update: {
          collection: collName,
          slug,
          data,
          order:   doc.order ?? 0,
          visible: doc.visible !== false,
        },
        create: {
          id,
          collection: collName,
          slug,
          data,
          order:   doc.order ?? 0,
          visible: doc.visible !== false,
        },
      });
      collectionItemCount++;
    }
    console.log(`   ✅  ${collName}: ${docs.length} items`);
  }
  console.log(`   ✅  Total collection items: ${collectionItemCount}`);

  // ── 7. CONTACT SUBMISSIONS ─────────────────────────────────────────────────
  console.log('\n📦  Migrating contact submissions…');
  const contacts = await db.collection('contactSubmissions').find({}).toArray();
  let contactCount = 0;
  for (const c of contacts) {
    const id = (c.id ?? c._id?.toString()) as string;
    try {
      await prisma.contactSubmission.upsert({
        where:  { id },
        update: {},
        create: {
          id,
          name:      c.name ?? '',
          email:     c.email ?? '',
          phone:     c.phone ?? c.mobile ?? null,
          company:   c.company ?? c.country ?? null,
          message:   c.message ?? c.brief ?? '',
          createdAt: c.submitted_at ? new Date(c.submitted_at) : new Date(),
        },
      });
      contactCount++;
    } catch { /* skip duplicates */ }
  }
  console.log(`   ✅  ${contactCount} contact submissions migrated`);

  // ── 8. JOB APPLICATIONS ────────────────────────────────────────────────────
  console.log('\n📦  Migrating job applications…');
  const applications = await db.collection('applications').find({}).toArray();
  let appCount = 0;
  for (const a of applications) {
    const id = (a.id ?? a._id?.toString()) as string;
    try {
      await prisma.application.upsert({
        where:  { id },
        update: {},
        create: {
          id,
          jobTitle:   a.jobTitle ?? a.job_title ?? null,
          name:       a.name ?? '',
          mobile:     a.mobile ?? a.phone ?? null,
          email:      a.email ?? '',
          experience: a.experience ?? null,
          message:    a.message ?? null,
          resumeUrl:  a.resumeUrl ?? a.resume_url ?? null,
          resumeName: a.resumeName ?? a.resume_name ?? null,
          createdAt:  a.createdAt ? new Date(a.createdAt) : new Date(),
        },
      });
      appCount++;
    } catch { /* skip duplicates */ }
  }
  console.log(`   ✅  ${appCount} applications migrated`);

  // ── 9. MEDIA ───────────────────────────────────────────────────────────────
  console.log('\n📦  Migrating media records…');
  const mediaItems = await db.collection('media').find({}).toArray();
  let mediaCount = 0;
  for (const m of mediaItems) {
    const id = (m.id ?? m._id?.toString()) as string;
    try {
      await prisma.media.upsert({
        where:  { id },
        update: {},
        create: {
          id,
          url:       m.url ?? '',
          publicId:  m.public_id ?? m.publicId ?? '',
          filename:  m.filename ?? m.original_filename ?? 'file',
          mimetype:  m.mimetype ?? m.resource_type ?? null,
          size:      m.size ? Number(m.size) : null,
          folder:    m.folder ?? null,
          createdAt: m.createdAt ? new Date(m.createdAt) : new Date(),
        },
      });
      mediaCount++;
    } catch { /* skip duplicates */ }
  }
  console.log(`   ✅  ${mediaCount} media records migrated`);

  // ── DONE ───────────────────────────────────────────────────────────────────
  console.log('\n🎉  Migration complete!');
  console.log(`
Summary:
  Users:               ${userCount}
  Settings:            1
  Sections:            ${sectionCount}
  Page Meta:           ${metaCount}
  Static Pages:        ${pageCount}
  Collection Items:    ${collectionItemCount}
  Contact Submissions: ${contactCount}
  Applications:        ${appCount}
  Media:               ${mediaCount}

Next steps:
  1. Run: npm run dev   → verify the Express API is serving data correctly
  2. Test: curl http://localhost:8000/api/v1/site
  3. Deploy backend to api.maxglobalsoft.com
  4. Build and deploy frontend to client.maxglobalsoft.com
`);

  await mongoClient.close();
  await prisma.$disconnect();
}

main().catch((err) => {
  console.error('❌  Migration failed:', err);
  prisma.$disconnect();
  process.exit(1);
});
