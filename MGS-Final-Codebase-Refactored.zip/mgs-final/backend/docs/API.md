# MGS — API Documentation
**Base URL:** `https://api.maxglobalsoft.com/api/v1`
**Auth:** JWT via httpOnly cookie `access_token` OR `Authorization: Bearer <token>`

---

## Auth

| Method | Endpoint | Auth | Body | Description |
|--------|----------|------|------|-------------|
| POST | `/auth/login` | — | `{email, password}` | Login, returns token + sets cookie |
| POST | `/auth/logout` | — | — | Clears cookie |
| GET | `/auth/me` | ✅ | — | Current user info |
| POST | `/auth/refresh` | — | — | Refresh token |

---

## Public Reads

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/site` | All sections + settings + nav (SiteContext) |
| GET | `/settings` | Site settings |
| GET | `/sections` | All sections |
| GET | `/sections/:key` | Single section |
| GET | `/page/:slug` | Composite page data (sections + collections + meta) |
| GET | `/page-meta/:slug` | SEO metadata for a slug |
| GET | `/pages/:slug` | Static CMS page content |
| GET | `/collections/:collection` | Public list of a collection |
| GET | `/case-studies/:slug` | Case study by slug |
| GET | `/portfolio/:slug` | Portfolio item by slug |
| GET | `/search?q=` | Full-text search |
| POST | `/contact` | Submit contact form |
| POST | `/apply` | Submit job application (multipart/form-data) |
| GET | `/sitemap.xml` | Dynamic sitemap |
| GET | `/robots.txt` | Robots file |

---

## Admin — Collections (Editor+)

All generic collections: `services, industries, portfolioCategories, portfolioItems, caseStudies, valuesItems, technologies, reviews, clients, teamMembers, jobs`

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/admin/collections/:collection` | List all items |
| POST | `/admin/collections/:collection` | Create item |
| PUT | `/admin/collections/:collection/reorder` | Reorder `{ids: string[]}` |
| PUT | `/admin/collections/:collection/:id` | Update item |
| DELETE | `/admin/collections/:collection/:id` | Delete item |

---

## Admin — CMS (Editor+)

| Method | Endpoint | Description |
|--------|----------|-------------|
| PUT | `/admin/sections/:key` | Update section content |
| PUT | `/admin/page-meta/:slug` | Update SEO meta |
| GET | `/admin/pages` | List static pages |
| POST | `/admin/pages` | Create static page |
| PUT | `/admin/pages/:id` | Update static page |
| DELETE | `/admin/pages/:id` | Delete static page |

---

## Admin — Settings (Super Admin only)

| Method | Endpoint | Description |
|--------|----------|-------------|
| PUT | `/admin/settings` | Update site settings |

---

## Admin — Media (Editor+)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/admin/media` | List all media |
| POST | `/admin/media/upload` | Upload file to Cloudinary (multipart) |
| DELETE | `/admin/media/:id` | Delete from Cloudinary + DB |

---

## Admin — Inboxes (Super Admin only)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/admin/contact-submissions` | List contact submissions |
| DELETE | `/admin/contact-submissions/:id` | Delete submission |
| GET | `/admin/applications` | List job applications |
| DELETE | `/admin/applications/:id` | Delete application |

---

## Admin — Users (Super Admin only)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/admin/users` | List users |
| POST | `/admin/users` | Create user `{email, password, name?, role?}` |
| PUT | `/admin/users/:id` | Update user `{name?, role?, password?}` |
| DELETE | `/admin/users/:id` | Delete user |

---

## Response format

```json
{ "success": true, "data": { ... } }
{ "success": false, "error": "message" }
```

## Roles

| Role | Permissions |
|------|-------------|
| `SUPER_ADMIN` | Everything |
| `EDITOR` | Collections, Sections, Pages, Media, PageMeta. No: Settings, Users, Inboxes. |
