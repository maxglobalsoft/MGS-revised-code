import { Response } from 'express';
import { z } from 'zod';
import { Role, AuthRequest } from '../types';
import prisma from '../config/prisma';
import { hashPassword } from '../utils/password';

const CREATE_SCHEMA = z.object({
  email:    z.string().email(),
  password: z.string().min(8),
  name:     z.string().optional(),
  role:     z.enum(['SUPER_ADMIN', 'EDITOR']).default('EDITOR'),
});

const UPDATE_SCHEMA = z.object({
  name:     z.string().optional(),
  role:     z.enum(['SUPER_ADMIN', 'EDITOR']).optional(),
  password: z.string().min(8).optional(),
});

const SELECT = { id: true, email: true, role: true, name: true, createdAt: true, updatedAt: true };

// GET /api/v1/admin/users
export async function listUsers(_req: AuthRequest, res: Response): Promise<void> {
  const users = await prisma.user.findMany({ select: SELECT, orderBy: { createdAt: 'asc' } });
  res.json({ success: true, data: users });
}

// POST /api/v1/admin/users
export async function createUser(req: AuthRequest, res: Response): Promise<void> {
  const body = CREATE_SCHEMA.parse(req.body);
  const passwordHash = await hashPassword(body.password);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const user = await prisma.user.create({ data: { email: body.email, passwordHash, name: body.name ?? null, role: body.role as any }, select: SELECT });
  res.status(201).json({ success: true, data: user });
}

// PUT /api/v1/admin/users/:id
export async function updateUser(req: AuthRequest, res: Response): Promise<void> {
  const body = UPDATE_SCHEMA.parse(req.body);

  if (req.params['id'] === req.user!.id && body.role && body.role !== Role.SUPER_ADMIN) {
    res.status(400).json({ success: false, error: 'Cannot change your own role' });
    return;
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const data: Record<string, any> = {};
  if (body.name !== undefined) data['name'] = body.name;
  if (body.role !== undefined) data['role'] = body.role;
  if (body.password)           data['passwordHash'] = await hashPassword(body.password);

  const user = await prisma.user.update({ where: { id: req.params['id'] }, data, select: SELECT });
  res.json({ success: true, data: user });
}

// DELETE /api/v1/admin/users/:id
export async function deleteUser(req: AuthRequest, res: Response): Promise<void> {
  if (req.params['id'] === req.user!.id) {
    res.status(400).json({ success: false, error: 'Cannot delete your own account' });
    return;
  }
  await prisma.user.delete({ where: { id: req.params['id'] } });
  res.json({ success: true, message: 'Deleted' });
}
