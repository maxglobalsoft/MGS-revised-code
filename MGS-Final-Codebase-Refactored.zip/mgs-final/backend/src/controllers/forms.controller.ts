import { Request, Response } from 'express';
import { z } from 'zod';
import prisma from '../config/prisma';
import { AuthRequest } from '../types';

// ─────────────────────────────────────────────────────────────
// CONTACT SUBMISSIONS
// ─────────────────────────────────────────────────────────────

const ContactSchema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
  phone: z.string().optional(),
  company: z.string().optional(),
  message: z.string().min(1),
});

// POST /api/v1/contact (public)
export async function submitContact(req: Request, res: Response): Promise<void> {
  const body = ContactSchema.parse(req.body);
  await prisma.contactSubmission.create({ data: body });
  res.status(201).json({ success: true, message: 'Message received. We will be in touch!' });
}

// GET /api/v1/admin/contact-submissions (super_admin only)
export async function listContactSubmissions(_req: AuthRequest, res: Response): Promise<void> {
  const submissions = await prisma.contactSubmission.findMany({
    orderBy: { createdAt: 'desc' },
  });
  res.json({ success: true, data: submissions });
}

// DELETE /api/v1/admin/contact-submissions/:id (super_admin only)
export async function deleteContactSubmission(req: AuthRequest, res: Response): Promise<void> {
  const sub = await prisma.contactSubmission.findUnique({ where: { id: req.params.id } });
  if (!sub) { res.status(404).json({ success: false, error: 'Submission not found' }); return; }
  await prisma.contactSubmission.delete({ where: { id: sub.id } });
  res.json({ success: true, message: 'Deleted' });
}

// ─────────────────────────────────────────────────────────────
// JOB APPLICATIONS
// ─────────────────────────────────────────────────────────────

const ApplicationSchema = z.object({
  jobTitle: z.string().optional(),
  name: z.string().min(1),
  mobile: z.string().optional(),
  email: z.string().email(),
  experience: z.string().optional(),
  message: z.string().optional(),
  resumeUrl: z.string().url().optional(),
  resumeName: z.string().optional(),
});

// POST /api/v1/apply (public — multipart handled in route via multer + uploadResume)
// This controller handles the non-file fields after the resume has been uploaded
export async function submitApplication(req: Request, res: Response): Promise<void> {
  const body = ApplicationSchema.parse(req.body);
  await prisma.application.create({ data: body });
  res.status(201).json({
    success: true,
    message: 'Application received. We will review and get back to you.',
  });
}

// GET /api/v1/admin/applications (super_admin only)
export async function listApplications(_req: AuthRequest, res: Response): Promise<void> {
  const applications = await prisma.application.findMany({
    orderBy: { createdAt: 'desc' },
  });
  res.json({ success: true, data: applications });
}

// DELETE /api/v1/admin/applications/:id (super_admin only)
export async function deleteApplication(req: AuthRequest, res: Response): Promise<void> {
  const app = await prisma.application.findUnique({ where: { id: req.params.id } });
  if (!app) { res.status(404).json({ success: false, error: 'Application not found' }); return; }
  await prisma.application.delete({ where: { id: app.id } });
  res.json({ success: true, message: 'Deleted' });
}
