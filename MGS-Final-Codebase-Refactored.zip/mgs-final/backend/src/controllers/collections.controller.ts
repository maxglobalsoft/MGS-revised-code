import { Response } from 'express';
import { z } from 'zod';
import prisma from '../config/prisma';
import { AuthRequest, ALLOWED_COLLECTIONS, CollectionName } from '../types';

// ── Helpers ───────────────────────────────────────────────────

function assertAllowed(collection: string, res: Response): collection is CollectionName {
  if (!ALLOWED_COLLECTIONS.includes(collection as CollectionName)) {
    res.status(400).json({ success: false, error: `Unknown collection: ${collection}` });
    return false;
  }
  return true;
}

// Format a CollectionItem for the response — mirrors the original MongoDB doc shape
function format(item: { id: string; collection: string; slug: string | null; data: unknown; order: number; visible: boolean; createdAt: Date; updatedAt: Date }) {
  const data = (item.data ?? {}) as Record<string, unknown>;
  return {
    _id: item.id,
    id: item.id,
    ...data,
    slug: item.slug ?? data['slug'],
    order: item.order,
    visible: item.visible,
    createdAt: item.createdAt,
    updatedAt: item.updatedAt,
  };
}

const ReorderSchema = z.object({ ids: z.array(z.string()) });

// ── Controllers ───────────────────────────────────────────────

// GET /api/v1/collections/:collection
export async function listItems(req: AuthRequest, res: Response): Promise<void> {
  const { collection } = req.params;
  if (!assertAllowed(collection, res)) return;

  const isAdmin = !!req.user;
  const items = await prisma.collectionItem.findMany({
    where: { collection, ...(isAdmin ? {} : { visible: true }) },
    orderBy: { order: 'asc' },
  });

  res.json({ success: true, data: items.map(format) });
}

// GET /api/v1/collections/:collection/:id
export async function getItem(req: AuthRequest, res: Response): Promise<void> {
  const { collection, id } = req.params;
  if (!assertAllowed(collection, res)) return;

  // Allow lookup by id OR slug
  const item = await prisma.collectionItem.findFirst({
    where: { collection, OR: [{ id }, { slug: id }] },
  });

  if (!item) { res.status(404).json({ success: false, error: 'Item not found' }); return; }
  res.json({ success: true, data: format(item) });
}

// POST /api/v1/admin/collections/:collection
export async function createItem(req: AuthRequest, res: Response): Promise<void> {
  const { collection } = req.params;
  if (!assertAllowed(collection, res)) return;

  const body = req.body as Record<string, unknown>;
  const slug = (body['slug'] as string | undefined) ?? null;

  // Find the next order value
  const maxOrder = await prisma.collectionItem.aggregate({
    _max: { order: true },
    where: { collection },
  });
  const order = typeof body['order'] === 'number' ? body['order'] : (maxOrder._max.order ?? -1) + 1;

  const item = await prisma.collectionItem.create({
    data: {
      collection,
      slug,
      data: body,
      order: order as number,
      visible: body['visible'] !== false,
    },
  });

  res.status(201).json({ success: true, data: format(item) });
}

// PUT /api/v1/admin/collections/:collection/:id
export async function updateItem(req: AuthRequest, res: Response): Promise<void> {
  const { collection, id } = req.params;
  if (!assertAllowed(collection, res)) return;

  const body = req.body as Record<string, unknown>;
  const slug = (body['slug'] as string | undefined) ?? undefined;

  const existing = await prisma.collectionItem.findFirst({
    where: { collection, id },
  });
  if (!existing) { res.status(404).json({ success: false, error: 'Item not found' }); return; }

  const item = await prisma.collectionItem.update({
    where: { id: existing.id },
    data: {
      slug: slug ?? existing.slug,
      data: body,
      order: typeof body['order'] === 'number' ? body['order'] : existing.order,
      visible: body['visible'] !== undefined ? body['visible'] as boolean : existing.visible,
    },
  });

  res.json({ success: true, data: format(item) });
}

// DELETE /api/v1/admin/collections/:collection/:id
export async function deleteItem(req: AuthRequest, res: Response): Promise<void> {
  const { collection, id } = req.params;
  if (!assertAllowed(collection, res)) return;

  const existing = await prisma.collectionItem.findFirst({ where: { collection, id } });
  if (!existing) { res.status(404).json({ success: false, error: 'Item not found' }); return; }

  await prisma.collectionItem.delete({ where: { id: existing.id } });
  res.json({ success: true, message: 'Deleted' });
}

// PUT /api/v1/admin/collections/:collection/reorder
export async function reorderItems(req: AuthRequest, res: Response): Promise<void> {
  const { collection } = req.params;
  if (!assertAllowed(collection, res)) return;

  const { ids } = ReorderSchema.parse(req.body);

  await prisma.$transaction(
    ids.map((id, index) =>
      prisma.collectionItem.updateMany({
        where: { id, collection },
        data: { order: index },
      })
    )
  );

  res.json({ success: true, message: 'Reordered' });
}
