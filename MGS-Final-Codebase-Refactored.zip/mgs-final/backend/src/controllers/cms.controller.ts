import { Request, Response } from 'express';
import { z } from 'zod';
import prisma from '../config/prisma';
import { AuthRequest } from '../types';

// ─────────────────────────────────────────────────────────────
// SECTIONS
// ─────────────────────────────────────────────────────────────

// GET /api/v1/sections
export async function getAllSections(_req: Request, res: Response): Promise<void> {
  const sections = await prisma.section.findMany();
  const result: Record<string, unknown> = {};
  sections.forEach((s: { key: string; data: unknown }) => { result[s.key] = s.data; });
  res.json({ success: true, data: result });
}

// GET /api/v1/sections/:key
export async function getSectionByKey(req: Request, res: Response): Promise<void> {
  const section = await prisma.section.findUnique({ where: { key: req.params.key } });
  if (!section) { res.status(404).json({ success: false, error: 'Section not found' }); return; }
  res.json({ success: true, data: section.data });
}

// PUT /api/v1/admin/sections/:key
export async function updateSection(req: AuthRequest, res: Response): Promise<void> {
  const section = await prisma.section.upsert({
    where: { key: req.params.key },
    update: { data: req.body },
    create: { key: req.params.key, data: req.body },
  });
  res.json({ success: true, data: section.data });
}

// ─────────────────────────────────────────────────────────────
// SETTINGS
// ─────────────────────────────────────────────────────────────

// GET /api/v1/settings
export async function getSettings(_req: Request, res: Response): Promise<void> {
  const settings = await prisma.settings.findUnique({ where: { id: 1 } });
  res.json({ success: true, data: settings?.data ?? {} });
}

// PUT /api/v1/admin/settings
export async function updateSettings(req: AuthRequest, res: Response): Promise<void> {
  const settings = await prisma.settings.upsert({
    where: { id: 1 },
    update: { data: req.body },
    create: { id: 1, data: req.body },
  });
  res.json({ success: true, data: settings.data });
}

// ─────────────────────────────────────────────────────────────
// PAGE META (SEO)
// ─────────────────────────────────────────────────────────────

// GET /api/v1/page-meta/:slug
export async function getPageMeta(req: Request, res: Response): Promise<void> {
  const meta = await prisma.pageMeta.findUnique({ where: { slug: req.params.slug } });
  res.json({ success: true, data: meta?.data ?? {} });
}

// PUT /api/v1/admin/page-meta/:slug
export async function updatePageMeta(req: AuthRequest, res: Response): Promise<void> {
  const meta = await prisma.pageMeta.upsert({
    where: { slug: req.params.slug },
    update: { data: req.body },
    create: { slug: req.params.slug, data: req.body },
  });
  res.json({ success: true, data: meta.data });
}

// ─────────────────────────────────────────────────────────────
// STATIC PAGES CMS
// ─────────────────────────────────────────────────────────────

// GET /api/v1/pages/:slug (public)
export async function getPageBySlug(req: Request, res: Response): Promise<void> {
  const page = await prisma.page.findFirst({
    where: { slug: req.params.slug, visible: true },
  });
  if (!page) { res.status(404).json({ success: false, error: 'Page not found' }); return; }
  res.json({ success: true, data: page });
}

// GET /api/v1/admin/pages (admin)
export async function listPages(_req: Request, res: Response): Promise<void> {
  const pages = await prisma.page.findMany({ orderBy: { order: 'asc' } });
  res.json({ success: true, data: pages });
}

// POST /api/v1/admin/pages
const PageSchema = z.object({
  slug: z.string().min(1).regex(/^[a-z0-9-]+$/),
  title: z.string().min(1),
  body: z.string().default(''),
  metaTitle: z.string().optional(),
  metaDescription: z.string().optional(),
  visible: z.boolean().default(true),
  order: z.number().default(0),
});

export async function createPage(req: AuthRequest, res: Response): Promise<void> {
  const body = PageSchema.parse(req.body);
  const page = await prisma.page.create({ data: body });
  res.status(201).json({ success: true, data: page });
}

// PUT /api/v1/admin/pages/:id
export async function updatePage(req: AuthRequest, res: Response): Promise<void> {
  const body = PageSchema.partial().parse(req.body);
  const page = await prisma.page.update({ where: { id: req.params.id }, data: body });
  res.json({ success: true, data: page });
}

// DELETE /api/v1/admin/pages/:id
export async function deletePage(req: AuthRequest, res: Response): Promise<void> {
  await prisma.page.delete({ where: { id: req.params.id } });
  res.json({ success: true, message: 'Deleted' });
}

// ─────────────────────────────────────────────────────────────
// SITE COMPOSITE ENDPOINT
// ─────────────────────────────────────────────────────────────

// GET /api/v1/site — returns all sections + settings + nav in one call (used by frontend SiteContext)
export async function getSite(_req: Request, res: Response): Promise<void> {
  const [sectionsArr, settings] = await Promise.all([
    prisma.section.findMany(),
    prisma.settings.findUnique({ where: { id: 1 } }),
  ]);

  const sections: Record<string, unknown> = {};
  sectionsArr.forEach((s: { key: string; data: unknown }) => { sections[s.key] = s.data; });

  const settingsData = (settings?.data ?? {}) as Record<string, unknown>;

  res.json({
    success: true,
    data: {
      sections,
      settings: settingsData,
      nav_links: settingsData['nav_links'] ?? [],
      footer_columns: settingsData['footer_columns'] ?? [],
    },
  });
}

// GET /api/v1/page/:slug — composite page data (sections + collections for a specific page)
export async function getPageData(req: Request, res: Response): Promise<void> {
  const { slug } = req.params;

  const [sectionsArr, settings, meta, collections] = await Promise.all([
    prisma.section.findMany(),
    prisma.settings.findUnique({ where: { id: 1 } }),
    prisma.pageMeta.findUnique({ where: { slug } }),
    // All visible collection items — frontend assembles what it needs
    prisma.collectionItem.findMany({ where: { visible: true }, orderBy: { order: 'asc' } }),
  ]);

  const sections: Record<string, unknown> = {};
  sectionsArr.forEach((s: { key: string; data: unknown }) => { sections[s.key] = s.data; });

  // Group collections by name
  const groupedCollections: Record<string, unknown[]> = {};
  collections.forEach((item: { collection: string; id: string; slug: string | null; data: unknown; order: number }) => {
    if (!groupedCollections[item.collection]) groupedCollections[item.collection] = [];
    const data = (item.data ?? {}) as Record<string, unknown>;
    groupedCollections[item.collection]!.push({
      _id: item.id, id: item.id, ...data, slug: item.slug ?? data['slug'], order: item.order,
    });
  });

  res.json({
    success: true,
    data: {
      sections,
      settings: settings?.data ?? {},
      collections: groupedCollections,
      meta: meta?.data ?? {},
    },
  });
}
