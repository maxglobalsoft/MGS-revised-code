import { Request, Response } from 'express';
import prisma from '../config/prisma';
import { generateSitemap } from '../utils/sitemap';

// GET /sitemap.xml
export async function getSitemap(_req: Request, res: Response): Promise<void> {
  const xml = await generateSitemap();
  res.setHeader('Content-Type', 'application/xml');
  res.setHeader('Cache-Control', 'public, max-age=3600');
  res.send(xml);
}

// GET /robots.txt
export async function getRobots(_req: Request, res: Response): Promise<void> {
  const base = process.env.PUBLIC_SITE_URL ?? 'https://www.maxglobalsoft.com';
  const txt = [
    'User-agent: *',
    'Allow: /',
    'Disallow: /admin',
    '',
    `Sitemap: ${base}/sitemap.xml`,
  ].join('\n');
  res.setHeader('Content-Type', 'text/plain');
  res.send(txt);
}

// GET /api/v1/search?q=...
export async function search(req: Request, res: Response): Promise<void> {
  const query = String(req.query['q'] ?? '').trim().toLowerCase();
  if (!query || query.length < 2) {
    res.json({ success: true, data: [] });
    return;
  }

  // Search across collections — filter on JSONB fields using Prisma raw or string contains
  const allItems = await prisma.collectionItem.findMany({
    where: {
      visible: true,
      OR: [
        { slug: { contains: query, mode: 'insensitive' } },
      ],
    },
    take: 20,
  });

  // Secondary: filter on data fields in application layer (PostgreSQL JSONB text search)
  const filtered = allItems.filter((item: { data: unknown }) => {
    const str = JSON.stringify(item.data).toLowerCase();
    return str.includes(query);
  });

  res.json({ success: true, data: filtered.slice(0, 10).map((i: { id: string; collection: string; slug: string | null; data: unknown }) => ({
    id: i.id,
    collection: i.collection,
    slug: i.slug,
    data: i.data,
  }))});
}
