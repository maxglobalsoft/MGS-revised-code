import { Request, Response } from 'express';
import { z } from 'zod';
import prisma from '../config/prisma';
import { verifyPassword } from '../utils/password';
import { signToken, extractTokenFromRequest, verifyToken } from '../utils/jwt';
import { AuthRequest } from '../types';

// ── Validations ───────────────────────────────────────────────

const LoginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

// ── Helpers ───────────────────────────────────────────────────

const COOKIE_OPTIONS = {
  httpOnly: true,
  secure: process.env.NODE_ENV === 'production',
  sameSite: (process.env.NODE_ENV === 'production' ? 'strict' : 'lax') as 'strict' | 'lax',
  maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
  path: '/',
};

// ── Controllers ───────────────────────────────────────────────

export async function login(req: Request, res: Response): Promise<void> {
  const body = LoginSchema.parse(req.body);

  const user = await prisma.user.findUnique({ where: { email: body.email } });
  if (!user || !(await verifyPassword(body.password, user.passwordHash))) {
    res.status(401).json({ success: false, error: 'Invalid email or password' });
    return;
  }

  const token = signToken({ id: user.id, email: user.email, role: user.role, name: user.name });

  // Set httpOnly cookie + return token in body (supports both cookie + Bearer usage)
  res.cookie('access_token', token, COOKIE_OPTIONS);
  res.json({
    success: true,
    data: {
      token,
      user: { id: user.id, email: user.email, role: user.role, name: user.name },
    },
  });
}

export async function logout(_req: Request, res: Response): Promise<void> {
  res.clearCookie('access_token', { path: '/' });
  res.json({ success: true, message: 'Logged out' });
}

export async function me(req: AuthRequest, res: Response): Promise<void> {
  const user = await prisma.user.findUnique({
    where: { id: req.user!.id },
    select: { id: true, email: true, role: true, name: true, createdAt: true },
  });
  res.json({ success: true, data: user });
}

export async function refreshToken(req: Request, res: Response): Promise<void> {
  const token = extractTokenFromRequest(req);
  if (!token) {
    res.status(401).json({ success: false, error: 'No token provided' });
    return;
  }
  try {
    const payload = verifyToken(token);
    const user = await prisma.user.findUnique({
      where: { id: payload.sub },
      select: { id: true, email: true, role: true, name: true },
    });
    if (!user) {
      res.status(401).json({ success: false, error: 'User not found' });
      return;
    }
    const newToken = signToken(user);
    res.cookie('access_token', newToken, COOKIE_OPTIONS);
    res.json({ success: true, data: { token: newToken } });
  } catch {
    res.status(401).json({ success: false, error: 'Invalid token' });
  }
}
