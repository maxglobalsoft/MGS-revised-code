import { Response } from 'express';
import { UploadApiResponse } from 'cloudinary';
import streamifier from 'streamifier';
import cloudinary from '../config/cloudinary';
import prisma from '../config/prisma';
import { AuthRequest } from '../types';

// ── Upload helpers ────────────────────────────────────────────

function uploadToCloudinary(buffer: Buffer, folder: string, resourceType: 'image' | 'raw' | 'auto' = 'auto'): Promise<UploadApiResponse> {
  return new Promise((resolve, reject) => {
    const uploadStream = cloudinary.uploader.upload_stream(
      { folder, resource_type: resourceType, use_filename: true, unique_filename: true },
      (error, result) => {
        if (error) reject(error);
        else resolve(result!);
      }
    );
    streamifier.createReadStream(buffer).pipe(uploadStream);
  });
}

// ── Controllers ───────────────────────────────────────────────

// POST /api/v1/media/upload
export async function uploadMedia(req: AuthRequest, res: Response): Promise<void> {
  const file = req.file;
  if (!file) {
    res.status(400).json({ success: false, error: 'No file provided' });
    return;
  }

  const folder = (req.body.folder as string) || 'mgs/uploads';
  const isResume = folder.includes('resume');
  const resourceType = isResume ? 'raw' : 'auto';

  const uploaded = await uploadToCloudinary(file.buffer, folder, resourceType);

  const media = await prisma.media.create({
    data: {
      url: uploaded.secure_url,
      publicId: uploaded.public_id,
      filename: file.originalname,
      mimetype: file.mimetype,
      size: file.size,
      folder,
    },
  });

  res.status(201).json({
    success: true,
    data: {
      id: media.id,
      url: media.url,
      filename: media.filename,
      publicId: media.publicId,
    },
  });
}

// POST /api/v1/media/upload-resume (multipart with optional resume)
export async function uploadResume(req: AuthRequest, res: Response): Promise<void> {
  const file = req.file;
  if (!file) {
    res.status(400).json({ success: false, error: 'No file provided' });
    return;
  }

  const ALLOWED_TYPES = [
    'application/pdf', 'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/rtf', 'text/plain',
  ];
  if (!ALLOWED_TYPES.includes(file.mimetype)) {
    res.status(400).json({ success: false, error: 'Resume must be a PDF, Word, or text file' });
    return;
  }

  const uploaded = await uploadToCloudinary(file.buffer, 'mgs/resumes', 'raw');

  res.json({
    success: true,
    data: { url: uploaded.secure_url, publicId: uploaded.public_id, filename: file.originalname },
  });
}

// GET /api/v1/admin/media
export async function listMedia(_req: AuthRequest, res: Response): Promise<void> {
  const media = await prisma.media.findMany({ orderBy: { createdAt: 'desc' } });
  res.json({ success: true, data: media });
}

// DELETE /api/v1/admin/media/:id
export async function deleteMedia(req: AuthRequest, res: Response): Promise<void> {
  const media = await prisma.media.findUnique({ where: { id: req.params.id } });
  if (!media) { res.status(404).json({ success: false, error: 'Media not found' }); return; }

  // Delete from Cloudinary
  try {
    await cloudinary.uploader.destroy(media.publicId);
  } catch {
    // Log but don't block — DB record should still be cleaned
    console.error(`Cloudinary deletion failed for ${media.publicId}`);
  }

  await prisma.media.delete({ where: { id: media.id } });
  res.json({ success: true, message: 'Deleted' });
}
