import 'dotenv/config';
import 'express-async-errors';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';

import router from './routes';
import { errorHandler, notFound } from './middleware/error.middleware';

// ── App setup ─────────────────────────────────────────────────

const app = express();
const PORT = Number(process.env.PORT) || 8000;

// ── Security & common middleware ──────────────────────────────

app.set('trust proxy', 1);

app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' },
}));

const allowedOrigins = (process.env.CORS_ORIGINS ?? '')
  .split(',')
  .map(o => o.trim())
  .filter(Boolean);

app.use(cors({
  origin: (origin, cb) => {
    if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin)) {
      cb(null, true);
    } else {
      cb(new Error(`CORS: origin ${origin} not allowed`));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

app.use(cookieParser());
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true, limit: '5mb' }));

if (process.env.NODE_ENV !== 'test') {
  app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
}

// ── Rate limiting ─────────────────────────────────────────────

app.use('/api/v1/contact', rateLimit({ windowMs: 15 * 60 * 1000, max: 10, message: { success: false, error: 'Too many submissions' } }));
app.use('/api/v1/apply',   rateLimit({ windowMs: 15 * 60 * 1000, max: 5,  message: { success: false, error: 'Too many applications' } }));
app.use('/api/v1/auth',    rateLimit({ windowMs: 15 * 60 * 1000, max: 20, message: { success: false, error: 'Too many auth requests' } }));

// ── Routes ────────────────────────────────────────────────────

// Sitemap/robots at root
app.get('/sitemap.xml', router);
app.get('/robots.txt', router);

// All API routes under /api/v1
app.use('/api/v1', router);

// Health check
app.get('/health', (_req, res) => {
  res.json({ success: true, status: 'ok', timestamp: new Date().toISOString() });
});

// ── Error handling ────────────────────────────────────────────

app.use(notFound);
app.use(errorHandler);

// ── Start ─────────────────────────────────────────────────────

app.listen(PORT, () => {
  console.log(`🚀 MGS API running on port ${PORT} [${process.env.NODE_ENV}]`);
});

export default app;
