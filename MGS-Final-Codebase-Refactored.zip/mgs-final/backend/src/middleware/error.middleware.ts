import { Request, Response, NextFunction } from 'express';
import { ZodError } from 'zod';

// Safe Prisma error detection without importing Prisma types before generation
function isPrismaError(err: unknown): err is { code: string; message: string } {
  return (
    typeof err === 'object' &&
    err !== null &&
    'code' in err &&
    'clientVersion' in err
  );
}

export function errorHandler(err: unknown, _req: Request, res: Response, _next: NextFunction): void {
  // Zod validation errors
  if (err instanceof ZodError) {
    res.status(422).json({
      success: false,
      error: 'Validation error',
      details: err.errors.map(e => ({ field: e.path.join('.'), message: e.message })),
    });
    return;
  }

  // Prisma known errors (P2002 = unique constraint, P2025 = not found)
  if (isPrismaError(err)) {
    const code = (err as { code: string }).code;
    if (code === 'P2002') {
      res.status(409).json({ success: false, error: 'A record with that value already exists' });
      return;
    }
    if (code === 'P2025') {
      res.status(404).json({ success: false, error: 'Record not found' });
      return;
    }
  }

  // Generic Error instances
  if (err instanceof Error) {
    const status = (err as Error & { status?: number }).status ?? 500;
    const message =
      process.env.NODE_ENV === 'production' && status === 500
        ? 'Internal server error'
        : err.message;
    res.status(status).json({ success: false, error: message });
    return;
  }

  res.status(500).json({ success: false, error: 'Internal server error' });
}

// 404 handler
export function notFound(_req: Request, res: Response): void {
  res.status(404).json({ success: false, error: 'Route not found' });
}
