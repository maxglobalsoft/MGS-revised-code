import { Response, NextFunction } from 'express';
import { Role } from '../types';
import { AuthRequest } from '../types';

export function requireRole(...roles: Role[]) {
  return (req: AuthRequest, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({ success: false, error: 'Authentication required' });
      return;
    }
    if (!roles.includes(req.user.role)) {
      res.status(403).json({ success: false, error: 'Insufficient permissions' });
      return;
    }
    next();
  };
}

// Convenience helpers matching the original Python RBAC matrix
export const superAdminOnly = requireRole(Role.SUPER_ADMIN);
export const editorOrAbove  = requireRole(Role.SUPER_ADMIN, Role.EDITOR);
