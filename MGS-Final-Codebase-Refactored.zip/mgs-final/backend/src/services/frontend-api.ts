// ──────────────────────────────────────────────────────────────
// MGS — Centralized API Service
// All backend calls go through this file.
// Replace import.meta.env.VITE_API_URL with the new Express API.
// ──────────────────────────────────────────────────────────────

const BASE_URL = (import.meta.env.VITE_API_URL as string) || '/api/v1';

// ── Core fetch wrapper ────────────────────────────────────────

async function request<T>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const url = `${BASE_URL}${path}`;

  const res = await fetch(url, {
    credentials: 'include',          // send httpOnly cookie
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
    ...options,
  });

  const json = await res.json().catch(() => ({ success: false, error: 'Invalid JSON response' }));

  if (!res.ok) {
    throw Object.assign(new Error(json.error ?? 'Request failed'), {
      status: res.status,
      data: json,
    });
  }

  return json;
}

function get<T>(path: string, init?: RequestInit) {
  return request<T>(path, { method: 'GET', ...init });
}

function post<T>(path: string, body?: unknown, init?: RequestInit) {
  return request<T>(path, { method: 'POST', body: JSON.stringify(body), ...init });
}

function put<T>(path: string, body?: unknown) {
  return request<T>(path, { method: 'PUT', body: JSON.stringify(body) });
}

function del<T>(path: string) {
  return request<T>(path, { method: 'DELETE' });
}

// ── Auth ──────────────────────────────────────────────────────

export const auth = {
  login:   (email: string, password: string) => post('/auth/login', { email, password }),
  logout:  () => post('/auth/logout'),
  me:      () => get('/auth/me'),
  refresh: () => post('/auth/refresh'),
};

// ── Site / CMS ────────────────────────────────────────────────

export const site = {
  getSite:       () => get('/site'),
  getSettings:   () => get('/settings'),
  getAllSections: () => get('/sections'),
  getSection:    (key: string) => get(`/sections/${key}`),
  getPageData:   (slug: string) => get(`/page/${slug}`),
  getPageMeta:   (slug: string) => get(`/page-meta/${slug}`),
  getStaticPage: (slug: string) => get(`/pages/${slug}`),
  search:        (q: string) => get(`/search?q=${encodeURIComponent(q)}`),
};

// ── Collections (public read) ─────────────────────────────────

export const collections = {
  list:         (collection: string) => get(`/collections/${collection}`),
  getCaseStudy: (slug: string) => get(`/case-studies/${slug}`),
  getPortfolio: (slug: string) => get(`/portfolio/${slug}`),
};

// ── Forms ─────────────────────────────────────────────────────

export const forms = {
  submitContact: (data: {
    name: string;
    email: string;
    phone?: string;
    company?: string;
    message: string;
  }) => post('/contact', data),

  submitApplication: async (data: {
    jobTitle?: string;
    name: string;
    mobile?: string;
    email: string;
    experience?: string;
    message?: string;
    resumeFile?: File | null;
  }) => {
    const formData = new FormData();
    if (data.jobTitle)    formData.append('jobTitle', data.jobTitle);
    formData.append('name', data.name);
    if (data.mobile)      formData.append('mobile', data.mobile);
    formData.append('email', data.email);
    if (data.experience)  formData.append('experience', data.experience);
    if (data.message)     formData.append('message', data.message);
    if (data.resumeFile)  formData.append('resume', data.resumeFile);

    return request('/apply', {
      method: 'POST',
      body: formData,
      headers: {}, // Let browser set Content-Type with boundary
    });
  },
};

// ── Admin — Collections ───────────────────────────────────────

export const adminCollections = {
  list:    (collection: string) => get(`/admin/collections/${collection}`),
  create:  (collection: string, data: unknown) => post(`/admin/collections/${collection}`, data),
  update:  (collection: string, id: string, data: unknown) => put(`/admin/collections/${collection}/${id}`, data),
  delete:  (collection: string, id: string) => del(`/admin/collections/${collection}/${id}`),
  reorder: (collection: string, ids: string[]) => put(`/admin/collections/${collection}/reorder`, { ids }),
};

// ── Admin — CMS ───────────────────────────────────────────────

export const adminCms = {
  updateSection:  (key: string, data: unknown) => put(`/admin/sections/${key}`, data),
  getSettings:    () => get('/settings'),
  updateSettings: (data: unknown) => put('/admin/settings', data),
  updatePageMeta: (slug: string, data: unknown) => put(`/admin/page-meta/${slug}`, data),
  listPages:      () => get('/admin/pages'),
  createPage:     (data: unknown) => post('/admin/pages', data),
  updatePage:     (id: string, data: unknown) => put(`/admin/pages/${id}`, data),
  deletePage:     (id: string) => del(`/admin/pages/${id}`),
};

// ── Admin — Media ─────────────────────────────────────────────

export const adminMedia = {
  list: () => get('/admin/media'),

  upload: async (file: File, folder?: string) => {
    const formData = new FormData();
    formData.append('file', file);
    if (folder) formData.append('folder', folder);
    return request('/admin/media/upload', {
      method: 'POST',
      body: formData,
      headers: {},
    });
  },

  delete: (id: string) => del(`/admin/media/${id}`),
};

// ── Admin — Inboxes ───────────────────────────────────────────

export const adminInboxes = {
  listContacts:          () => get('/admin/contact-submissions'),
  deleteContact:         (id: string) => del(`/admin/contact-submissions/${id}`),
  listApplications:      () => get('/admin/applications'),
  deleteApplication:     (id: string) => del(`/admin/applications/${id}`),
};

// ── Admin — Users ─────────────────────────────────────────────

export const adminUsers = {
  list:   () => get('/admin/users'),
  create: (data: { email: string; password: string; name?: string; role?: string }) => post('/admin/users', data),
  update: (id: string, data: { name?: string; role?: string; password?: string }) => put(`/admin/users/${id}`, data),
  delete: (id: string) => del(`/admin/users/${id}`),
};

// ── Default export (for convenience) ─────────────────────────

const api = { auth, site, collections, forms, adminCollections, adminCms, adminMedia, adminInboxes, adminUsers };
export default api;
