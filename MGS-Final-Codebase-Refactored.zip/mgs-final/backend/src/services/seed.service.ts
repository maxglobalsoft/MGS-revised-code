import 'dotenv/config';
import prisma from '../config/prisma';
import { hashPassword } from '../utils/password';
import { Role } from '../types';

// ── Seed data ─────────────────────────────────────────────────

const SETTINGS_DATA = {
  contact: {
    email: ['ceo@maxglobalsoft.com', 'info@maxglobalsoft.com'],
    phone: ['+91-7795287075', '+91-80-49746380', '+91-80-40935246'],
    website: 'https://www.maxglobalsoft.com',
    skype: '',
    offices: [
      {
        label: 'Head Office — Bengaluru',
        address: 'Samartha Apartment, #202, Door No. 2405, 18th Main Road, Kumaraswamy Layout 2nd Stage, Bengaluru – 560078, Karnataka, India',
        contactPerson: '',
        designation: '',
        phone: '+91-7795287075',
      },
      {
        label: 'Branch Office — Kolkata',
        address: 'SP Complex, Action Area II, Newtown, Kolkata – 700135, West Bengal, India',
        contactPerson: 'Rakib',
        designation: 'Branch Manager & Project Manager',
        phone: '+91 70768 20213',
      },
    ],
  },
  socials: [
    { platform: 'facebook', url: '#' },
    { platform: 'twitter', url: '#' },
    { platform: 'linkedin', url: '#' },
    { platform: 'youtube', url: '#' },
  ],
  nav_links: [
    { label: 'About Us', children: [
      { label: 'Why MGS', to: '/why-mgs' },
      { label: 'Our Team', to: '/our-team' },
    ]},
    { label: 'Services', to: '/services' },
    { label: 'Industries', to: '/industries' },
    { label: 'Portfolio', to: '/portfolio' },
    { label: 'Case Study', to: '/case-studies' },
    { label: 'Career', to: '/career' },
  ],
  footer_columns: [
    {
      heading: 'Our Services',
      links: [
        { label: 'Web Development', to: '/services' },
        { label: 'Mobile App Development', to: '/services' },
        { label: 'AI & ML Solutions', to: '/services' },
        { label: 'UI/UX Design', to: '/services' },
      ],
    },
    {
      heading: "Let's Explore",
      links: [
        { label: 'Why MGS', to: '/why-mgs' },
        { label: 'Our Team', to: '/our-team' },
        { label: 'Case Study', to: '/case-studies' },
        { label: 'Career', to: '/career' },
        { label: 'Reviews', to: '/reviews' },
      ],
    },
    {
      heading: 'T&C',
      links: [
        { label: 'Content Guidelines', to: '/p/content-guidelines' },
        { label: 'Legal Disclosure', to: '/p/legal-disclosure' },
        { label: 'Privacy Policy', to: '/p/privacy-policy' },
        { label: 'Security', to: '/p/security' },
        { label: 'Terms & Services', to: '/p/terms' },
      ],
    },
  ],
};

const LEGAL_PAGES = [
  { slug: 'privacy-policy',    title: 'Privacy Policy',    order: 1 },
  { slug: 'terms',             title: 'Terms & Services',  order: 2 },
  { slug: 'legal-disclosure',  title: 'Legal Disclosure',  order: 3 },
  { slug: 'content-guidelines',title: 'Content Guidelines',order: 4 },
  { slug: 'security',          title: 'Security',          order: 5 },
];

const SEED_SECTIONS = [
  { key: 'hero',            data: { heading: 'Powering Businesses With Tech Innovation', subhead: '& Transformative Digital Solutions', eyebrow: 'AI-FIRST SOFTWARE · SINCE 2005' } },
  { key: 'servicesHeader', data: { heading: 'Explore Services', subhead: 'We build intelligent, scalable digital solutions powered by modern AI.' } },
  { key: 'industriesHeader',data: { heading: 'Industries', subhead: 'Domain expertise across the sectors that matter most.' } },
  { key: 'achievements',   data: { heading: 'Company\nAchievements', eyebrow: 'OUR TRACK RECORD', stats: [{ label: 'Years Experience', value: '20+' }, { label: 'Web Portals', value: '800+' }, { label: 'Mobile Apps & Games', value: '400+' }, { label: 'Expert Team', value: '35+' }] } },
  { key: 'portfolioHeader',data: { heading: 'Our Portfolio', eyebrow: 'SELECTED WORK' } },
  { key: 'caseStudyHome', data: { heading: 'Case Study', eyebrow: 'IN DEPTH' } },
  { key: 'valuesHeader',  data: { heading: 'Our Values', eyebrow: 'WHAT DRIVES US', subhead: 'With a focus on innovation, we help clients helping, making a difference that lasts.' } },
  { key: 'techHeader',    data: { heading: 'Technologies & Platform', eyebrow: 'OUR STACK' } },
  { key: 'testimonialsHeader', data: { heading: 'Client Speaks', eyebrow: 'TESTIMONIALS' } },
  { key: 'clientsHeader', data: { heading: 'Esteemed Clients', eyebrow: 'TRUSTED BY' } },
  { key: 'ctaBand',       data: { heading: 'Gain An Upper Edge Over Your Competitors With Our Development Assistance!', form_title: 'What can we help you with?' } },
  { key: 'reviewsHeader', data: { heading: "Take Our Clients' Word for It", subhead: "Do you want to know why so many businesses enjoy working with us? Here's what they have to say." } },
  { key: 'careerHeader',  data: { heading: 'Career', subhead: 'We have {N} open positions now!' } },
  { key: 'careerNote',    data: { text: "We're always seeking talented people. If you can't find your role here, send us your LinkedIn profile and contact details — we'll be in touch." } },
  { key: 'contactHeader', data: { heading: "Let's Build Something Together", subhead: 'Tell us about your project — we will get back within one business day.' } },
  { key: 'whyMgsHeader', data: { heading: 'Why MGS', subhead: 'People, Technology, Excellence.' } },
  { key: 'teamHeader',   data: { heading: 'Our Team', subhead: 'People, Powered by Technology' } },
];

// ── Seed function ─────────────────────────────────────────────

async function seed() {
  console.log('🌱 Seeding database...');

  // 1. Admin user
  const adminEmail = process.env.ADMIN_EMAIL ?? 'admin@maxglobalsoft.com';
  const adminPassword = process.env.ADMIN_PASSWORD ?? 'Admin@MGS2026';
  const existing = await prisma.user.findUnique({ where: { email: adminEmail } });
  if (!existing) {
    await prisma.user.create({
      data: { email: adminEmail, passwordHash: await hashPassword(adminPassword), role: Role.SUPER_ADMIN as any, name: 'Super Admin' },
    });
    console.log(`  ✅ Admin user created: ${adminEmail}`);
  } else {
    console.log(`  ⏭  Admin user already exists`);
  }

  // 2. Editor user
  const editorEmail = 'editor@maxglobalsoft.com';
  const editorExists = await prisma.user.findUnique({ where: { email: editorEmail } });
  if (!editorExists) {
    await prisma.user.create({
      data: { email: editorEmail, passwordHash: await hashPassword('Editor@2026'), role: Role.EDITOR as any, name: 'Content Editor' },
    });
    console.log(`  ✅ Editor user created: ${editorEmail}`);
  }

  // 3. Settings
  const settingsExist = await prisma.settings.findUnique({ where: { id: 1 } });
  if (!settingsExist) {
    await prisma.settings.create({ data: { id: 1, data: SETTINGS_DATA } });
    console.log('  ✅ Settings seeded');
  }

  // 4. Sections
  for (const s of SEED_SECTIONS) {
    await prisma.section.upsert({
      where: { key: s.key },
      update: {},
      create: { key: s.key, data: s.data },
    });
  }
  console.log(`  ✅ ${SEED_SECTIONS.length} sections seeded`);

  // 5. Legal pages
  for (const p of LEGAL_PAGES) {
    const exists = await prisma.page.findUnique({ where: { slug: p.slug } });
    if (!exists) {
      await prisma.page.create({
        data: { slug: p.slug, title: p.title, body: `[Add the ${p.title} text via admin.]`, order: p.order },
      });
    }
  }
  console.log(`  ✅ ${LEGAL_PAGES.length} legal pages seeded`);

  console.log('🎉 Seed complete!');
}

seed()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
