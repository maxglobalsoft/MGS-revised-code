import { Router } from 'express';
import multer from 'multer';

import { requireAuth } from '../middleware/auth.middleware';
import { superAdminOnly, editorOrAbove } from '../middleware/rbac.middleware';
import { optionalAuth } from '../middleware/auth.middleware';

// Controllers
import * as auth from '../controllers/auth.controller';
import * as collections from '../controllers/collections.controller';
import * as cms from '../controllers/cms.controller';
import * as media from '../controllers/media.controller';
import * as forms from '../controllers/forms.controller';
import * as users from '../controllers/users.controller';
import * as seo from '../controllers/seo.controller';

const router = Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } }); // 10MB

// ─────────────────────────────────────────────────────────────
// SEO (served at root level)
// ─────────────────────────────────────────────────────────────
router.get('/sitemap.xml', seo.getSitemap);
router.get('/robots.txt', seo.getRobots);

// ─────────────────────────────────────────────────────────────
// AUTH  — /api/v1/auth/
// ─────────────────────────────────────────────────────────────
router.post('/auth/login', auth.login);
router.post('/auth/logout', auth.logout);
router.get('/auth/me', requireAuth, auth.me);
router.post('/auth/refresh', auth.refreshToken);

// ─────────────────────────────────────────────────────────────
// PUBLIC READ  — /api/v1/
// ─────────────────────────────────────────────────────────────
router.get('/site', cms.getSite);
router.get('/settings', cms.getSettings);
router.get('/sections', cms.getAllSections);
router.get('/sections/:key', cms.getSectionByKey);
router.get('/page/home', cms.getPageData.bind(null));          // /api/v1/page/home
router.get('/page/:slug', cms.getPageData);
router.get('/page-meta/:slug', cms.getPageMeta);
router.get('/pages/:slug', cms.getPageBySlug);                 // Static CMS pages
router.get('/search', seo.search);
router.post('/contact', forms.submitContact);
router.post('/apply', upload.single('resume'), async (req, res) => {
  // If resume file present, upload to Cloudinary first then store URL in body
  if (req.file) {
    const { uploadResume } = await import('../controllers/media.controller');
    // Inline mini-handler: upload resume then continue
    try {
      const cloudinary = (await import('../config/cloudinary')).default;
      const streamifier = (await import('streamifier')).default;
      
      await new Promise<void>((resolve) => {
        const uploadStream = cloudinary.uploader.upload_stream(
          { folder: 'mgs/resumes', resource_type: 'raw', use_filename: true },
          (err, result) => {
            if (!err && result) {
              req.body['resumeUrl'] = result.secure_url;
              req.body['resumeName'] = req.file!.originalname;
            }
            resolve();
          }
        );
        streamifier.createReadStream(req.file!.buffer).pipe(uploadStream);
      });
    } catch { /* Resume upload failed — don't block application */ }
  }
  return forms.submitApplication(req, res);
});

// Public collection reads (portfolio/case-studies by slug)
router.get('/case-studies/:slug', optionalAuth, (req, res) => {
  req.params.collection = 'caseStudies';
  req.params.id = req.params.slug;
  return collections.getItem(req as never, res);
});
router.get('/portfolio/:slug', optionalAuth, (req, res) => {
  req.params.collection = 'portfolioItems';
  req.params.id = req.params.slug;
  return collections.getItem(req as never, res);
});
router.get('/collections/:collection', optionalAuth, collections.listItems as never);

// ─────────────────────────────────────────────────────────────
// ADMIN  — /api/v1/admin/   (requireAuth + role check per route)
// ─────────────────────────────────────────────────────────────

// Collections (editor + above)
router.get('/admin/collections/:collection', requireAuth, editorOrAbove, collections.listItems as never);
router.post('/admin/collections/:collection', requireAuth, editorOrAbove, collections.createItem as never);
router.put('/admin/collections/:collection/reorder', requireAuth, editorOrAbove, collections.reorderItems as never);
router.put('/admin/collections/:collection/:id', requireAuth, editorOrAbove, collections.updateItem as never);
router.delete('/admin/collections/:collection/:id', requireAuth, editorOrAbove, collections.deleteItem as never);

// Sections (editor + above)
router.put('/admin/sections/:key', requireAuth, editorOrAbove, cms.updateSection as never);

// Settings (super_admin only)
router.put('/admin/settings', requireAuth, superAdminOnly, cms.updateSettings as never);

// Page meta (editor + above)
router.put('/admin/page-meta/:slug', requireAuth, editorOrAbove, cms.updatePageMeta as never);

// Static pages (editor + above)
router.get('/admin/pages', requireAuth, editorOrAbove, cms.listPages);
router.post('/admin/pages', requireAuth, editorOrAbove, cms.createPage as never);
router.put('/admin/pages/:id', requireAuth, editorOrAbove, cms.updatePage as never);
router.delete('/admin/pages/:id', requireAuth, editorOrAbove, cms.deletePage as never);

// Media (editor + above)
router.get('/admin/media', requireAuth, editorOrAbove, media.listMedia as never);
router.post('/admin/media/upload', requireAuth, editorOrAbove, upload.single('file'), media.uploadMedia as never);
router.delete('/admin/media/:id', requireAuth, editorOrAbove, media.deleteMedia as never);

// Contact submissions (super_admin only)
router.get('/admin/contact-submissions', requireAuth, superAdminOnly, forms.listContactSubmissions as never);
router.delete('/admin/contact-submissions/:id', requireAuth, superAdminOnly, forms.deleteContactSubmission as never);

// Applications (super_admin only)
router.get('/admin/applications', requireAuth, superAdminOnly, forms.listApplications as never);
router.delete('/admin/applications/:id', requireAuth, superAdminOnly, forms.deleteApplication as never);

// Users (super_admin only)
router.get('/admin/users', requireAuth, superAdminOnly, users.listUsers as never);
router.post('/admin/users', requireAuth, superAdminOnly, users.createUser as never);
router.put('/admin/users/:id', requireAuth, superAdminOnly, users.updateUser as never);
router.delete('/admin/users/:id', requireAuth, superAdminOnly, users.deleteUser as never);

export default router;
