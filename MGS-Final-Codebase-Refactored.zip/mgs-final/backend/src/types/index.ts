import { Request } from 'express';

// ── Role ──────────────────────────────────────────────────────
// Defined locally so TypeScript compiles before `npx prisma generate`.
// Values match the Role enum in prisma/schema.prisma exactly.

export const Role = {
  SUPER_ADMIN: 'SUPER_ADMIN' as const,
  EDITOR:      'EDITOR'      as const,
} as const;

export type Role = typeof Role[keyof typeof Role];

// ── Auth ──────────────────────────────────────────────────────

export interface JwtPayload {
  sub:   string;
  email: string;
  role:  Role;
  type:  'access';
}

export interface AuthUser {
  id:    string;
  email: string;
  role:  Role;
  name?: string | null;
}

export interface AuthRequest extends Request {
  user?: AuthUser;
}

// ── Collections ───────────────────────────────────────────────

export const ALLOWED_COLLECTIONS = [
  'services',
  'industries',
  'portfolioCategories',
  'portfolioItems',
  'caseStudies',
  'caseStudyCategories',
  'valuesItems',
  'technologies',
  'testimonials',
  'reviews',
  'clients',
  'teamMembers',
  'jobs',
  'serviceCards',
  'serviceIndustries',
  'recentProjects',
  'whyMgsBlocks',
  'certifications',
] as const;

export type CollectionName = typeof ALLOWED_COLLECTIONS[number];

// ── API Response ──────────────────────────────────────────────

export interface ApiResponse<T = unknown> {
  success:  boolean;
  data?:    T;
  message?: string;
  error?:   string;
}

// ── Cloudinary ────────────────────────────────────────────────

export interface CloudinaryUploadResult {
  public_id:         string;
  secure_url:        string;
  original_filename: string;
  bytes:             number;
  format:            string;
  resource_type:     string;
  folder?:           string;
}
