import jwt from 'jsonwebtoken';
import { JwtPayload, AuthUser } from '../types';
import { Role } from '../types';

const JWT_SECRET = process.env.JWT_SECRET!;
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN ?? '7d';

export function signToken(user: AuthUser): string {
  const payload: JwtPayload = {
    sub: user.id,
    email: user.email,
    role: user.role,
    type: 'access',
  };
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN } as jwt.SignOptions);
}

export function verifyToken(token: string): JwtPayload {
  const decoded = jwt.verify(token, JWT_SECRET) as JwtPayload;
  if (decoded.type !== 'access') {
    throw new Error('Invalid token type');
  }
  return decoded;
}

export function extractTokenFromRequest(req: { cookies?: Record<string, string>; headers: { authorization?: string } }): string | null {
  // 1. httpOnly cookie (preferred)
  if (req.cookies?.access_token) return req.cookies.access_token;
  // 2. Authorization: Bearer <token>
  const auth = req.headers.authorization;
  if (auth?.startsWith('Bearer ')) return auth.slice(7);
  return null;
}

export function parsedRole(role: string): Role {
  if (role === 'SUPER_ADMIN') return Role.SUPER_ADMIN;
  return Role.EDITOR;
}
