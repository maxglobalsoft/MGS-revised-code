import prisma from '../config/prisma';

const BASE_URL = () => process.env.PUBLIC_SITE_URL ?? 'https://www.maxglobalsoft.com';

const STATIC_ROUTES = [
  { path: '/', changefreq: 'weekly', priority: '1.0' },
  { path: '/services', changefreq: 'monthly', priority: '0.8' },
  { path: '/industries', changefreq: 'monthly', priority: '0.8' },
  { path: '/case-studies', changefreq: 'weekly', priority: '0.8' },
  { path: '/portfolio', changefreq: 'weekly', priority: '0.8' },
  { path: '/why-mgs', changefreq: 'monthly', priority: '0.7' },
  { path: '/our-team', changefreq: 'monthly', priority: '0.7' },
  { path: '/reviews', changefreq: 'weekly', priority: '0.7' },
  { path: '/career', changefreq: 'weekly', priority: '0.7' },
  { path: '/contact', changefreq: 'monthly', priority: '0.6' },
];

function urlEntry(loc: string, changefreq: string, priority: string, lastmod?: Date): string {
  return `  <url>
    <loc>${loc}</loc>${lastmod ? `\n    <lastmod>${lastmod.toISOString().split('T')[0]}</lastmod>` : ''}
    <changefreq>${changefreq}</changefreq>
    <priority>${priority}</priority>
  </url>`;
}

export async function generateSitemap(): Promise<string> {
  const base = BASE_URL();
  const entries: string[] = [];

  // Static routes
  for (const r of STATIC_ROUTES) {
    entries.push(urlEntry(`${base}${r.path}`, r.changefreq, r.priority));
  }

  // Case studies
  const caseStudies = await prisma.collectionItem.findMany({
    where: { collection: 'caseStudies', visible: true, slug: { not: null } },
    select: { slug: true, updatedAt: true },
  });
  for (const cs of caseStudies) {
    entries.push(urlEntry(`${base}/case-studies/${cs.slug}`, 'monthly', '0.7', cs.updatedAt));
  }

  // Portfolio items
  const portfolioItems = await prisma.collectionItem.findMany({
    where: { collection: 'portfolioItems', visible: true, slug: { not: null } },
    select: { slug: true, updatedAt: true },
  });
  for (const p of portfolioItems) {
    entries.push(urlEntry(`${base}/portfolio/${p.slug}`, 'monthly', '0.7', p.updatedAt));
  }

  // Static pages (CMS)
  const pages = await prisma.page.findMany({
    where: { visible: true },
    select: { slug: true, updatedAt: true },
  });
  for (const pg of pages) {
    entries.push(urlEntry(`${base}/p/${pg.slug}`, 'monthly', '0.5', pg.updatedAt));
  }

  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${entries.join('\n')}
</urlset>`;
}
