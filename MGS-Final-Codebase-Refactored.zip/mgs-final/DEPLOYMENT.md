# MGS Website — Refactored Codebase Deployment Guide

## Architecture Overview

```
client.maxglobalsoft.com   →  /frontend   (React app, built static files)
admin.maxglobalsoft.com    →  /frontend   (same build, /admin route)
api.maxglobalsoft.com      →  /backend    (Express/Node.js API)
```

All three are served from the same CentOS VPS with WHM/cPanel.
The backend connects to PostgreSQL (replaces MongoDB).
Media files are stored in Cloudinary (replaces local /uploads/).

---

## Step 1 — Prerequisites on the VPS

SSH into your server as root:

```bash
ssh root@your-vps-ip
```

Install Node.js 20 (if not already installed):

```bash
curl -fsSL https://rpm.nodesource.com/setup_20.x | bash -
yum install -y nodejs
node -v   # should show v20.x.x
npm -v
```

Install PostgreSQL 15:

```bash
dnf install -y https://download.postgresql.org/pub/repos/yum/reporpms/EL-8-x86_64/pgdg-redhat-repo-latest.noarch.rpm
dnf -qy module disable postgresql
dnf install -y postgresql15-server postgresql15
postgresql-15-setup initdb
systemctl enable postgresql-15 --now
```

Install PM2 (process manager for Node):

```bash
npm install -g pm2
```

---

## Step 2 — Set Up PostgreSQL Database

```bash
sudo -u postgres psql << 'SQL'
CREATE USER mgs_user WITH PASSWORD 'YourStrongPassword123!';
CREATE DATABASE mgs_db OWNER mgs_user;
GRANT ALL PRIVILEGES ON DATABASE mgs_db TO mgs_user;
SQL
```

---

## Step 3 — Deploy the Backend

### 3.1 Upload the backend folder to the VPS

Upload `/backend` to `/var/www/mgs-api` on the server.

Using SCP from your local machine:
```bash
scp -r ./backend root@your-vps-ip:/var/www/mgs-api
```

### 3.2 Set up environment variables

```bash
cd /var/www/mgs-api
cp .env.example .env
nano .env
```

Fill in all values in `.env`:

```env
NODE_ENV=production
PORT=8000
DATABASE_URL=postgresql://mgs_user:YourStrongPassword123!@localhost:5432/mgs_db
JWT_SECRET=<generate with: node -e "console.log(require('crypto').randomBytes(64).toString('hex'))">
JWT_EXPIRES_IN=7d
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
CLOUDINARY_UPLOAD_PRESET=mgs_uploads
CORS_ORIGINS=https://maxglobalsoft.com,https://www.maxglobalsoft.com,https://admin.maxglobalsoft.com
ADMIN_EMAIL=admin@maxglobalsoft.com
ADMIN_PASSWORD=Admin@MGS2026!
PUBLIC_SITE_URL=https://www.maxglobalsoft.com
```

### 3.3 Install dependencies and set up database

```bash
cd /var/www/mgs-api
npm install
npx prisma generate
npx prisma migrate deploy
npm run seed
```

Expected output:
```
✅ Admin user created: admin@maxglobalsoft.com
✅ Default settings seeded
✅ Sections seeded
```

### 3.4 Start the backend with PM2

```bash
npm run build
pm2 start dist/app.js --name mgs-api
pm2 save
pm2 startup   # follow the printed command to auto-start on reboot
```

Verify it's running:
```bash
curl http://localhost:8000/health
# Should return: {"success":true,"status":"ok","timestamp":"..."}
```

---

## Step 4 — Migrate MongoDB Data (if you have existing data)

If your old MongoDB still has live data, run the migration script:

```bash
# Add MONGO_URL to your .env first:
echo "MONGO_URL=mongodb://localhost:27017" >> /var/www/mgs-api/.env
echo "MONGO_DB_NAME=mgs_db_old" >> /var/www/mgs-api/.env

# Run the migration
cd /var/www/mgs-api
npx ts-node migrate-from-mongo.ts
```

The script is safe to re-run — it uses upsert everywhere.

---

## Step 5 — Deploy the Frontend

### 5.1 Build locally first

On your local machine (or CI):

```bash
cd frontend
cp .env.example .env
# Edit .env and set:
# REACT_APP_API_URL=https://api.maxglobalsoft.com/api/v1

npm install
npm run build
```

This creates a `/build` folder with static HTML/CSS/JS files.

### 5.2 Upload build to VPS

```bash
scp -r ./build root@your-vps-ip:/var/www/mgs-client
```

---

## Step 6 — Configure Nginx

Install Nginx if not present:

```bash
yum install -y nginx
systemctl enable nginx --now
```

Create the Nginx configuration:

```bash
nano /etc/nginx/conf.d/mgs.conf
```

Paste:

```nginx
# ── API backend ──────────────────────────────────────────────
server {
    listen 80;
    server_name api.maxglobalsoft.com;

    location / {
        proxy_pass         http://localhost:8000;
        proxy_http_version 1.1;
        proxy_set_header   Upgrade $http_upgrade;
        proxy_set_header   Connection 'upgrade';
        proxy_set_header   Host $host;
        proxy_set_header   X-Real-IP $remote_addr;
        proxy_set_header   X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}

# ── Client website ───────────────────────────────────────────
server {
    listen 80;
    server_name maxglobalsoft.com www.maxglobalsoft.com;

    root /var/www/mgs-client;
    index index.html;

    # React router — serve index.html for all routes
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Cache static assets
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}

# ── Admin (same build, different subdomain) ──────────────────
server {
    listen 80;
    server_name admin.maxglobalsoft.com;

    root /var/www/mgs-client;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

Test and reload:

```bash
nginx -t
systemctl reload nginx
```

---

## Step 7 — SSL Certificates (HTTPS)

```bash
# Install certbot
yum install -y certbot python3-certbot-nginx

# Get certificates for all three domains
certbot --nginx -d maxglobalsoft.com -d www.maxglobalsoft.com -d api.maxglobalsoft.com -d admin.maxglobalsoft.com

# Auto-renew (already set up by certbot, verify with):
systemctl status certbot-renew.timer
```

---

## Step 8 — DNS Configuration

In your domain registrar / DNS panel, add these A records:

| Type | Name  | Value          |
|------|-------|----------------|
| A    | @     | your-vps-ip    |
| A    | www   | your-vps-ip    |
| A    | api   | your-vps-ip    |
| A    | admin | your-vps-ip    |

---

## Step 9 — Go-Live Verification Checklist

```bash
# 1. API health check
curl https://api.maxglobalsoft.com/health

# 2. Public site data
curl https://api.maxglobalsoft.com/api/v1/site

# 3. Homepage data
curl https://api.maxglobalsoft.com/api/v1/page/home

# 4. Admin login (via browser)
# Open: https://admin.maxglobalsoft.com/admin/login
# Use: admin@maxglobalsoft.com / Admin@MGS2026!

# 5. Check PM2 is running
pm2 status

# 6. Check nginx is running
systemctl status nginx
```

---

## Ongoing Maintenance

### Updating the backend
```bash
cd /var/www/mgs-api
# (upload new files)
npm install
npm run build
pm2 restart mgs-api
```

### Updating the frontend
```bash
# Build locally, then:
scp -r ./build root@your-vps-ip:/var/www/mgs-client
```

### View backend logs
```bash
pm2 logs mgs-api
pm2 logs mgs-api --lines 100
```

### Database backup
```bash
pg_dump -U mgs_user mgs_db > backup_$(date +%Y%m%d).sql
```

---

## Environment Variables Reference

### Backend (.env)
| Variable | Description |
|----------|-------------|
| NODE_ENV | production / development |
| PORT | API port (default 8000) |
| DATABASE_URL | PostgreSQL connection string |
| JWT_SECRET | 64-char random secret |
| JWT_EXPIRES_IN | Token lifetime (e.g. 7d) |
| CLOUDINARY_CLOUD_NAME | From Cloudinary dashboard |
| CLOUDINARY_API_KEY | From Cloudinary dashboard |
| CLOUDINARY_API_SECRET | From Cloudinary dashboard |
| CORS_ORIGINS | Comma-separated allowed origins |
| ADMIN_EMAIL | Initial admin email |
| ADMIN_PASSWORD | Initial admin password |
| PUBLIC_SITE_URL | Full site URL for sitemap |
| MONGO_URL | MongoDB URL (migration only) |
| MONGO_DB_NAME | MongoDB DB name (migration only) |

### Frontend (.env)
| Variable | Description |
|----------|-------------|
| REACT_APP_API_URL | Full URL to Express API including /api/v1 |

---

*Prepared by Max Global Software — Quality Beyond Desires*
