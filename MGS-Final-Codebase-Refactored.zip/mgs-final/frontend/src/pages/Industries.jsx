import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Building2 } from 'lucide-react';

import SectionHeading from '@/components/brand/SectionHeading';
import SpotlightCard from '@/components/brand/SpotlightCard';
import CtaBand from '@/components/sections/CtaBand';
import { viewportOnce } from '@/lib/motion';
import { useIndustriesData } from '@/hooks/useIndustriesData';
import { resolveIcon } from '@/lib/iconMap';

/* ─── Static fallbacks ──────────────────────────────────────────────────── */

const DEFAULT_HEADER = {
  heading: 'Industries We Serve with Our AI & Software Development Services',
  subhead:
    'We build industry-tailored AI and software — streamlining operations and giving you a competitive edge, whatever your sector.',
  banner_image: 'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=2000&q=80',
  crumb: 'Industries',
};

const DEFAULT_INDUSTRIES = [
  { label: 'Transportation & Logistics', icon: 'Truck' },
  { label: 'E-Commerce & Retail', icon: 'ShoppingCart' },
  { label: 'FinTech', icon: 'Banknote' },
  { label: 'Healthcare', icon: 'HeartPulse' },
  { label: 'Real Estate', icon: 'Building2' },
  { label: 'Education', icon: 'GraduationCap', highlighted: true },
  { label: 'Manufacturing', icon: 'Factory' },
  { label: 'Telecommunication', icon: 'Radio' },
  { label: 'Insurance', icon: 'ShieldCheck' },
  { label: 'Marketing & Advertising', icon: 'Megaphone' },
  { label: 'Public Services', icon: 'Landmark' },
  { label: 'Professional Services', icon: 'Briefcase' },
];

/* ─── Page component ────────────────────────────────────────────────────── */

export default function IndustriesPage() {
  const { data } = useIndustriesData();

  const header = data?.sections?.industriesHeader?.data || DEFAULT_HEADER;
  const ctaData = data?.sections?.cta?.data;
  const liveIndustries = data?.collections?.serviceIndustries;
  const industries =
    Array.isArray(liveIndustries) && liveIndustries.length ? liveIndustries : DEFAULT_INDUSTRIES;

  return (
    <>
      {/* ─── Banner ──────────────────────────────────────────────────── */}
      <section className="relative pt-28 pb-12 bg-sky-50">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
            className="relative overflow-hidden rounded-2xl border border-hairline shadow-card"
            data-testid="industries-banner"
          >
            <img
              src={header.banner_image}
              alt={header.heading}
              loading="lazy"
              className="w-full h-[280px] sm:h-[340px] lg:h-[380px] object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-tr from-sky-50/60 via-transparent to-white/30 pointer-events-none" />
          </motion.div>

          {/* Heading + subhead, centered below the banner */}
          <div className="mt-14" data-testid="industries-heading">
            <SectionHeading
              title={header.heading}
              subtitle={header.subhead}
              align="center"
            />
          </div>
        </div>
      </section>

      {/* ─── Industry grid ───────────────────────────────────────────── */}
      <section className="pb-24 bg-sky-50">
        <div className="container mx-auto">
          <div
            className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5"
            data-testid="industries-grid"
          >
            {industries.map((it, i) => (
              <IndustryCard key={it.id || it.label || i} item={it} index={i} />
            ))}
          </div>
        </div>
      </section>

      <CtaBand data={ctaData} />
    </>
  );
}

/* ─── Sub-component ─────────────────────────────────────────────────────── */

function IndustryCard({ item, index = 0 }) {
  const Icon = resolveIcon(item.icon, Building2);
  return (
    <motion.div
      initial={{ opacity: 0, y: 28, scale: 0.95 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={viewportOnce}
      transition={{ duration: 0.55, delay: index * 0.05, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -8, scale: 1.03 }}
      className="h-full"
    >
      <Link
        to="/contact"
        aria-label={`Get in touch about ${item.label}`}
        data-testid={`industry-card-link-${index}`}
        className="block h-full rounded-2xl focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60"
      >
        <SpotlightCard
          className="h-full rounded-2xl border border-hairline overflow-hidden cursor-pointer group chip-hover-shadow"
          surfaceClassName="chip-hover-fill"
        >
          <div className="px-6 py-9 text-center relative">
            <motion.div
              whileHover={{ rotate: -8, scale: 1.12 }}
              transition={{ type: 'spring', stiffness: 320, damping: 16 }}
              className="mx-auto h-14 w-14 rounded-full inline-flex items-center justify-center bg-sky-100 text-brandblue transition-all duration-500 group-hover:bg-white group-hover:text-[#C9962E] group-hover:shadow-[0_10px_24px_rgba(255,255,255,0.5)]"
            >
              <Icon className="h-6 w-6" />
            </motion.div>
            <div className="mt-4 text-sm sm:text-[15px] leading-tight tracking-wide font-semibold text-navy transition-all duration-500 group-hover:text-white group-hover:font-bold group-hover:drop-shadow-[0_2px_4px_rgba(0,0,0,0.45)]">
              {item.label}
            </div>
          </div>
        </SpotlightCard>
      </Link>
    </motion.div>
  );
}
