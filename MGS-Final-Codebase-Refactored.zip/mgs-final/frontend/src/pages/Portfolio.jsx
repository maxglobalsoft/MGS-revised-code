import React, { useMemo, useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, ExternalLink, X, Image as ImageIcon } from 'lucide-react';

import SpotlightCard from '@/components/brand/SpotlightCard';
import MetricCountUp from '@/components/brand/MetricCountUp';
import CtaBand from '@/components/sections/CtaBand';
import { viewportOnce } from '@/lib/motion';
import { usePortfolioData } from '@/hooks/usePortfolioData';

const EASE = [0.22, 1, 0.36, 1];
const PAGE_SIZE = 12;

/* ─── Static fallbacks (match seed) ────────────────────────────────────── */

const DEFAULT_HEADER = {
  heading: 'Our Work',
  subhead:
    '800+ web portals and 400+ mobile apps delivered across industries worldwide. Explore a selection of what we\u2019ve built.',
};

const DEFAULT_CATEGORIES = [
  { category_id: 'web', label: 'Web' },
  { category_id: 'mobile', label: 'Mobile' },
  { category_id: 'ai', label: 'AI & ML' },
  { category_id: 'ecom', label: 'E-Commerce' },
  { category_id: 'biz', label: 'Enterprise' },
  { category_id: 'uiux', label: 'UI/UX' },
  { category_id: 'games', label: 'Games' },
];

const STATS = [
  { value: '800+', label: 'Web portals' },
  { value: '400+', label: 'Mobile apps' },
  { value: '35+',  label: 'AI experts' },
];

/* ─── Page ─────────────────────────────────────────────────────────────── */

export default function Portfolio() {
  const { data } = usePortfolioData();

  const header = data?.sections?.portfolioHeader?.data || DEFAULT_HEADER;
  const ctaData = data?.sections?.cta?.data;
  const categories =
    Array.isArray(data?.collections?.portfolioCategories) && data.collections.portfolioCategories.length
      ? data.collections.portfolioCategories
      : DEFAULT_CATEGORIES;
  const items = Array.isArray(data?.collections?.portfolioItems) ? data.collections.portfolioItems : [];

  const [activeCat, setActiveCat] = useState('all');
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const [lightbox, setLightbox] = useState(null); // {img, title}

  // Reset visible count when category changes
  useEffect(() => { setVisibleCount(PAGE_SIZE); }, [activeCat]);

  const filtered = useMemo(() => {
    if (activeCat === 'all') return items;
    return items.filter((it) => it.category === activeCat);
  }, [items, activeCat]);

  const visibleItems = filtered.slice(0, visibleCount);
  const hasMore = filtered.length > visibleCount;

  const closeLightbox = useCallback(() => setLightbox(null), []);

  return (
    <>
      <PortfolioHeader header={header} />

      {/* ─── Filter tabs ─────────────────────────────────────────────── */}
      <section className="bg-sky-50 pt-4 pb-4 sticky top-[68px] z-30 backdrop-blur border-b border-hairline">
        <div className="container mx-auto">
          <FilterTabs
            categories={categories}
            activeCat={activeCat}
            onChange={setActiveCat}
          />
        </div>
      </section>

      {/* ─── Immersive grid ──────────────────────────────────────────── */}
      <section className="py-16 sm:py-20 bg-sky-50">
        <div className="container mx-auto">
          <motion.div
            layout
            data-testid="portfolio-grid"
            className="grid grid-cols-1 sm:grid-cols-6 lg:grid-cols-12 auto-rows-[260px] gap-5"
          >
            <AnimatePresence mode="popLayout">
              {visibleItems.map((it, idx) => (
                <PortfolioTile
                  key={it.id || it.title + idx}
                  item={it}
                  index={idx}
                  onLightbox={(payload) => setLightbox(payload)}
                />
              ))}
            </AnimatePresence>
          </motion.div>

          {filtered.length === 0 && (
            <p className="mt-12 text-center text-slatebody text-sm italic">
              No projects in this category yet.
            </p>
          )}

          {hasMore && (
            <div className="mt-14 flex justify-center">
              <button
                onClick={() => setVisibleCount((n) => n + PAGE_SIZE)}
                data-testid="portfolio-load-more"
                className="group inline-flex items-center gap-2 text-[11px] tracking-[0.22em] uppercase font-bold text-brandblue hover:text-navy-deep transition-colors px-6 py-3 rounded-full border border-brandblue/30 hover:border-brandblue bg-white"
              >
                Load more work
                <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1.5" />
              </button>
            </div>
          )}
        </div>
      </section>

      <CtaBand data={ctaData} />

      {/* ─── Lightbox ──────────────────────────────────────────────────── */}
      <AnimatePresence>
        {lightbox && <Lightbox payload={lightbox} onClose={closeLightbox} />}
      </AnimatePresence>
    </>
  );
}

/* ─── Header (immersive, centered + slim credibility strip) ───────────── */

function PortfolioHeader({ header }) {
  const reducedMotion = useReducedMotion();
  return (
    <section
      className="relative pt-36 pb-16 sm:pt-44 sm:pb-20 overflow-hidden bg-sky-50"
      data-testid="portfolio-header"
    >
      <HeaderMesh reducedMotion={reducedMotion} />
      <div className="container mx-auto relative max-w-4xl text-center">
        <motion.p
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, ease: EASE }}
          className="text-xs sm:text-sm uppercase tracking-[0.2em] font-semibold text-brandblue mb-5"
        >
          Portfolio
        </motion.p>
        <motion.h1
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1, ease: EASE }}
          className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-navy-deep leading-[1.05]"
        >
          {header.heading}
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.25, ease: EASE }}
          className="mt-6 max-w-2xl mx-auto text-slatebody text-base sm:text-[15px] leading-relaxed"
        >
          {header.subhead}
        </motion.p>
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ duration: 0.9, delay: 0.4, ease: EASE }}
          style={{ transformOrigin: 'center' }}
          className="mx-auto mt-8 h-[2px] w-24 rounded-full bg-gradient-to-r from-[#2BA8E0] via-[#2F6FB0] to-[#E8C25A]"
        />

        {/* Slim credibility strip */}
        <div className="mt-12 flex flex-wrap items-center justify-center gap-x-12 gap-y-4">
          {STATS.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 + i * 0.07, ease: EASE }}
              className="text-center"
            >
              <div className="text-2xl sm:text-3xl font-bold tracking-tight text-navy-deep leading-none">
                <MetricCountUp value={s.value} />
              </div>
              <p className="mt-1.5 text-[10px] tracking-[0.22em] uppercase font-bold text-slatebody/80">{s.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function HeaderMesh({ reducedMotion }) {
  return (
    <div className="absolute inset-0 pointer-events-none opacity-60" aria-hidden="true">
      <motion.div
        className="absolute -top-32 -left-24 w-[480px] h-[480px] rounded-full blur-3xl"
        style={{ background: 'radial-gradient(circle, rgba(47,111,176,0.18), transparent 65%)' }}
        animate={reducedMotion ? {} : { x: [0, 16, 0], y: [0, 10, 0] }}
        transition={{ duration: 22, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div
        className="absolute -bottom-40 -right-24 w-[520px] h-[520px] rounded-full blur-3xl"
        style={{ background: 'radial-gradient(circle, rgba(201,150,46,0.14), transparent 65%)' }}
        animate={reducedMotion ? {} : { x: [0, -14, 0], y: [0, -8, 0] }}
        transition={{ duration: 26, repeat: Infinity, ease: 'easeInOut' }}
      />
    </div>
  );
}

/* ─── Filter tabs ──────────────────────────────────────────────────────── */

function FilterTabs({ categories, activeCat, onChange }) {
  const tabs = [{ category_id: 'all', label: 'All' }, ...categories];
  return (
    <div
      role="tablist"
      data-testid="portfolio-filter-tabs"
      className="flex flex-wrap justify-center gap-2 sm:gap-3"
    >
      {tabs.map((c) => {
        const isActive = activeCat === c.category_id;
        return (
          <button
            key={c.category_id}
            role="tab"
            aria-selected={isActive}
            data-testid={`portfolio-tab-${c.category_id}`}
            onClick={() => onChange(c.category_id)}
            className="relative isolate px-5 py-2.5 text-[11px] tracking-[0.18em] uppercase font-bold rounded-full focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60 transition-colors"
          >
            {isActive && (
              <motion.span
                layoutId="portfolio-tab-pill"
                transition={{ type: 'spring', stiffness: 380, damping: 32 }}
                className="absolute inset-0 rounded-full bg-navy-deep shadow-card -z-10"
              />
            )}
            <span className={isActive ? 'text-white' : 'text-navy/70 hover:text-navy'}>{c.label}</span>
          </button>
        );
      })}
    </div>
  );
}

/* ─── Portfolio tile (immersive) ───────────────────────────────────────── */

const TILE_SPANS = [
  // 12-col grid, 260px row → tasteful asymmetric rhythm
  'sm:col-span-4 sm:row-span-2 lg:col-span-6 lg:row-span-2',
  'sm:col-span-2 sm:row-span-1 lg:col-span-3 lg:row-span-1',
  'sm:col-span-2 sm:row-span-1 lg:col-span-3 lg:row-span-1',
  'sm:col-span-3 sm:row-span-1 lg:col-span-4 lg:row-span-1',
  'sm:col-span-3 sm:row-span-1 lg:col-span-4 lg:row-span-1',
  'sm:col-span-6 sm:row-span-1 lg:col-span-4 lg:row-span-1',
];

function PortfolioTile({ item, index, onLightbox }) {
  const navigate = useNavigate();
  const span = TILE_SPANS[index % TILE_SPANS.length];

  const handleClick = (e) => {
    if (item.caseStudySlug) {
      navigate(`/case-studies/${item.caseStudySlug}`);
    } else if (item.slug) {
      navigate(`/portfolio/${item.slug}`);
    } else if (item.link) {
      window.open(item.link, '_blank', 'noopener,noreferrer');
    } else {
      e.preventDefault();
      onLightbox({ img: item.img, title: item.title });
    }
  };

  const accessibleLabel = item.caseStudySlug
    ? `Read case study: ${item.title}`
    : item.slug
    ? `Open project: ${item.title}`
    : item.link
    ? `Open ${item.title} in a new tab`
    : `Preview ${item.title}`;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 28, scale: 0.97 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -12, scale: 0.96 }}
      transition={{ duration: 0.55, delay: index * 0.035, ease: EASE }}
      whileHover={{ y: -4 }}
      className={`relative ${span}`}
    >
      <SpotlightCard
        className="h-full rounded-2xl overflow-hidden"
        surfaceClassName="bg-navy-deep border border-hairline shadow-[0_10px_28px_rgba(31,45,69,0.10)] hover:shadow-[0_22px_50px_rgba(31,45,69,0.20)]"
      >
        <button
          type="button"
          data-testid={`portfolio-tile-${index}`}
          aria-label={accessibleLabel}
          onClick={handleClick}
          className="group block relative w-full h-full text-left cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60"
        >
          {item.img ? (
            <motion.img
              layoutId={item.slug ? `portfolio-img-${item.slug}` : undefined}
              src={item.img}
              alt={item.title}
              loading="lazy"
              className="absolute inset-0 w-full h-full object-cover grayscale opacity-95 transition-all duration-[1.1s] ease-out group-hover:grayscale-0 group-hover:scale-[1.05] group-hover:opacity-100 will-change-transform"
            />
          ) : (
            <div
              aria-hidden="true"
              className="absolute inset-0"
              style={{ background: 'linear-gradient(135deg, #1F4373 0%, #2F6FB0 55%, #E8C25A20 100%)' }}
            >
              <ImageIcon className="absolute inset-0 m-auto h-10 w-10 text-white/40" strokeWidth={1.4} />
            </div>
          )}

          {/* Idle gradient (subtle, always present) */}
          <div className="absolute inset-x-0 bottom-0 h-2/3 bg-gradient-to-t from-navy-deep/85 via-navy-deep/30 to-transparent" />

          {/* Bottom-left always-on title (smaller) */}
          <div className="absolute left-5 right-5 bottom-5 transition-all duration-500 group-hover:opacity-0 group-hover:-translate-y-2">
            <p className="text-[10px] font-bold tracking-[0.2em] uppercase text-[#E8C25A] mb-1.5">
              {item.tag || ''}
            </p>
            <h3 className="text-white text-base sm:text-lg font-semibold tracking-tight leading-snug drop-shadow-[0_1px_2px_rgba(0,0,0,0.5)] line-clamp-2">
              {item.title}
            </h3>
          </div>

          {/* Hover overlay reveal */}
          <div className="absolute inset-0 p-6 flex flex-col justify-end opacity-0 group-hover:opacity-100 translate-y-3 group-hover:translate-y-0 transition-all duration-500 bg-gradient-to-t from-navy-deep via-navy-deep/65 to-transparent">
            <p className="text-[10px] font-bold tracking-[0.2em] uppercase text-[#E8C25A] mb-2">
              {item.tag || ''}
            </p>
            <h3 className="text-white text-lg sm:text-xl font-bold tracking-tight leading-tight drop-shadow-[0_1px_2px_rgba(0,0,0,0.5)]">
              {item.title}
            </h3>
            {Array.isArray(item.tags) && item.tags.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {item.tags.slice(0, 4).map((t, i) => (
                  <span
                    key={t + i}
                    className="text-[10px] font-semibold tracking-wide px-2 py-0.5 rounded-full bg-white/15 backdrop-blur text-white"
                  >
                    {t}
                  </span>
                ))}
              </div>
            )}
            <span className="mt-4 inline-flex items-center gap-1.5 text-[11px] font-bold tracking-[0.18em] uppercase text-white">
              {item.caseStudySlug ? 'View case study' : item.link ? 'Open live project' : 'Preview'}
              {item.link && !item.caseStudySlug ? (
                <ExternalLink className="h-3.5 w-3.5" />
              ) : (
                <ArrowRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-1.5" />
              )}
            </span>
          </div>
        </button>
      </SpotlightCard>
    </motion.div>
  );
}

/* ─── Lightbox ─────────────────────────────────────────────────────────── */

function Lightbox({ payload, onClose }) {
  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [onClose]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3, ease: EASE }}
      data-testid="portfolio-lightbox"
      className="fixed inset-0 z-[80] bg-navy-deep/90 backdrop-blur-sm flex items-center justify-center p-6"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.94, y: 18 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.95 }}
        transition={{ duration: 0.4, ease: EASE }}
        className="relative max-w-5xl w-full max-h-[88vh] rounded-2xl overflow-hidden shadow-[0_30px_80px_rgba(0,0,0,0.5)]"
        onClick={(e) => e.stopPropagation()}
      >
        <img
          src={payload.img}
          alt={payload.title}
          className="w-full h-auto object-contain max-h-[88vh]"
        />
        <button
          aria-label="Close preview"
          onClick={onClose}
          data-testid="portfolio-lightbox-close"
          className="absolute top-4 right-4 h-10 w-10 rounded-full bg-white/95 text-navy-deep inline-flex items-center justify-center hover:bg-white shadow-card"
        >
          <X className="h-5 w-5" />
        </button>
        <div className="absolute bottom-0 left-0 right-0 p-5 bg-gradient-to-t from-navy-deep/85 to-transparent">
          <p className="text-white font-semibold text-sm sm:text-base">{payload.title}</p>
        </div>
      </motion.div>
    </motion.div>
  );
}
