import React, { useState } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { Linkedin, User } from 'lucide-react';

import CtaBand from '@/components/sections/CtaBand';
import TeamMemberModal from '@/components/brand/TeamMemberModal';
import { viewportOnce } from '@/lib/motion';
import { useTeamData } from '@/hooks/useTeamData';

const EASE = [0.22, 1, 0.36, 1];

/* ─── Fallbacks (match seed 1:1) ───────────────────────────────────────── */

const DEFAULT_HEADER = {
  heading: 'Our Team',
  subhead: 'Driven by People, Powered by Technology',
};

const DEFAULT_TEAM = [
  { name: 'Bhupendra Verma', role: 'Founder & Managing Director' },
  { name: '[Team Member — add real name, role & photo via admin]', role: 'Co-Founder & CTO' },
  { name: '[Team Member — add real name, role & photo via admin]', role: 'Director — Projects & Operations' },
  { name: '[Team Member — add real name, role & photo via admin]', role: 'HR & Recruitment Head' },
  { name: '[Team Member — add real name, role & photo via admin]', role: 'Head of Engineering' },
  { name: '[Team Member — add real name, role & photo via admin]', role: 'AI / ML Lead' },
  { name: '[Team Member — add real name, role & photo via admin]', role: 'Design Lead' },
  { name: '[Team Member — add real name, role & photo via admin]', role: 'QA Lead' },
];

/* ─── Page ─────────────────────────────────────────────────────────────── */

export default function OurTeam() {
  const { data } = useTeamData();
  const [openMember, setOpenMember] = useState(null);

  const header = data?.sections?.teamHeader?.data || DEFAULT_HEADER;
  const ctaData = data?.sections?.cta?.data;
  const team =
    Array.isArray(data?.collections?.teamMembers) && data.collections.teamMembers.length
      ? data.collections.teamMembers
      : DEFAULT_TEAM;

  return (
    <>
      <TeamHeader header={header} />

      {/* ─── Team grid ────────────────────────────────────────────────── */}
      <section className="py-16 sm:py-24 bg-sky-50">
        <div className="container mx-auto">
          <motion.div
            initial="hidden"
            animate="show"
            variants={{
              hidden: {},
              show: { transition: { staggerChildren: 0.07, delayChildren: 0.06 } },
            }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-14"
            data-testid="team-grid"
          >
            {team.map((m, i) => (
              <TeamCard key={(m.id || m.name) + i} member={m} index={i} onOpen={setOpenMember} />
            ))}
          </motion.div>
        </div>
      </section>

      <CtaBand data={ctaData} />

      <TeamMemberModal member={openMember} onClose={() => setOpenMember(null)} />
    </>
  );
}

/* ─── Header ───────────────────────────────────────────────────────────── */

function TeamHeader({ header }) {
  const reducedMotion = useReducedMotion();
  return (
    <section
      className="relative pt-36 pb-16 sm:pt-44 sm:pb-20 overflow-hidden bg-sky-50"
      data-testid="team-header"
    >
      <HeaderMesh reducedMotion={reducedMotion} />
      <div className="container mx-auto relative max-w-4xl text-center">
        <motion.p
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, ease: EASE }}
          className="text-xs sm:text-sm uppercase tracking-[0.2em] font-semibold text-brandblue mb-5"
        >
          {header.heading}
        </motion.p>
        <motion.h1
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1, ease: EASE }}
          className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-brandblue leading-[1.05]"
        >
          {header.subhead}
        </motion.h1>
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ duration: 0.9, delay: 0.35, ease: EASE }}
          style={{ transformOrigin: 'center' }}
          className="mx-auto mt-7 h-[2px] w-24 rounded-full bg-gradient-to-r from-[#2BA8E0] via-[#2F6FB0] to-[#E8C25A]"
        />
      </div>
    </section>
  );
}

function HeaderMesh({ reducedMotion }) {
  return (
    <div className="absolute inset-0 pointer-events-none opacity-60" aria-hidden="true">
      <motion.div
        className="absolute -top-32 -left-24 w-[480px] h-[480px] rounded-full blur-3xl"
        style={{ background: 'radial-gradient(circle, rgba(47,111,176,0.18), transparent 65%)' }}
        animate={reducedMotion ? {} : { x: [0, 16, 0], y: [0, 10, 0] }}
        transition={{ duration: 22, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div
        className="absolute -bottom-40 -right-24 w-[520px] h-[520px] rounded-full blur-3xl"
        style={{ background: 'radial-gradient(circle, rgba(201,150,46,0.14), transparent 65%)' }}
        animate={reducedMotion ? {} : { x: [0, -14, 0], y: [0, -8, 0] }}
        transition={{ duration: 26, repeat: Infinity, ease: 'easeInOut' }}
      />
    </div>
  );
}

/* ─── Team Card (circular photo, gold ring sweep on hover) ────────────── */

function TeamCard({ member, index, onOpen }) {
  const { name, role, photo, linkedin } = member;
  const initials = String(name || '?')
    .replace(/\[.*?\]/g, '')
    .trim()
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0])
    .join('')
    .toUpperCase() || '–';
  const placeholderName = /^\[/.test(String(name).trim());

  const handleOpen = () => onOpen?.(member);
  const handleKey = (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      handleOpen();
    }
  };

  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 28 },
        show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: EASE } },
      }}
      whileHover={{ y: -6 }}
      onClick={handleOpen}
      onKeyDown={handleKey}
      role="button"
      tabIndex={0}
      aria-label={placeholderName ? 'Open team member bio' : `Open bio for ${name}`}
      data-testid={`team-card-${index}`}
      className="group flex flex-col items-center text-center cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60 rounded-2xl"
    >
      {/* Photo + animated gold ring */}
      <div className="relative">
        {/* Outer rotating gold ring (visible on hover) */}
        <span
          aria-hidden="true"
          className="absolute -inset-1.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500 will-change-transform group-hover:[animation:spin_8s_linear_infinite]"
          style={{
            background:
              'conic-gradient(from 0deg, #C9962E 0deg, #E8C25A 90deg, transparent 180deg, transparent 270deg, #C9962E 360deg)',
            mask: 'radial-gradient(circle, transparent 60%, black 62%)',
            WebkitMask: 'radial-gradient(circle, transparent 60%, black 62%)',
          }}
        />
        {/* Inner ambient halo */}
        <span
          aria-hidden="true"
          className="absolute -inset-3 rounded-full opacity-0 group-hover:opacity-70 transition-opacity duration-500 blur-2xl"
          style={{
            background:
              'radial-gradient(circle, rgba(232,194,90,0.45), transparent 70%)',
          }}
        />

        <div className="relative h-40 w-40 rounded-full overflow-hidden border-2 border-white ring-1 ring-hairline shadow-[0_14px_38px_rgba(31,45,69,0.14)] bg-sky-100">
          {photo ? (
            <img
              src={photo}
              alt={placeholderName ? 'Team member placeholder' : name}
              loading="lazy"
              className="w-full h-full object-cover transition-transform duration-[900ms] ease-out group-hover:scale-110 will-change-transform"
            />
          ) : (
            <div
              aria-hidden="true"
              className="absolute inset-0 flex items-center justify-center"
              style={{
                background: 'linear-gradient(135deg, #E6F1FB 0%, #C9DCEF 55%, #E8C25A20 100%)',
              }}
            >
              {placeholderName ? (
                <User className="h-12 w-12 text-navy/35" strokeWidth={1.4} />
              ) : (
                <span className="text-3xl font-bold tracking-tight text-navy-deep/65 select-none">
                  {initials}
                </span>
              )}
            </div>
          )}
        </div>

        {/* LinkedIn chip — fades in on hover */}
        {linkedin && (
          <a
            href={linkedin}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e) => e.stopPropagation()}
            aria-label={`${name} on LinkedIn`}
            className="absolute bottom-1 right-1 h-9 w-9 rounded-full bg-white shadow-card border border-hairline inline-flex items-center justify-center text-brandblue opacity-0 translate-y-1 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-400 hover:text-navy-deep"
          >
            <Linkedin className="h-4 w-4" strokeWidth={2.2} />
          </a>
        )}
      </div>

      {/* Name + Role */}
      <h3
        className={`mt-6 text-[15px] font-bold tracking-tight leading-snug ${
          placeholderName ? 'text-slatebody/60 italic font-medium text-[13px]' : 'text-navy-deep'
        }`}
      >
        {placeholderName ? '— Add team member via admin —' : name}
      </h3>
      <p className="mt-2 text-[11px] font-bold tracking-[0.18em] uppercase text-brandblue">
        {role}
      </p>
    </motion.div>
  );
}
