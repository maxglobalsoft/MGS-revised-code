import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Home } from 'lucide-react';
import { PrimaryButton } from '@/components/brand/Buttons';

export default function NotFound() {
  return (
    <section className="min-h-[80vh] flex items-center justify-center pt-44 pb-20">
      <div className="container mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="text-[120px] sm:text-[180px] font-bold leading-none text-gradient-blue-gold">
            404
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold text-navy-deep">Page not found</h1>
          <p className="mt-3 max-w-md mx-auto text-slatebody">
            The page you&apos;re looking for doesn&apos;t exist or has moved. Let&apos;s get you
            back home.
          </p>
          <div className="mt-7">
            <Link to="/">
              <PrimaryButton icon={<Home className="h-4 w-4" />}>Back to Home</PrimaryButton>
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
