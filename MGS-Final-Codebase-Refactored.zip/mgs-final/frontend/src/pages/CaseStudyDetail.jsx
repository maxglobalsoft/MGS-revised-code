import React, { useEffect, useMemo, useRef, useState } from 'react';
import { motion, useReducedMotion, useMotionValue, useSpring } from 'framer-motion';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ChevronLeft, ChevronRight } from 'lucide-react';

import PageHero from '@/components/layout/PageHero';
import MetricCountUp from '@/components/brand/MetricCountUp';
import CtaBand from '@/components/sections/CtaBand';
import { viewportOnce } from '@/lib/motion';
import { useCaseStudyDetail } from '@/hooks/useCaseStudyDetail';
import { useCaseStudiesData } from '@/hooks/useCaseStudiesData';

const EASE = [0.22, 1, 0.36, 1];

const SECTION_DEFS = [
  { id: 'overview', label: 'Overview' },
  { id: 'gallery', label: 'Gallery' },
  { id: 'tech', label: 'Tech Stack' },
  { id: 'challenge', label: 'Challenge' },
  { id: 'solution', label: 'Solution' },
  { id: 'results', label: 'Results' },
];

export default function CaseStudyDetail() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { data, loading, notFound } = useCaseStudyDetail(slug);
  const { data: listData } = useCaseStudiesData();
  const reducedMotion = useReducedMotion();

  // Update page meta from the case study
  useEffect(() => {
    if (!data?.meta) return;
    if (data.meta.title) document.title = data.meta.title;
    const setMeta = (sel, attr, name, content) => {
      if (!content) return;
      let el = document.querySelector(sel);
      if (!el) {
        el = document.createElement('meta');
        el.setAttribute(attr, name);
        document.head.appendChild(el);
      }
      el.setAttribute('content', content);
    };
    setMeta('meta[name="description"]', 'name', 'description', data.meta.description);
    setMeta('meta[property="og:title"]', 'property', 'og:title', data.meta.title);
    setMeta('meta[property="og:description"]', 'property', 'og:description', data.meta.description);
    if (data.meta.og_image) {
      const abs = /^https?:\/\//i.test(data.meta.og_image)
        ? data.meta.og_image
        : `${window.location.origin}${data.meta.og_image.startsWith('/') ? '' : '/'}${data.meta.og_image}`;
      setMeta('meta[property="og:image"]', 'property', 'og:image', abs);
    }
  }, [data?.meta]);

  // Measure the real navbar height at runtime so the sticky progress track sits
  // flush below it regardless of the navbar's actual size. Also track the
  // rendered progress-track height so anchor jumps land below both.
  const trackRef = useRef(null);
  const [navH, setNavH] = useState(160);
  const [trackH, setTrackH] = useState(52);

  useEffect(() => {
    const measure = () => {
      const header = document.querySelector('header');
      if (header) setNavH(header.offsetHeight || 160);
      if (trackRef.current) setTrackH(trackRef.current.offsetHeight || 52);
    };
    measure();
    // ResizeObserver covers nav logo loading + responsive breakpoint changes
    const ro = new ResizeObserver(measure);
    const header = document.querySelector('header');
    if (header) ro.observe(header);
    if (trackRef.current) ro.observe(trackRef.current);
    window.addEventListener('resize', measure);
    return () => {
      ro.disconnect();
      window.removeEventListener('resize', measure);
    };
  }, []);

  if (notFound) {
    return (
      <>
        <PageHero title="Case Study Not Found" subtitle="The case study you're looking for doesn't exist." crumb="Case Study" />
        <section className="py-16">
          <div className="container mx-auto text-center">
            <Link to="/case-studies" data-testid="cs-back-link" className="text-sm font-semibold text-brandblue hover:text-[#C9962E]">
              ← Back to all case studies
            </Link>
          </div>
        </section>
        <CtaBand />
      </>
    );
  }

  if (loading || !data) {
    return (
      <section className="py-32 bg-sky-50">
        <div className="container mx-auto text-center text-sm text-slatebody">Loading case study…</div>
      </section>
    );
  }

  const cs = data.case_study;
  const prev = data.prev_slug;
  const next = data.next_slug;

  // Filter visible sections to those with content
  const visibleSections = SECTION_DEFS.filter((s) => {
    if (s.id === 'overview') return true;
    if (s.id === 'gallery') return Array.isArray(cs.gallery) && cs.gallery.length;
    if (s.id === 'tech') return Array.isArray(cs.tech_stack) && cs.tech_stack.length;
    if (s.id === 'challenge') return Array.isArray(cs.challenges) && cs.challenges.length;
    if (s.id === 'solution') return Array.isArray(cs.solution) && cs.solution.length;
    if (s.id === 'results') return !!cs.results;
    return false;
  });

  // Related = other visible case studies, max 3
  const related = (listData?.collections?.caseStudies || [])
    .filter((c) => c.slug && c.slug !== slug)
    .slice(0, 3);

  // 16px breathing room below the sticky track when an anchor jump lands
  const scrollOffset = navH + trackH + 16;
  const sectionStyle = { scrollMarginTop: `${scrollOffset}px` };

  return (
    <>
      <EditorialHero cs={cs} prev={prev} next={next} navigate={navigate} reducedMotion={reducedMotion} navH={navH} />

      <LeftProgressRail sections={visibleSections} navH={navH} trackH={trackH} trackRef={trackRef} />

      {/* ─── Overview / Clients Vision (centered editorial pull-quote) ──── */}
      <section id="overview" style={sectionStyle} className="py-16 sm:py-20 bg-white">
        <div className="container mx-auto max-w-5xl">
          <SectionEyebrow eyebrow="Overview" title="The client's vision" />
          {cs.clients_vision && (
            <motion.blockquote
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={viewportOnce}
              transition={{ duration: 0.65, ease: EASE }}
              data-testid="cs-clients-vision"
              className="relative mt-10 text-center px-6 sm:px-16"
            >
              <span
                aria-hidden="true"
                className="absolute -top-6 left-1/2 -translate-x-1/2 text-[120px] sm:text-[150px] leading-none font-serif text-[#C9962E]/25 select-none pointer-events-none"
              >
                &ldquo;
              </span>
              <p className="relative text-xl sm:text-2xl font-medium tracking-tight text-navy-deep leading-relaxed max-w-3xl mx-auto">
                {cs.clients_vision}
              </p>
              <footer className="mt-8 text-xs sm:text-sm font-semibold tracking-[0.2em] uppercase text-brandblue">
                — Client&rsquo;s Vision
              </footer>
            </motion.blockquote>
          )}
        </div>
      </section>

      {/* ─── At a glance metrics ─────────────────────────────────────────── */}
      <AtAGlance cs={cs} />

      {/* ─── Gallery (App Store style snap scroll) ───────────────────────── */}
      {Array.isArray(cs.gallery) && cs.gallery.length > 0 && (
        <section id="gallery" style={sectionStyle} className="py-16 sm:py-20 bg-white">
          <div className="container mx-auto">
            <SectionEyebrow eyebrow="Gallery" title="Project Gallery" subtitle="A closer look at the build — drag the strip below to explore." />
          </div>
          <div className="mt-12">
            <SnapGallery images={cs.gallery} title={cs.title} />
          </div>
        </section>
      )}

      {/* ─── Technology Stack ────────────────────────────────────────────── */}
      {Array.isArray(cs.tech_stack) && cs.tech_stack.length > 0 && (
        <section id="tech" style={sectionStyle} className="py-16 sm:py-20 bg-sky-50">
          <div className="container mx-auto">
            <SectionEyebrow eyebrow="Tech Stack" title="Technology Stack" subtitle="The battle-tested tools we used to ship this work." />
            <div className="mt-12 flex flex-wrap items-center justify-center gap-6" data-testid="cs-tech-stack">
              {cs.tech_stack.map((t, i) => (
                <motion.div
                  key={t.name + i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={viewportOnce}
                  transition={{ duration: 0.55, delay: i * 0.05, ease: EASE }}
                  whileHover={{ y: -6, scale: 1.04 }}
                  className="will-change-transform"
                >
                  <motion.div
                    animate={reducedMotion ? {} : { y: [0, -3, 0] }}
                    transition={reducedMotion ? {} : { duration: 4, repeat: Infinity, ease: 'easeInOut', delay: i * 0.3 }}
                    className="group h-28 w-28 rounded-full bg-white shadow-[0_10px_24px_rgba(31,45,69,0.08)] border border-hairline flex flex-col items-center justify-center transition-shadow hover:shadow-[0_16px_32px_rgba(31,45,69,0.14)]"
                    title={t.name}
                  >
                  {t.icon_url ? (
                    <img
                      src={t.icon_url}
                      alt={t.name}
                      loading="lazy"
                      className="h-11 w-11 object-contain grayscale group-hover:grayscale-0 transition-all duration-300"
                    />
                  ) : (
                    <span className="text-xs font-semibold text-navy">{t.name}</span>
                  )}
                  <span className="mt-1.5 text-[10px] font-semibold tracking-wide text-navy/70 opacity-0 group-hover:opacity-100 transition-opacity">
                    {t.name}
                  </span>
                  </motion.div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ─── Challenges (sticky left, scrolling right) ──────────────────── */}
      {Array.isArray(cs.challenges) && cs.challenges.length > 0 && (
        <ChallengeSolutionBlock id="challenge" testId="cs-challenges" eyebrow="The Challenges" heading="Challenges" subtitle="What we needed to solve before we could ship." items={cs.challenges} accent sectionStyle={sectionStyle} />
      )}

      {/* ─── Solution ────────────────────────────────────────────────────── */}
      {Array.isArray(cs.solution) && cs.solution.length > 0 && (
        <ChallengeSolutionBlock id="solution" testId="cs-solution" eyebrow="The Solution" heading="Solution" subtitle="How we built it." items={cs.solution} sectionStyle={sectionStyle} />
      )}

      {/* ─── Results — distinct full-width navy panel with stat cards ──── */}
      {cs.results && (
        <ResultsPanel cs={cs} sectionStyle={sectionStyle} />
      )}

      {/* ─── Related case studies ───────────────────────────────────────── */}
      {related.length > 0 && (
        <section className="py-16 sm:py-20 bg-white">
          <div className="container mx-auto">
            <SectionEyebrow eyebrow="More Work" title="More Case Studies" />
            <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-6" data-testid="cs-related">
              {related.map((r, i) => (
                <motion.div
                  key={r.slug}
                  initial={{ opacity: 0, y: 22 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={viewportOnce}
                  transition={{ duration: 0.55, delay: i * 0.07, ease: EASE }}
                >
                  <Link
                    to={`/case-studies/${r.slug}`}
                    className="group block rounded-2xl overflow-hidden bg-white border border-hairline shadow-[0_10px_28px_rgba(31,45,69,0.08)] hover:shadow-[0_18px_36px_rgba(31,45,69,0.14)] transition-shadow"
                  >
                    <div className="relative aspect-[16/10] overflow-hidden bg-sky-100">
                      {r.img ? (
                        <img src={r.img} alt={r.title} loading="lazy" className="w-full h-full object-cover transition-transform duration-[900ms] group-hover:scale-[1.06] will-change-transform" />
                      ) : (
                        <div aria-hidden="true" className="absolute inset-0" style={{ background: 'linear-gradient(135deg, #E6F1FB 0%, #C9DCEF 55%, #E8C25A20 100%)' }} />
                      )}
                    </div>
                    <div className="p-6">
                      <p className="text-[11px] font-bold tracking-[0.2em] uppercase text-brandblue">{r.category || 'Case Study'}</p>
                      <h4 className="mt-3 text-[15px] font-semibold tracking-tight text-navy-deep leading-snug line-clamp-2 group-hover:text-[#C9962E] transition-colors">{r.title}</h4>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      <CtaBand data={data.sections?.cta?.data} />
    </>
  );
}

/* ─── Editorial stacked hero (no full-bleed image) ──────────────────────── */

function EditorialHero({ cs, prev, next, navigate, reducedMotion, navH = 160 }) {
  // Parse year from cs.date if present (e.g. "September 14, 2023" → "2023")
  const year = (() => {
    const m = (cs.date || '').match(/\b(20\d{2})\b/);
    return m ? m[1] : '';
  })();
  // Derive a short "services" tag from tech_stack count if not present
  const servicesLabel = Array.isArray(cs.tech_stack) && cs.tech_stack.length
    ? `${cs.tech_stack.length} Technologies`
    : 'Engineering · Product';

  // Split metric into number + label fragment for the giant outcome display
  const metricParts = (() => {
    const m = (cs.metric || '').match(/([+−\-]?\d[\d.,]*\s*[%×x+]?)\s*(.*)/);
    if (!m) return null;
    return { value: m[1], rest: (m[2] || '').trim() };
  })();

  return (
    <section
      data-testid="cs-hero"
      style={{ paddingTop: `${navH + 40}px` }}
      className="relative bg-white border-b border-hairline pb-12 sm:pb-14 overflow-hidden"
    >
      {/* Soft gradient accent backdrop */}
      <div
        aria-hidden="true"
        className="absolute inset-0 pointer-events-none opacity-70"
        style={{
          background:
            'radial-gradient(900px 480px at 12% 18%, rgba(47,111,176,0.10), transparent 65%), radial-gradient(720px 400px at 88% 90%, rgba(232,194,90,0.10), transparent 70%)',
        }}
      />
      <div className="relative container mx-auto">
        <Link
          to="/case-studies"
          data-testid="cs-back-link"
          className="inline-flex items-center gap-1 text-[11px] tracking-[0.18em] uppercase font-bold text-slatebody hover:text-navy-deep transition-colors mb-10"
        >
          <ChevronLeft className="h-4 w-4" /> Back to Case Studies
        </Link>

        <div className="text-center max-w-4xl mx-auto">
          {/* Thin meta bar */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: EASE }}
            className="flex flex-wrap items-center justify-center gap-x-7 gap-y-3 text-[10.5px] font-bold tracking-[0.24em] uppercase text-slatebody/80"
          >
            <MetaPill>{cs.brand || 'Client'}</MetaPill>
            <Dot />
            <MetaPill>{cs.category || 'Industry'}</MetaPill>
            {year && (
              <>
                <Dot />
                <MetaPill>{year}</MetaPill>
              </>
            )}
            <Dot />
            <MetaPill>{servicesLabel}</MetaPill>
          </motion.div>

          {/* Oversized display headline */}
          <div className="mt-7 overflow-hidden">
            <motion.h1
              data-testid="cs-detail-title"
              initial={reducedMotion ? { y: 0, opacity: 1 } : { y: '110%', opacity: 0.001 }}
              animate={{ y: '0%', opacity: 1 }}
              transition={{ duration: 0.7, delay: 0.05, ease: EASE }}
              className="text-3xl sm:text-5xl lg:text-[3.4rem] xl:text-[3.6rem] font-bold tracking-[-0.015em] text-navy-deep leading-[1.08] will-change-transform"
            >
              {cs.title}
            </motion.h1>
          </div>

          {/* Byline */}
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.35, ease: EASE }}
            className="mt-5 text-[12px] tracking-[0.22em] uppercase font-bold text-slatebody/70"
          >
            {cs.date && <span>{cs.date}</span>}
            {cs.date && cs.read_time && <span className="mx-3 text-slatebody/40">/</span>}
            {cs.read_time && <span>{cs.read_time}</span>}
          </motion.p>

          {/* Centered outcome metric */}
          {metricParts && (
            <motion.div
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.45, ease: EASE }}
              data-testid="cs-hero-outcome"
              className="mt-10"
            >
              <p className="text-[10px] font-bold tracking-[0.24em] uppercase text-[#C9962E] mb-2">Outcome</p>
              <div className="flex items-end justify-center gap-5 flex-wrap">
                <span
                  className="block text-[3.5rem] sm:text-[5rem] lg:text-[5.5rem] font-bold tracking-[-0.03em] leading-[0.9] text-transparent bg-clip-text"
                  style={{ backgroundImage: 'linear-gradient(135deg, #1F4373 0%, #2F6FB0 50%, #C9962E 100%)' }}
                >
                  <MetricCountUp value={metricParts.value} />
                </span>
                {metricParts.rest && (
                  <p className="pb-2 text-sm sm:text-base font-semibold text-navy-deep/80 leading-snug max-w-[18ch] text-left">
                    {metricParts.rest}
                  </p>
                )}
              </div>
            </motion.div>
          )}

          {/* Prev / next — centered under outcome */}
          <div className="mt-10 hidden sm:flex items-center justify-center gap-3">
            <MagneticNavButton
              testId="cs-prev"
              label="Previous case study"
              disabled={!prev}
              onClick={() => prev && navigate(`/case-studies/${prev}`)}
              reducedMotion={reducedMotion}
              dark
            >
              <ChevronLeft className="h-5 w-5" />
            </MagneticNavButton>
            <MagneticNavButton
              testId="cs-next"
              label="Next case study"
              disabled={!next}
              onClick={() => next && navigate(`/case-studies/${next}`)}
              reducedMotion={reducedMotion}
              dark
            >
              <ChevronRight className="h-5 w-5" />
            </MagneticNavButton>
          </div>
        </div>

        {/* Inline framed editorial image (supporting, not dominating) */}
        {cs.img && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.55, ease: EASE }}
            className="mt-14 rounded-2xl overflow-hidden border border-hairline shadow-[0_24px_60px_rgba(15,25,45,0.14)] max-w-[1100px] mx-auto"
          >
            <div className="aspect-[21/9] bg-navy-deep">
              <img
                src={cs.img}
                alt={cs.title}
                loading="eager"
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>
        )}
      </div>
    </section>
  );
}

/* ─── Reusable centered section eyebrow + title + gold divider ─────────── */

function SectionEyebrow({ eyebrow, title, subtitle }) {
  return (
    <div className="text-center max-w-2xl mx-auto">
      <motion.p
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: EASE }}
        className="text-xs sm:text-sm font-semibold tracking-[0.2em] uppercase text-brandblue"
      >
        {eyebrow}
      </motion.p>
      <motion.h2
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.55, delay: 0.05, ease: EASE }}
        className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-navy-deep leading-[1.05]"
      >
        {title}
      </motion.h2>
      <motion.span
        initial={{ scaleX: 0 }}
        whileInView={{ scaleX: 1 }}
        viewport={{ once: true, amount: 0 }}
        transition={{ duration: 0.7, delay: 0.15, ease: EASE }}
        style={{ transformOrigin: 'center' }}
        className="mx-auto mt-5 block h-[2px] w-16 rounded-full bg-gradient-to-r from-[#2BA8E0] via-[#2F6FB0] to-[#E8C25A]"
      />
      {subtitle && (
        <motion.p
          initial={{ opacity: 0, y: 8 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0 }}
          transition={{ duration: 0.55, delay: 0.2, ease: EASE }}
          className="mt-5 text-base sm:text-lg text-slatebody leading-relaxed"
        >
          {subtitle}
        </motion.p>
      )}
    </div>
  );
}

function MetaPill({ children }) {
  return <span className="text-slatebody/80">{children}</span>;
}
function Dot() {
  return <span aria-hidden="true" className="h-1 w-1 rounded-full bg-slatebody/35" />;
}

/* ─── Magnetic nav button (reuses brand magnetic logic) ────────────────── */

function MagneticNavButton({ children, testId, label, onClick, disabled, reducedMotion, dark = false }) {
  const btnRef = useRef(null);
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const x = useSpring(mx, { stiffness: 220, damping: 18, mass: 0.5 });
  const y = useSpring(my, { stiffness: 220, damping: 18, mass: 0.5 });

  const onMove = (e) => {
    if (disabled || reducedMotion) return;
    const r = btnRef.current?.getBoundingClientRect?.();
    if (!r) return;
    const px = e.clientX - (r.left + r.width / 2);
    const py = e.clientY - (r.top + r.height / 2);
    mx.set(Math.max(-7, Math.min(7, px * 0.22)));
    my.set(Math.max(-5, Math.min(5, py * 0.22)));
  };
  const onLeave = () => { mx.set(0); my.set(0); };

  return (
    <motion.button
      ref={btnRef}
      style={{ x, y }}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      whileTap={disabled ? {} : { scale: 0.92 }}
      transition={{ type: 'spring', stiffness: 360, damping: 22 }}
      data-testid={testId}
      aria-label={label}
      disabled={disabled}
      onClick={onClick}
      className={
        dark
          ? 'h-12 w-12 rounded-full bg-sky-50 border border-hairline text-navy-deep inline-flex items-center justify-center disabled:opacity-30 disabled:cursor-not-allowed hover:bg-navy-deep hover:text-white transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/70'
          : 'h-12 w-12 rounded-full bg-white/15 backdrop-blur text-white inline-flex items-center justify-center disabled:opacity-30 disabled:cursor-not-allowed hover:bg-white hover:text-navy-deep transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#E8C25A]/70'
      }
    >
      {children}
    </motion.button>
  );
}

/* ─── Sticky TOP centered progress track (editorial signature) ──────────── */

function LeftProgressRail({ sections, navH = 160, trackH = 52, trackRef }) {
  // Despite the legacy name kept for testids, this is now a top horizontal
  // centered progress track — looks balanced and doesn't compete with content.
  const [active, setActive] = useState(sections[0]?.id);
  const [scrollPct, setScrollPct] = useState(0);

  useEffect(() => {
    const observers = sections.map((s) => {
      const el = document.getElementById(s.id);
      if (!el) return null;
      const io = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) setActive(s.id);
        },
        { rootMargin: '-30% 0px -55% 0px', threshold: 0 }
      );
      io.observe(el);
      return io;
    });
    return () => observers.forEach((io) => io && io.disconnect());
  }, [sections]);

  useEffect(() => {
    const onScroll = () => {
      const doc = document.documentElement;
      const max = doc.scrollHeight - doc.clientHeight;
      setScrollPct(max > 0 ? doc.scrollTop / max : 0);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const goTo = (e, id) => {
    e.preventDefault();
    const el = document.getElementById(id);
    if (!el) return;
    const top = el.getBoundingClientRect().top + window.scrollY - (navH + trackH + 16);
    window.scrollTo({ top, behavior: 'smooth' });
  };

  return (
    <nav
      ref={trackRef}
      aria-label="Section navigation"
      data-testid="cs-scrollspy"
      style={{ top: `${navH}px` }}
      className="hidden md:block sticky z-30 pointer-events-none mb-2"
    >
      <div className="container mx-auto flex justify-center">
        <div className="pointer-events-auto relative inline-flex items-center gap-1 sm:gap-2 px-3 sm:px-4 py-2 rounded-full bg-white/90 backdrop-blur-md ring-1 ring-hairline shadow-[0_10px_28px_rgba(15,25,45,0.08)] overflow-hidden">
          {/* Scroll-progress fill running behind the labels */}
          <span
            aria-hidden="true"
            className="absolute inset-y-0 left-0 transition-[width] duration-200 ease-out"
            style={{
              width: `${Math.round(scrollPct * 100)}%`,
              background:
                'linear-gradient(90deg, rgba(232,194,90,0.18) 0%, rgba(201,150,46,0.18) 60%, transparent 100%)',
            }}
          />
          {sections.map((s) => {
            const isActive = active === s.id;
            return (
              <a
                key={s.id}
                href={`#${s.id}`}
                onClick={(e) => goTo(e, s.id)}
                data-testid={`cs-spy-${s.id}`}
                className="relative isolate inline-flex items-center px-3 sm:px-4 py-1.5 rounded-full text-[10.5px] sm:text-[11px] tracking-[0.18em] uppercase font-bold transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60"
              >
                {isActive && (
                  <motion.span
                    layoutId="cs-spy-pill"
                    transition={{ type: 'spring', stiffness: 380, damping: 32 }}
                    className="absolute inset-0 rounded-full bg-navy-deep shadow-[0_6px_16px_rgba(15,25,45,0.25)] -z-10"
                  />
                )}
                <span className={isActive ? 'text-white' : 'text-navy/60 hover:text-navy-deep'}>{s.label}</span>
              </a>
            );
          })}
        </div>
      </div>
    </nav>
  );
}

/* ─── At-a-glance metrics ───────────────────────────────────────────────── */

function AtAGlance({ cs }) {
  // Derive 3-4 stats from the case study (metric + counts of items)
  const stats = useMemo(() => {
    const items = [];
    if (cs.metric) items.push({ value: cs.metric, label: 'Outcome' });
    if (cs.tech_stack?.length) items.push({ value: `${cs.tech_stack.length}+`, label: 'Technologies' });
    if (cs.challenges?.length) items.push({ value: `${cs.challenges.length}`, label: 'Key Challenges' });
    if (cs.solution?.length) items.push({ value: `${cs.solution.length}`, label: 'Solution Pillars' });
    return items.slice(0, 4);
  }, [cs]);

  if (!stats.length) return null;
  return (
    <section className="py-12 sm:py-16 bg-sky-50/40 border-y border-hairline" data-testid="cs-at-a-glance">
      <div className="container mx-auto">
        <SectionEyebrow eyebrow="At a glance" title="The project in numbers" />
        <div className="mt-10 grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((s, i) => (
            <motion.div
              key={s.label + i}
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={viewportOnce}
              transition={{ duration: 0.55, delay: i * 0.06, ease: EASE }}
              className="text-center"
            >
              <div className="text-4xl sm:text-5xl font-bold tracking-tight text-navy-deep leading-none">
                <MetricCountUp value={s.value} />
              </div>
              <p className="mt-3 text-[11px] font-bold tracking-[0.22em] uppercase text-slatebody/80">{s.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── Challenge / Solution block (centered header + numbered cards) ────── */

function ChallengeSolutionBlock({ id, testId, eyebrow, heading, subtitle, items, accent = false, sectionStyle }) {
  return (
    <section
      id={id}
      data-testid={testId}
      style={sectionStyle}
      className={`py-16 sm:py-20 ${accent ? 'bg-sky-50' : 'bg-white'}`}
    >
      <div className="container mx-auto">
        <SectionEyebrow eyebrow={eyebrow} title={heading || eyebrow.replace(/^The\s+/i, '')} subtitle={subtitle} />
        <div className="mt-12 relative max-w-3xl mx-auto">
          {/* Vertical connector line behind the numbers */}
          <div
            aria-hidden="true"
            className="absolute left-[19px] top-4 bottom-4 w-px"
            style={{ background: 'linear-gradient(to bottom, #C9962E22 0%, #1F437333 50%, #C9962E11 100%)' }}
          />
          <ul className="space-y-8">
            {items.map((it, i) => (
              <motion.li
                key={(it.title || '') + i}
                initial={{ opacity: 0, y: 28 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={viewportOnce}
                transition={{ duration: 0.6, delay: i * 0.07, ease: EASE }}
                className="relative flex gap-6 pl-0"
              >
                <span className={`relative z-10 shrink-0 h-10 w-10 rounded-full bg-navy-deep text-white inline-flex items-center justify-center text-[12px] font-bold tracking-[0.06em] ring-4 ${accent ? 'ring-sky-50' : 'ring-white'}`}>
                  {String(i + 1).padStart(2, '0')}
                </span>
                <div className="flex-1 pb-2">
                  <h4 className="text-xl font-bold tracking-tight text-navy-deep leading-snug">{it.title}</h4>
                  <p className="mt-2.5 text-slatebody text-base sm:text-lg leading-relaxed">{it.desc}</p>
                </div>
              </motion.li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}

/* ─── Results — distinct deep-navy full-width panel + count-up stat cards ─ */

function ResultsPanel({ cs, sectionStyle }) {
  // Derive 3 outcome stats from the case study
  const stats = useMemo(() => {
    const items = [];
    if (cs.metric) items.push({ value: cs.metric, label: 'Headline Outcome' });
    if (cs.tech_stack?.length) items.push({ value: `${cs.tech_stack.length}+`, label: 'Technologies Shipped' });
    if (cs.solution?.length) items.push({ value: `${cs.solution.length}`, label: 'Solution Pillars' });
    if (cs.challenges?.length) items.push({ value: `${cs.challenges.length}`, label: 'Key Challenges' });
    return items.slice(0, 3);
  }, [cs]);

  return (
    <section
      id="results"
      data-testid="cs-results"
      className="relative py-16 sm:py-20 overflow-hidden"
      style={{ ...(sectionStyle || {}), background: 'radial-gradient(900px 600px at 80% 10%, rgba(232,194,90,0.18), transparent 60%), linear-gradient(180deg, #0F192D 0%, #1F4373 100%)' }}
    >
      <div
        aria-hidden="true"
        className="absolute -top-32 -left-40 h-[460px] w-[460px] rounded-full blur-3xl"
        style={{ background: 'radial-gradient(circle, rgba(47,111,176,0.35), transparent 65%)' }}
      />
      <div className="relative container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={viewportOnce}
          transition={{ duration: 0.65, ease: EASE }}
          className="text-center max-w-3xl mx-auto"
        >
          <p className="text-xs sm:text-sm font-semibold tracking-[0.2em] uppercase text-[#E8C25A]">Results</p>
          <h3 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white leading-[1.05] drop-shadow-[0_2px_4px_rgba(0,0,0,0.4)]">
            Outcomes that matter.
          </h3>
          <span
            aria-hidden="true"
            className="mx-auto mt-5 block h-[2px] w-16 rounded-full bg-gradient-to-r from-[#C9962E] to-[#E8C25A]"
          />
          <p className="mt-6 text-white/90 text-base sm:text-lg leading-relaxed">
            {cs.results}
          </p>
        </motion.div>

        {stats.length > 0 && (
          <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {stats.map((s, i) => (
              <motion.div
                key={s.label + i}
                initial={{ opacity: 0, y: 22 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={viewportOnce}
                transition={{ duration: 0.55, delay: i * 0.08, ease: EASE }}
                className="relative rounded-2xl bg-white/8 backdrop-blur-md ring-1 ring-white/15 p-8 overflow-hidden text-center"
              >
                <span
                  aria-hidden="true"
                  className="absolute -top-px left-6 right-6 h-[2px] rounded-full bg-gradient-to-r from-transparent via-[#E8C25A] to-transparent"
                />
                <div className="text-5xl sm:text-6xl font-bold tracking-[-0.02em] leading-none text-transparent bg-clip-text"
                  style={{ backgroundImage: 'linear-gradient(135deg, #FFFFFF 0%, #E8C25A 100%)' }}
                >
                  <MetricCountUp value={s.value} />
                </div>
                <p className="mt-5 text-[11px] font-bold tracking-[0.22em] uppercase text-white/75">{s.label}</p>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

/* ─── Snap-scroll gallery (App Store style) — drag with momentum ────────── */

function SnapGallery({ images, title }) {
  const scrollerRef = useRef(null);
  const reducedMotion = useReducedMotion();
  const dragState = useRef({ active: false, startX: 0, startScroll: 0, lastX: 0, lastT: 0, vx: 0 });
  const [grabbing, setGrabbing] = useState(false);

  const onPointerDown = (e) => {
    if (reducedMotion) return;
    const el = scrollerRef.current;
    if (!el) return;
    dragState.current = {
      active: true,
      startX: e.clientX,
      startScroll: el.scrollLeft,
      lastX: e.clientX,
      lastT: performance.now(),
      vx: 0,
    };
    setGrabbing(true);
    el.setPointerCapture?.(e.pointerId);
  };

  const onPointerMove = (e) => {
    const st = dragState.current;
    if (!st.active) return;
    const el = scrollerRef.current;
    if (!el) return;
    const dx = e.clientX - st.startX;
    // Minimum drag threshold — avoid tap-drift / accidental momentum on click
    if (Math.abs(dx) < 4) return;
    el.scrollLeft = st.startScroll - dx;
    const now = performance.now();
    const dt = Math.max(1, now - st.lastT);
    st.vx = (e.clientX - st.lastX) / dt; // px/ms
    st.lastX = e.clientX;
    st.lastT = now;
  };

  const onPointerUp = () => {
    const st = dragState.current;
    if (!st.active) return;
    st.active = false;
    setGrabbing(false);
    // Momentum: decelerate scroll using vx for ~450ms (eased)
    const el = scrollerRef.current;
    if (!el || reducedMotion) return;
    let v = -st.vx * 18; // tune magnitude → felt as a flick
    if (Math.abs(v) < 0.5) return;
    let last = performance.now();
    const tick = (now) => {
      const dt = now - last;
      last = now;
      el.scrollLeft += v * (dt / 16);
      v *= 0.92; // ease-out
      if (Math.abs(v) > 0.3) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  };

  return (
    <div
      ref={scrollerRef}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={onPointerUp}
      className={`overflow-x-auto snap-x snap-mandatory no-scrollbar pb-4 select-none ${grabbing ? 'cursor-grabbing' : 'cursor-grab'}`}
      data-testid="cs-gallery"
      style={{ willChange: 'scroll-position' }}
    >
      <div className="container mx-auto flex gap-5 sm:gap-7">
        {images.map((src, i) => (
          <motion.figure
            key={src + i}
            initial={{ opacity: 0, scale: 0.97, y: 18 }}
            whileInView={{ opacity: 1, scale: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.6, delay: i * 0.07, ease: EASE }}
            whileHover={{ y: -4 }}
            className="group snap-start shrink-0 w-[78vw] sm:w-[480px] lg:w-[640px] rounded-2xl overflow-hidden border border-hairline shadow-[0_14px_38px_rgba(31,45,69,0.10)] hover:shadow-[0_22px_50px_rgba(31,45,69,0.16)] transition-shadow"
          >
            <div className="relative aspect-[16/10] overflow-hidden bg-navy-deep">
              <img
                src={src}
                alt={`${title} screenshot ${i + 1}`}
                loading="lazy"
                draggable={false}
                className="w-full h-full object-cover transition-transform duration-[1.1s] ease-out group-hover:scale-[1.04] will-change-transform pointer-events-none"
              />
            </div>
          </motion.figure>
        ))}
        {/* Trailing spacer so the last card can fully snap */}
        <div className="shrink-0 w-4" aria-hidden="true" />
      </div>
    </div>
  );
}
