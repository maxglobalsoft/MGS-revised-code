import React, { useMemo, useState } from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { MapPin, Briefcase, ArrowRight, Search } from 'lucide-react';

import SectionHeading from '@/components/brand/SectionHeading';
import ApplyJobModal from '@/components/brand/ApplyJobModal';
import CtaBand from '@/components/sections/CtaBand';
import { viewportOnce } from '@/lib/motion';
import { useCareerData } from '@/hooks/useCareerData';

const EASE = [0.22, 1, 0.36, 1];

const FALLBACK = {
  sections: {
    careerHeader: { data: { kicker: 'Career', heading: 'We have 0 open positions now!' } },
    careerNote: {
      data: {
        text: "We're always seeking talented people. If you can't find your role here, send us your LinkedIn profile and contact details — we'll be in touch.",
        cta_label: "Let's Connect",
        cta_to: '/contact',
      },
    },
  },
  collections: { jobs: [] },
};

const ALL = '__all__';

export default function Career() {
  const { data, loading } = useCareerData();
  const reducedMotion = useReducedMotion();

  const payload = data || FALLBACK;
  const header = payload.sections?.careerHeader?.data || FALLBACK.sections.careerHeader.data;
  const note = payload.sections?.careerNote?.data || FALLBACK.sections.careerNote.data;
  const jobs = payload.collections?.jobs || [];

  // Build category list with counts
  const categories = useMemo(() => {
    const map = new Map();
    jobs.forEach((j) => {
      const key = j.category || 'Other';
      map.set(key, (map.get(key) || 0) + 1);
    });
    return [
      { key: ALL, label: 'All positions', count: jobs.length },
      ...Array.from(map.entries())
        .sort((a, b) => a[0].localeCompare(b[0]))
        .map(([k, c]) => ({ key: k, label: k, count: c })),
    ];
  }, [jobs]);

  const [activeCat, setActiveCat] = useState(ALL);
  const [applyJob, setApplyJob] = useState(null);
  const visibleJobs = useMemo(
    () => (activeCat === ALL ? jobs : jobs.filter((j) => (j.category || 'Other') === activeCat)),
    [jobs, activeCat]
  );

  // Replace {N} client-side if the backend didn't (static fallback case)
  const headingText = (header.heading || '').replace('{N}', String(jobs.length));

  return (
    <>
      {/* ─── Header ─────────────────────────────────────────────────── */}
      <section className="relative pt-36 pb-16 sm:pt-44 sm:pb-20 overflow-hidden bg-sky-50">
        <div
          aria-hidden="true"
          className="absolute inset-0 opacity-70 pointer-events-none"
          style={{
            background:
              'radial-gradient(700px 400px at 12% 18%, rgba(47,111,176,0.10), transparent 65%), radial-gradient(560px 320px at 88% 90%, rgba(232,194,90,0.10), transparent 70%)',
          }}
        />
        <div className="relative container mx-auto" data-testid="career-header">
          <SectionHeading
            eyebrow={header.kicker || 'Career'}
            title={headingText}
            subtitle="Join a team that ships AI-first products with care, craft and consistency."
            align="center"
          />
        </div>
      </section>

      {/* ─── Two-column body ────────────────────────────────────────── */}
      <section className="py-16 sm:py-20 bg-white">
        <div className="container mx-auto">
          <div className="grid lg:grid-cols-[280px_1fr] gap-10 lg:gap-14">
            {/* Left rail: category filter + note */}
            <aside className="lg:sticky lg:top-32 lg:self-start" data-testid="career-sidebar">
              <p className="text-xs sm:text-sm font-semibold tracking-[0.2em] uppercase text-brandblue mb-4">
                Filter by team
              </p>
              <ul className="space-y-1.5" role="listbox" aria-label="Job categories">
                {categories.map((c) => {
                  const isActive = activeCat === c.key;
                  return (
                    <li key={c.key}>
                      <button
                        type="button"
                        onClick={() => setActiveCat(c.key)}
                        data-testid={`career-filter-${c.key === ALL ? 'all' : c.key.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`}
                        aria-pressed={isActive}
                        className={`group w-full flex items-center justify-between gap-3 rounded-xl px-3.5 py-2.5 text-left transition-all ${
                          isActive
                            ? 'bg-navy-deep text-white shadow-[0_8px_22px_rgba(15,25,45,0.18)]'
                            : 'bg-transparent text-navy-deep hover:bg-sky-50'
                        }`}
                      >
                        <span className="text-base sm:text-[15px] font-semibold tracking-tight">{c.label}</span>
                        <span
                          className={`text-xs font-bold tracking-[0.1em] px-2 py-0.5 rounded-full ${
                            isActive ? 'bg-[#E8C25A]/95 text-navy-deep' : 'bg-sky-100 text-navy-deep/70'
                          }`}
                        >
                          {c.count}
                        </span>
                      </button>
                    </li>
                  );
                })}
              </ul>

              <div className="mt-10 rounded-2xl bg-sky-50 border border-hairline p-6">
                <p className="text-base sm:text-lg text-navy-deep leading-relaxed">{note.text}</p>
                <Link
                  to={note.cta_to || '/contact'}
                  data-testid="career-connect-btn"
                  className="group mt-5 inline-flex items-center gap-1.5 rounded-full px-6 py-3 text-sm font-semibold text-white bg-gold-gradient shadow-gold hover:shadow-[0_18px_44px_rgba(201,150,46,0.5)] transition-shadow focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60"
                >
                  {note.cta_label || "Let's Connect"}
                  <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
                </Link>
              </div>
            </aside>

            {/* Right: job list */}
            <div data-testid="career-job-list">
              {loading && (
                <p className="text-sm text-slatebody">Loading roles…</p>
              )}

              {!loading && visibleJobs.length === 0 && (
                <div
                  data-testid="career-empty-state"
                  className="rounded-2xl border border-dashed border-hairline bg-sky-50/60 p-10 text-center"
                >
                  <Search className="mx-auto h-8 w-8 text-slatebody/60" />
                  <h3 className="mt-4 text-2xl sm:text-3xl font-bold tracking-tight text-navy-deep">
                    No openings right now
                  </h3>
                  <p className="mt-3 text-base sm:text-lg text-slatebody leading-relaxed">
                    We&rsquo;re not currently hiring in this team. Drop us a line and we&rsquo;ll let you
                    know when something opens up.
                  </p>
                  <Link
                    to="/contact"
                    data-testid="career-empty-cta"
                    className="group mt-6 inline-flex items-center gap-1.5 rounded-full px-6 py-3 text-sm font-semibold text-white bg-gold-gradient shadow-gold hover:shadow-[0_18px_44px_rgba(201,150,46,0.5)] transition-shadow focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60"
                  >
                    Write to us
                    <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
                  </Link>
                </div>
              )}

              <AnimatePresence mode="popLayout">
                {visibleJobs.map((j, i) => (
                  <motion.article
                    layout={!reducedMotion}
                    key={j.id || j.title + i}
                    initial={{ opacity: 0, y: 18 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={viewportOnce}
                    transition={{ duration: 0.45, delay: i * 0.05, ease: EASE }}
                    className="group relative rounded-2xl bg-white border border-hairline shadow-card hover:shadow-soft transition-shadow p-6 sm:p-7 mb-5"
                    data-testid={`career-job-card-${i}`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-xs sm:text-sm font-semibold tracking-[0.2em] uppercase text-brandblue">
                            {j.category}
                          </span>
                        </div>
                        <h3 className="text-2xl sm:text-3xl font-bold tracking-tight text-navy-deep leading-[1.12] group-hover:text-[#C9962E] transition-colors">
                          {j.title}
                        </h3>
                        <div className="mt-3 flex flex-wrap items-center gap-2" data-testid={`career-job-tags-${i}`}>
                          {j.location && (
                            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-50 border border-hairline text-xs sm:text-sm font-semibold text-navy-deep">
                              <MapPin className="h-3.5 w-3.5 text-brandblue" /> {j.location}
                            </span>
                          )}
                          {j.type && (
                            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-50 border border-hairline text-xs sm:text-sm font-semibold text-navy-deep">
                              <Briefcase className="h-3.5 w-3.5 text-brandblue" /> {j.type}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    {j.description && (
                      <p className="mt-5 text-base sm:text-lg text-slatebody leading-relaxed">
                        {j.description}
                      </p>
                    )}
                    <div className="mt-6">
                      <button
                        type="button"
                        onClick={() => setApplyJob(j)}
                        className="group inline-flex items-center gap-1 px-5 py-2.5 rounded-full bg-navy-deep text-white text-sm font-semibold tracking-tight hover:bg-[#0F192D] transition-colors shadow-[0_10px_24px_rgba(15,25,45,0.18)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60"
                        data-testid={`career-apply-${i}`}
                      >
                        Apply
                        <ArrowRight className="h-4 w-4 ml-1 transition-transform duration-300 group-hover:translate-x-1" />
                      </button>
                    </div>
                  </motion.article>
                ))}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </section>

      <CtaBand />

      <ApplyJobModal job={applyJob} onClose={() => setApplyJob(null)} />
    </>
  );
}
