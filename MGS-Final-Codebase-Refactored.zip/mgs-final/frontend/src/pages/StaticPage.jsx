import React, { useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChevronLeft, Loader2 } from 'lucide-react';

import NotFound from '@/pages/NotFound';
import { useStaticPage } from '@/hooks/useStaticPage';

const EASE = [0.22, 1, 0.36, 1];

function formatUpdated(iso) {
  if (!iso) return '';
  try {
    return new Date(iso).toLocaleDateString('en-GB', {
      day: 'numeric', month: 'long', year: 'numeric',
    });
  } catch {
    return '';
  }
}

/**
 * Generic admin-managed static text page. Mounted at /p/:slug.
 * Reads the `pages` collection via GET /api/pages/{slug}.
 * Invalid / hidden slugs → NotFound.
 */
export default function StaticPage() {
  const { slug } = useParams();
  const { data, loading, notFound } = useStaticPage(slug);

  // Set per-page document.title + description from the doc's metaTitle/metaDescription.
  useEffect(() => {
    if (!data) return;
    if (data.metaTitle) document.title = data.metaTitle;
    if (data.metaDescription) {
      let el = document.querySelector('meta[name="description"]');
      if (!el) {
        el = document.createElement('meta');
        el.setAttribute('name', 'description');
        document.head.appendChild(el);
      }
      el.setAttribute('content', data.metaDescription);
    }
  }, [data]);

  if (loading) {
    return (
      <section className="min-h-[60vh] flex items-center justify-center pt-32 pb-20" data-testid="static-page-loading">
        <Loader2 className="h-6 w-6 animate-spin text-slatebody/60" />
      </section>
    );
  }

  if (notFound || !data) {
    return <NotFound />;
  }

  return (
    <article className="pt-32 sm:pt-40 pb-20 bg-white" data-testid="static-page">
      <div className="container mx-auto max-w-3xl">
        <Link
          to="/"
          className="inline-flex items-center gap-1.5 text-sm text-slatebody hover:text-[#C9962E] transition-colors"
          data-testid="static-page-back"
        >
          <ChevronLeft className="h-4 w-4" /> Back to home
        </Link>

        <motion.h1
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: EASE }}
          className="mt-6 text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-navy-deep leading-[1.05]"
          data-testid="static-page-title"
        >
          {data.title}
        </motion.h1>

        {data.updatedAt && (
          <p className="mt-4 text-sm text-slatebody" data-testid="static-page-updated">
            Last updated: <span className="font-semibold text-navy-deep">{formatUpdated(data.updatedAt)}</span>
          </p>
        )}

        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.08, ease: EASE }}
          className="mt-10 text-base sm:text-lg text-navy-deep/90 leading-relaxed whitespace-pre-line"
          data-testid="static-page-body"
        >
          {data.body || ''}
        </motion.div>
      </div>
    </article>
  );
}
