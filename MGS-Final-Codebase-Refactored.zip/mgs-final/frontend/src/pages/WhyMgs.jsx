import React, { useRef } from 'react';
import { motion, useReducedMotion, useScroll, useTransform } from 'framer-motion';

import MetricCountUp from '@/components/brand/MetricCountUp';
import CtaBand from '@/components/sections/CtaBand';
import { viewportOnce } from '@/lib/motion';
import { useWhyMgsData } from '@/hooks/useWhyMgsData';

const EASE = [0.22, 1, 0.36, 1];

/* ─── Static fallbacks (match seed 1:1) ────────────────────────────────── */

const DEFAULT_HEADER = {
  heading: 'Why MGS',
  subhead: 'Your trusted partner for tailored, cutting-edge, and premium AI & software solutions.',
};

const DEFAULT_BLOCKS = [
  {
    heading: 'Empowering Innovation With MGS',
    imageSide: 'left',
    image: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=1400&q=75',
    body:
      'At Max Global Software, we don\u2019t just build software — we deliver AI-driven innovation, reliability, and measurable results. With 20+ years of engineering depth and a passion for solving complex challenges, we help businesses thrive in the AI age. Our client-first approach — combined with expertise across generative AI, machine learning, cloud, and modern software development — ensures every solution is tailored to your needs and built for performance, scalability, and long-term success.',
  },
  {
    heading: 'Driven By Technology, Defined By Trust',
    imageSide: 'right',
    image: 'https://images.unsplash.com/photo-1486325212027-8081e485255e?w=1400&q=75',
    body:
      'We believe one-size-fits-all doesn\u2019t apply to technology. We take the time to understand your business, goals, and challenges before crafting custom AI and software strategies that drive growth and efficiency. Whether you\u2019re a startup scaling fast or an enterprise modernizing legacy systems, our solutions are designed with your future in mind.',
  },
];

const DEFAULT_CERTIFICATIONS = [
  { name: 'ISO 9001:2015', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/ISO_9001-2015.svg/240px-ISO_9001-2015.svg.png' },
  { name: 'ISO 27001', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/ISO_logo_%28Red_square%29.svg/240px-ISO_logo_%28Red_square%29.svg.png' },
  { name: 'SOC 2 Type II', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/AICPA_SOC_Logo.svg/240px-AICPA_SOC_Logo.svg.png' },
  { name: 'NASSCOM Member', logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d6/NASSCOM_logo.svg/240px-NASSCOM_logo.svg.png' },
];

const DEFAULT_STATS = [
  { value: '20+', label: 'Years in business' },
  { value: '800+', label: 'Web portals delivered' },
  { value: '400+', label: 'Mobile apps shipped' },
  { value: '35+', label: 'AI engineers & experts' },
];

/* ─── Page ─────────────────────────────────────────────────────────────── */

export default function WhyMgs() {
  const { data } = useWhyMgsData();

  const header = data?.sections?.whyMgsHeader?.data || DEFAULT_HEADER;
  const ctaData = data?.sections?.cta?.data;
  const statsData = data?.sections?.whyMgsStats?.data?.stats;
  const stats = Array.isArray(statsData) && statsData.length ? statsData : DEFAULT_STATS;

  const blocks =
    Array.isArray(data?.collections?.whyMgsBlocks) && data.collections.whyMgsBlocks.length
      ? data.collections.whyMgsBlocks
      : DEFAULT_BLOCKS;
  const certifications =
    Array.isArray(data?.collections?.certifications) && data.collections.certifications.length
      ? data.collections.certifications
      : DEFAULT_CERTIFICATIONS;

  return (
    <>
      {/* ─── Centered header on sky background ─────────────────────────── */}
      <section
        className="relative pt-36 pb-16 sm:pt-44 sm:pb-20 overflow-hidden bg-sky-100"
        data-testid="why-mgs-header"
      >
        <HeaderMesh />
        <div className="container mx-auto relative max-w-4xl text-center">
          <motion.p
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: EASE }}
            className="text-xs sm:text-sm uppercase tracking-[0.2em] font-semibold text-brandblue mb-5"
          >
            {header.heading}
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1, ease: EASE }}
            className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-brandblue leading-[1.05]"
          >
            {header.subhead}
          </motion.h1>
          <motion.div
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 0.9, delay: 0.35, ease: EASE }}
            style={{ transformOrigin: 'center' }}
            className="mx-auto mt-7 h-[2px] w-24 rounded-full bg-gradient-to-r from-[#2BA8E0] via-[#2F6FB0] to-[#E8C25A]"
          />
        </div>
      </section>

      {/* ─── Editorial alternating blocks ─────────────────────────────── */}
      <section className="py-20 sm:py-28 bg-sky-100" data-testid="why-mgs-blocks">
        <div className="container mx-auto space-y-20 sm:space-y-28">
          {blocks.map((b, i) => (
            <EditorialBlock key={(b.id || b.heading) + i} block={b} index={i} />
          ))}

          {/* Certifications row */}
          <CertificationsRow items={certifications} />
        </div>
      </section>

      {/* ─── Trust stats strip ─────────────────────────────────────────── */}
      <StatsStrip stats={stats} />

      <CtaBand data={ctaData} />
    </>
  );
}

/* ─── Header mesh accent ───────────────────────────────────────────────── */

function HeaderMesh() {
  const reducedMotion = useReducedMotion();
  return (
    <div className="absolute inset-0 pointer-events-none opacity-60" aria-hidden="true">
      <motion.div
        className="absolute -top-32 -left-24 w-[480px] h-[480px] rounded-full blur-3xl"
        style={{ background: 'radial-gradient(circle, rgba(47,111,176,0.18), transparent 65%)' }}
        animate={reducedMotion ? {} : { x: [0, 16, 0], y: [0, 10, 0] }}
        transition={{ duration: 22, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div
        className="absolute -bottom-40 -right-24 w-[520px] h-[520px] rounded-full blur-3xl"
        style={{ background: 'radial-gradient(circle, rgba(201,150,46,0.15), transparent 65%)' }}
        animate={reducedMotion ? {} : { x: [0, -14, 0], y: [0, -8, 0] }}
        transition={{ duration: 26, repeat: Infinity, ease: 'easeInOut' }}
      />
    </div>
  );
}

/* ─── Editorial block (alternating image + text) ───────────────────────── */

function EditorialBlock({ block, index }) {
  const ref = useRef(null);
  const reducedMotion = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] });
  const yImg = useTransform(scrollYProgress, [0, 1], reducedMotion ? ['0%', '0%'] : ['-6%', '6%']);

  const imageLeft = (block.imageSide || 'left').toLowerCase() === 'left';

  return (
    <div
      ref={ref}
      data-testid={`why-mgs-block-${index}`}
      className="relative grid lg:grid-cols-12 gap-10 lg:gap-14 items-center"
    >
      {/* Image */}
      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.96 }}
        whileInView={{ opacity: 1, y: 0, scale: 1 }}
        viewport={viewportOnce}
        transition={{ duration: 0.8, ease: EASE }}
        className={`lg:col-span-7 ${imageLeft ? 'lg:order-1' : 'lg:order-2'}`}
      >
        <div className="group relative overflow-hidden rounded-3xl border border-hairline shadow-[0_14px_38px_rgba(31,45,69,0.10)] hover:shadow-[0_22px_50px_rgba(31,45,69,0.16)] transition-shadow duration-500 bg-sky-200/40 aspect-[16/10]">
          {block.image ? (
            <motion.img
              src={block.image}
              alt={block.heading}
              loading="lazy"
              style={{ y: yImg }}
              className="absolute inset-x-0 -top-[6%] w-full h-[112%] object-cover transition-transform duration-[1.4s] ease-out group-hover:scale-[1.04] will-change-transform"
            />
          ) : (
            <div
              aria-hidden="true"
              className="absolute inset-0"
              style={{ background: 'linear-gradient(135deg, #E6F1FB 0%, #C9DCEF 55%, #E8C25A20 100%)' }}
            />
          )}
          {/* Subtle gradient overlay frame, on hover only */}
          <div className="absolute inset-0 bg-gradient-to-tr from-navy-deep/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        </div>
      </motion.div>

      {/* Text */}
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={viewportOnce}
        transition={{ duration: 0.65, delay: 0.15, ease: EASE }}
        className={`lg:col-span-5 ${imageLeft ? 'lg:order-2' : 'lg:order-1'}`}
      >
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-brandblue leading-[1.05]">
          {block.heading}
        </h2>
        <motion.div
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={viewportOnce}
          transition={{ duration: 0.8, delay: 0.35, ease: EASE }}
          style={{ transformOrigin: 'left' }}
          className="mt-5 h-[2px] w-20 rounded-full bg-gradient-to-r from-[#2BA8E0] via-[#2F6FB0] to-[#E8C25A]"
        />
        <p className="mt-6 text-[15px] sm:text-base text-slatebody leading-[1.8]">
          {block.body}
        </p>
      </motion.div>
    </div>
  );
}

/* ─── Certifications row ───────────────────────────────────────────────── */

function CertificationsRow({ items }) {
  if (!items?.length) return null;
  return (
    <motion.div
      initial="hidden"
      whileInView="show"
      viewport={viewportOnce}
      variants={{
        hidden: {},
        show: { transition: { staggerChildren: 0.08, delayChildren: 0.1 } },
      }}
      className="pt-6 flex flex-wrap items-center justify-center gap-x-12 gap-y-6"
      data-testid="why-mgs-certifications"
    >
      {items.map((c, i) => (
        <CertificationBadge key={(c.id || c.name) + i} cert={c} />
      ))}
    </motion.div>
  );
}

function CertificationBadge({ cert }) {
  const [failed, setFailed] = React.useState(false);
  const showLogo = cert.logo && !failed;
  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 14 },
        show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: EASE } },
      }}
      whileHover={{ y: -3 }}
      className="group flex items-center justify-center"
      title={cert.name}
    >
      {showLogo ? (
        <img
          src={cert.logo}
          alt={cert.name}
          loading="lazy"
          onError={() => setFailed(true)}
          className="h-14 w-auto max-w-[140px] object-contain grayscale opacity-70 transition-all duration-500 group-hover:grayscale-0 group-hover:opacity-100"
        />
      ) : (
        <span className="inline-flex h-14 items-center px-5 rounded-full bg-white border border-hairline text-[12px] tracking-[0.16em] uppercase font-bold text-navy/70 group-hover:text-navy group-hover:border-brandblue/40 transition-colors">
          {cert.name}
        </span>
      )}
    </motion.div>
  );
}

/* ─── Stats strip ──────────────────────────────────────────────────────── */

function StatsStrip({ stats }) {
  return (
    <section className="py-14 sm:py-16 bg-white border-y border-hairline" data-testid="why-mgs-stats">
      <div className="container mx-auto">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((s, i) => (
            <motion.div
              key={s.label + i}
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={viewportOnce}
              transition={{ duration: 0.55, delay: i * 0.06, ease: EASE }}
              className="text-center"
            >
              <div className="text-4xl sm:text-5xl font-bold tracking-tight text-navy-deep leading-none">
                <MetricCountUp value={s.value} />
              </div>
              <p className="mt-3 text-[11px] font-bold tracking-[0.22em] uppercase text-slatebody/80">{s.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
