import React, { useEffect, useRef, useState } from 'react';
import {
  motion,
  AnimatePresence,
  useScroll,
  useTransform,
  useReducedMotion,
  useMotionValue,
  useSpring,
} from 'framer-motion';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  ArrowRight,
  ArrowUpRight,
  GripHorizontal,
  Sparkles,
} from 'lucide-react';

import PageHero from '@/components/layout/PageHero';
import CtaBand from '@/components/sections/CtaBand';
import { viewportOnce } from '@/lib/motion';
import { usePortfolioDetail } from '@/hooks/usePortfolioDetail';
import { usePortfolioData } from '@/hooks/usePortfolioData';

const EASE = [0.22, 1, 0.36, 1];

/* ─── Page ─────────────────────────────────────────────────────────────── */

export default function PortfolioDetail() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { data, loading, notFound } = usePortfolioDetail(slug);
  const { data: listData } = usePortfolioData();
  const reducedMotion = useReducedMotion();

  // Update page meta from the portfolio item
  useEffect(() => {
    if (!data?.meta) return;
    if (data.meta.title) document.title = data.meta.title;
    const setMeta = (sel, attr, name, content) => {
      if (!content) return;
      let el = document.querySelector(sel);
      if (!el) {
        el = document.createElement('meta');
        el.setAttribute(attr, name);
        document.head.appendChild(el);
      }
      el.setAttribute('content', content);
    };
    setMeta('meta[name="description"]', 'name', 'description', data.meta.description);
    setMeta('meta[property="og:title"]', 'property', 'og:title', data.meta.title);
    setMeta('meta[property="og:description"]', 'property', 'og:description', data.meta.description);
    if (data.meta.og_image) {
      const abs = /^https?:\/\//i.test(data.meta.og_image)
        ? data.meta.og_image
        : `${window.location.origin}${data.meta.og_image.startsWith('/') ? '' : '/'}${data.meta.og_image}`;
      setMeta('meta[property="og:image"]', 'property', 'og:image', abs);
    }
  }, [data?.meta]);

  if (notFound) {
    return (
      <>
        <PageHero title="Project Not Found" subtitle="The project you're looking for doesn't exist." crumb="Portfolio" />
        <section className="py-16">
          <div className="container mx-auto text-center">
            <Link to="/portfolio" data-testid="pd-back-link" className="text-sm font-semibold text-brandblue hover:text-[#C9962E]">
              ← Back to all work
            </Link>
          </div>
        </section>
        <CtaBand />
      </>
    );
  }

  if (loading || !data) {
    return (
      <section className="py-32 bg-navy-deep">
        <div className="container mx-auto text-center text-sm text-white/70">Loading project…</div>
      </section>
    );
  }

  const p = data.portfolio;
  const prev = data.prev_slug;
  const next = data.next_slug;

  // Related = other visible items in the same category, max 3, excluding self
  const allItems = listData?.collections?.portfolioItems || [];
  const related = allItems
    .filter((it) => it.slug && it.slug !== slug && it.category === p.category)
    .slice(0, 3);

  const fallbackRelated = related.length
    ? related
    : allItems.filter((it) => it.slug && it.slug !== slug).slice(0, 3);

  return (
    <>
      <CinematicHero item={p} reducedMotion={reducedMotion} />
      <FloatingGlassCard item={p} />

      {Array.isArray(p.highlights) && p.highlights.length > 0 && (
        <HighlightsBand highlights={p.highlights} />
      )}

      {/* Device mockup band — 2 screenshots in laptop + phone frame */}
      {Array.isArray(p.gallery) && p.gallery.length >= 2 && (
        <DeviceMockupBand
          laptopImage={p.gallery[0]}
          phoneImage={p.gallery[1] || p.gallery[0]}
          title={p.title}
        />
      )}

      {/* Alternating full-bleed image bands + short text blocks */}
      {Array.isArray(p.gallery) && p.gallery.length >= 3 && (
        <AlternatingBands gallery={p.gallery.slice(2)} title={p.title} description={p.description} />
      )}

      {/* Horizontal drag gallery */}
      {Array.isArray(p.gallery) && p.gallery.length > 0 && (
        <DragGallery images={p.gallery} title={p.title} reducedMotion={reducedMotion} />
      )}

      {/* Tech-stack marquee */}
      {Array.isArray(p.techStack) && p.techStack.length > 0 && (
        <TechMarquee techStack={p.techStack} reducedMotion={reducedMotion} />
      )}

      {/* Case-study cross-link if available */}
      {p.caseStudySlug && <CaseStudyCrosslink slug={p.caseStudySlug} />}

      {/* Magnetic prev / next */}
      <PrevNextBand prev={prev} next={next} navigate={navigate} reducedMotion={reducedMotion} />

      {fallbackRelated.length > 0 && (
        <RelatedProjects items={fallbackRelated} />
      )}

      <CtaBand />

      {/* Sticky visit-live pill */}
      {p.link && <StickyVisitPill link={p.link} />}
    </>
  );
}

/* ─── 1. Cinematic full-bleed hero ─────────────────────────────────────── */

function CinematicHero({ item, reducedMotion }) {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] });
  const y = useTransform(scrollYProgress, [0, 1], reducedMotion ? ['0%', '0%'] : ['0%', '14%']);
  const scale = useTransform(scrollYProgress, [0, 1], reducedMotion ? [1, 1] : [1.05, 1.18]);

  return (
    <section
      ref={ref}
      data-testid="pd-hero"
      className="relative h-[80vh] min-h-[600px] w-full overflow-hidden bg-navy-deep"
    >
      {item.img && (
        <motion.img
          layoutId={reducedMotion ? undefined : `portfolio-img-${item.slug}`}
          src={item.img}
          alt={item.title}
          loading="eager"
          style={{ y, scale }}
          className="absolute inset-0 w-full h-full object-cover will-change-transform"
        />
      )}

      {/* Light scrim behind the navbar so logo + menu stay readable over dark images */}
      <div
        aria-hidden="true"
        className="absolute top-0 inset-x-0 h-44 pointer-events-none"
        style={{
          background:
            'linear-gradient(to bottom, rgba(255,255,255,0.92) 0%, rgba(255,255,255,0.65) 45%, rgba(255,255,255,0.18) 78%, transparent 100%)',
        }}
      />

      {/* Vignette + reading gradient for the title area at the bottom */}
      <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-navy-deep via-navy-deep/45 to-transparent" />
      <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-r from-navy-deep/55 via-transparent to-navy-deep/25" />

      <div className="relative h-full container mx-auto flex flex-col justify-end pb-44 sm:pb-48 pt-44">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1, ease: EASE }}
        >
          <Link
            to="/portfolio"
            data-testid="pd-back-link"
            className="inline-flex items-center gap-1 text-[11px] tracking-[0.18em] uppercase font-bold text-white/85 hover:text-white transition-colors mb-7"
          >
            <ChevronLeft className="h-4 w-4" /> Back to Portfolio
          </Link>

          <div className="flex flex-wrap items-center gap-2 mb-6">
            {item.client && <MetaChip>{item.client}</MetaChip>}
            {item.category && <MetaChip>{prettyCategory(item.category)}</MetaChip>}
            {item.year && <MetaChip>{item.year}</MetaChip>}
          </div>

          <h1
            data-testid="pd-title"
            className="text-4xl sm:text-5xl lg:text-[3.6rem] font-bold tracking-tight text-white leading-[1.02] max-w-4xl drop-shadow-[0_4px_18px_rgba(0,0,0,0.55)]"
          >
            {item.title}
          </h1>

          {item.tag && (
            <p className="mt-5 text-[11px] tracking-[0.32em] uppercase font-bold text-[#E8C25A]">{item.tag}</p>
          )}
        </motion.div>
      </div>

      {/* Subtle bottom scroll-cue */}
      <motion.div
        aria-hidden="true"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.9, duration: 0.6 }}
        className="absolute bottom-6 left-1/2 -translate-x-1/2 text-white/40 text-[10px] tracking-[0.32em] uppercase font-bold flex flex-col items-center gap-2"
      >
        <span>Scroll</span>
        <motion.span
          animate={reducedMotion ? {} : { y: [0, 6, 0] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
          className="h-7 w-[1px] bg-white/40"
        />
      </motion.div>
    </section>
  );
}

function MetaChip({ children }) {
  return (
    <span className="inline-flex items-center px-3 py-1 rounded-full bg-white/12 backdrop-blur ring-1 ring-white/15 text-[11px] font-bold tracking-[0.2em] uppercase text-white">
      {children}
    </span>
  );
}

/* ─── 2. Floating frosted glass info card (overlaps hero bottom) ────────── */

function FloatingGlassCard({ item }) {
  return (
    <section className="relative z-10 -mt-32 sm:-mt-36">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 28 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={viewportOnce}
          transition={{ duration: 0.7, ease: EASE }}
          data-testid="pd-glass-card"
          className="relative max-w-5xl mx-auto rounded-3xl bg-white/85 backdrop-blur-xl ring-1 ring-white/40 shadow-[0_30px_60px_rgba(15,25,45,0.25)] p-8 sm:p-10"
        >
          {/* Soft gold accent corner */}
          <span
            aria-hidden="true"
            className="absolute -top-px left-10 right-10 h-[2px] rounded-full bg-gradient-to-r from-transparent via-[#C9962E] to-transparent"
          />
          <div className="grid lg:grid-cols-[1fr_auto] gap-8 items-end">
            <div>
              <p className="text-xs sm:text-sm font-semibold tracking-[0.2em] uppercase text-brandblue mb-3">
                The Project
              </p>
              {item.description ? (
                <p className="text-navy-deep text-base sm:text-lg leading-relaxed max-w-2xl">
                  {item.description}
                </p>
              ) : (
                <p className="text-navy-deep text-base sm:text-lg leading-relaxed max-w-2xl">
                  {item.title} — a {item.category} project crafted by MGS for {item.client || 'a partner brand'}.
                </p>
              )}

              <div className="mt-7 grid grid-cols-3 gap-6 max-w-md">
                <FactCol label="Client" value={item.client} />
                <FactCol label="Year" value={item.year} />
                <FactCol label="Category" value={prettyCategory(item.category)} />
              </div>
            </div>

            {item.link && (
              <a
                href={item.link}
                target="_blank"
                rel="noopener noreferrer"
                data-testid="pd-visit-live-btn"
                className="group inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-navy-deep text-white text-[11px] tracking-[0.22em] uppercase font-bold hover:bg-[#0F192D] transition-all shadow-[0_10px_24px_rgba(15,25,45,0.35)] hover:shadow-[0_14px_30px_rgba(15,25,45,0.45)]"
              >
                Visit Live Site
                <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
              </a>
            )}
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function FactCol({ label, value }) {
  if (!value) return null;
  return (
    <div>
      <p className="text-[10px] font-bold tracking-[0.2em] uppercase text-slatebody/70">{label}</p>
      <p className="mt-1.5 text-[13px] font-semibold text-navy-deep leading-snug">{value}</p>
    </div>
  );
}

function prettyCategory(c) {
  if (!c) return '';
  const map = { web: 'Web', mobile: 'Mobile', ai: 'AI & ML', ecom: 'E-Commerce', biz: 'Enterprise', uiux: 'UI/UX', games: 'Games' };
  return map[c] || c;
}

/* ─── 3. Highlights band ─────────────────────────────────────────────── */

function HighlightsBand({ highlights }) {
  return (
    <section className="py-24 sm:py-28 bg-white" data-testid="pd-highlights">
      <div className="container mx-auto max-w-6xl">
        <motion.p
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={viewportOnce}
          transition={{ duration: 0.5, ease: EASE }}
          className="text-xs sm:text-sm font-semibold tracking-[0.2em] uppercase text-brandblue"
        >
          Highlights
        </motion.p>
        <motion.h2
          initial={{ opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={viewportOnce}
          transition={{ duration: 0.6, delay: 0.05, ease: EASE }}
          className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-navy-deep leading-[1.05] max-w-3xl"
        >
          Why this project stands out.
        </motion.h2>

        <ul className="mt-14 grid sm:grid-cols-2 gap-x-12 gap-y-9">
          {highlights.map((h, i) => (
            <motion.li
              key={h + i}
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={viewportOnce}
              transition={{ duration: 0.55, delay: i * 0.07, ease: EASE }}
              className="flex items-start gap-4"
            >
              <span className="shrink-0 mt-2 h-[6px] w-[6px] rotate-45 bg-[#C9962E]" aria-hidden="true" />
              <p className="text-base sm:text-lg text-navy-deep leading-relaxed">{h}</p>
            </motion.li>
          ))}
        </ul>
      </div>
    </section>
  );
}

/* ─── 4. Device mockup band (laptop + phone) ───────────────────────────── */

function DeviceMockupBand({ laptopImage, phoneImage, title }) {
  return (
    <section className="relative py-24 sm:py-28 overflow-hidden" data-testid="pd-mockups">
      <div
        aria-hidden="true"
        className="absolute inset-0"
        style={{ background: 'linear-gradient(180deg, #0F192D 0%, #1F4373 60%, #0F192D 100%)' }}
      />
      <div className="relative container mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={viewportOnce}
          transition={{ duration: 0.7, ease: EASE }}
          className="grid lg:grid-cols-[1.4fr_1fr] gap-12 items-center"
        >
          {/* Laptop frame */}
          <div className="relative">
            <div className="relative rounded-t-xl bg-[#1F2937] border border-white/10 p-2.5 shadow-[0_30px_60px_rgba(0,0,0,0.45)]">
              <div className="flex gap-1.5 mb-2 pl-1">
                <span className="h-2.5 w-2.5 rounded-full bg-red-400/80" />
                <span className="h-2.5 w-2.5 rounded-full bg-yellow-400/80" />
                <span className="h-2.5 w-2.5 rounded-full bg-green-400/80" />
              </div>
              <div className="rounded-md overflow-hidden bg-navy-deep aspect-[16/10]">
                <img
                  src={laptopImage}
                  alt={`${title} — desktop view`}
                  loading="lazy"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            {/* Laptop base */}
            <div className="h-2.5 mx-[-12px] bg-[#0F1623] rounded-b-2xl shadow-[0_18px_30px_rgba(0,0,0,0.45)]" />
            <div className="mx-auto -mt-1 h-1.5 w-32 bg-[#1F2937] rounded-b-xl" />
          </div>

          {/* Phone frame */}
          <div className="relative justify-self-center">
            <div className="relative w-[240px] sm:w-[270px] rounded-[2.4rem] bg-[#0F1623] border border-white/10 p-2.5 shadow-[0_24px_50px_rgba(0,0,0,0.5)]">
              <div className="absolute top-3 left-1/2 -translate-x-1/2 h-1.5 w-16 rounded-full bg-black/80" />
              <div className="rounded-[1.9rem] overflow-hidden bg-navy-deep aspect-[9/19]">
                <img
                  src={phoneImage}
                  alt={`${title} — mobile view`}
                  loading="lazy"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

/* ─── 5. Alternating full-bleed image bands + text blocks ───────────────── */

function AlternatingBands({ gallery, title, description }) {
  // First band carries the description; subsequent ones use short flavour text.
  const flavourTexts = [
    'Crafted around real user journeys — every micro-interaction earns its place on the screen.',
    'Built for resilience: graceful loading states, optimistic UI, and observability baked in.',
    'A design language that scales — from marquee marketing moments to dense interior screens.',
  ];

  return (
    <div data-testid="pd-bands">
      {gallery.map((img, i) => {
        const reverse = i % 2 === 1;
        const text = i === 0 ? description || flavourTexts[0] : flavourTexts[i % flavourTexts.length];
        const eyebrow = i === 0 ? 'The Build' : i === 1 ? 'In Practice' : 'At Scale';

        return (
          <section
            key={img + i}
            className={`py-24 sm:py-28 ${i % 2 === 0 ? 'bg-sky-50' : 'bg-white'}`}
          >
            <div className="container mx-auto">
              <div className={`grid lg:grid-cols-12 gap-10 items-center ${reverse ? 'lg:[direction:rtl]' : ''}`}>
                <motion.div
                  initial={{ opacity: 0, x: reverse ? 30 : -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={viewportOnce}
                  transition={{ duration: 0.7, ease: EASE }}
                  className={`lg:col-span-7 ${reverse ? 'lg:[direction:ltr]' : ''}`}
                >
                  <div className="relative rounded-2xl overflow-hidden aspect-[16/10] shadow-[0_24px_60px_rgba(15,25,45,0.18)]">
                    <img src={img} alt={`${title} ${i + 1}`} loading="lazy" className="w-full h-full object-cover" />
                  </div>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, x: reverse ? -30 : 30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={viewportOnce}
                  transition={{ duration: 0.7, delay: 0.05, ease: EASE }}
                  className={`lg:col-span-5 ${reverse ? 'lg:[direction:ltr]' : ''}`}
                >
                  <p className="text-xs sm:text-sm font-semibold tracking-[0.2em] uppercase text-brandblue">{eyebrow}</p>
                  <h3 className="mt-3 text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-navy-deep leading-[1.08]">
                    {i === 0 ? 'Beyond the brief.' : i === 1 ? 'Made to be used.' : 'Wired for growth.'}
                  </h3>
                  <p className="mt-5 text-base sm:text-lg text-slatebody leading-relaxed">{text}</p>
                </motion.div>
              </div>
            </div>
          </section>
        );
      })}
    </div>
  );
}

/* ─── 6. Horizontal drag gallery (film-strip with gold rail) ───────────── */

function DragGallery({ images, title, reducedMotion }) {
  const scrollerRef = useRef(null);
  const railRef = useRef(null);
  const [progress, setProgress] = useState(0);
  const dragState = useRef({ active: false, startX: 0, startScroll: 0, lastX: 0, lastT: 0, vx: 0 });
  const [grabbing, setGrabbing] = useState(false);

  // Update gold-rail progress dot on scroll
  useEffect(() => {
    const el = scrollerRef.current;
    if (!el) return;
    const onScroll = () => {
      const max = el.scrollWidth - el.clientWidth;
      setProgress(max > 0 ? el.scrollLeft / max : 0);
    };
    el.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => el.removeEventListener('scroll', onScroll);
  }, [images]);

  const onPointerDown = (e) => {
    if (reducedMotion) return;
    const el = scrollerRef.current;
    if (!el) return;
    dragState.current = {
      active: true,
      startX: e.clientX,
      startScroll: el.scrollLeft,
      lastX: e.clientX,
      lastT: performance.now(),
      vx: 0,
    };
    setGrabbing(true);
    el.setPointerCapture?.(e.pointerId);
  };

  const onPointerMove = (e) => {
    const st = dragState.current;
    if (!st.active) return;
    const el = scrollerRef.current;
    if (!el) return;
    const dx = e.clientX - st.startX;
    if (Math.abs(dx) < 4) return;
    el.scrollLeft = st.startScroll - dx;
    const now = performance.now();
    const dt = Math.max(1, now - st.lastT);
    st.vx = (e.clientX - st.lastX) / dt;
    st.lastX = e.clientX;
    st.lastT = now;
  };

  const onPointerUp = () => {
    const st = dragState.current;
    if (!st.active) return;
    st.active = false;
    setGrabbing(false);
    const el = scrollerRef.current;
    if (!el || reducedMotion) return;
    let v = -st.vx * 22;
    if (Math.abs(v) < 0.5) return;
    let last = performance.now();
    const tick = (now) => {
      const dt = now - last;
      last = now;
      el.scrollLeft += v * (dt / 16);
      v *= 0.92;
      if (Math.abs(v) > 0.3) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  };

  return (
    <section className="py-24 sm:py-28 bg-navy-deep relative overflow-hidden" data-testid="pd-gallery">
      <div className="container mx-auto flex items-end justify-between mb-10">
        <div>
          <p className="text-xs sm:text-sm font-semibold tracking-[0.2em] uppercase text-[#E8C25A]">The Gallery</p>
          <h2 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white leading-[1.05]">
            Inside {title}
          </h2>
        </div>
        <p className="hidden sm:inline-flex items-center gap-2 text-[10px] tracking-[0.22em] uppercase font-bold text-white/60">
          <GripHorizontal className="h-3.5 w-3.5" /> Drag · Flick · Explore
        </p>
      </div>

      <div
        ref={scrollerRef}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
        className={`overflow-x-auto no-scrollbar pb-2 select-none ${grabbing ? 'cursor-grabbing' : 'cursor-grab'}`}
        style={{ willChange: 'scroll-position' }}
      >
        <div className="container mx-auto flex gap-6 sm:gap-8">
          {images.map((src, i) => (
            <motion.figure
              key={src + i}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.6, delay: i * 0.06, ease: EASE }}
              className="group shrink-0 w-[82vw] sm:w-[560px] lg:w-[720px] rounded-2xl overflow-hidden ring-1 ring-white/10 shadow-[0_20px_50px_rgba(0,0,0,0.4)]"
            >
              <div className="relative aspect-[16/10] overflow-hidden bg-black">
                <img
                  src={src}
                  alt={`${title} screenshot ${i + 1}`}
                  loading="lazy"
                  draggable={false}
                  className="w-full h-full object-cover transition-transform duration-[1.1s] ease-out group-hover:scale-[1.03] will-change-transform pointer-events-none"
                />
              </div>
            </motion.figure>
          ))}
          <div className="shrink-0 w-6" aria-hidden="true" />
        </div>
      </div>

      {/* Thin gold progress rail */}
      <div className="container mx-auto mt-8" ref={railRef}>
        <div className="relative h-[3px] w-full max-w-2xl mx-auto rounded-full bg-white/10 overflow-hidden">
          <div
            className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-[#C9962E] to-[#E8C25A] transition-[width] duration-200"
            style={{ width: `${Math.round(progress * 100)}%` }}
          />
        </div>
      </div>
    </section>
  );
}

/* ─── 7. Tech-stack marquee ────────────────────────────────────────────── */

function TechMarquee({ techStack, reducedMotion }) {
  // Duplicate for an uninterrupted loop
  const items = [...techStack, ...techStack];
  return (
    <section className="py-20 sm:py-24 bg-white border-y border-hairline overflow-hidden" data-testid="pd-tech-marquee">
      <div className="container mx-auto mb-10">
        <p className="text-xs sm:text-sm font-semibold tracking-[0.2em] uppercase text-brandblue text-center">
          Tech Stack
        </p>
        <h3 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-navy-deep leading-[1.05] text-center">
          Built with battle-tested tools.
        </h3>
      </div>
      <div className="relative">
        <div
          aria-hidden="true"
          className="absolute inset-y-0 left-0 w-24 z-10"
          style={{ background: 'linear-gradient(to right, #fff, transparent)' }}
        />
        <div
          aria-hidden="true"
          className="absolute inset-y-0 right-0 w-24 z-10"
          style={{ background: 'linear-gradient(to left, #fff, transparent)' }}
        />
        <motion.div
          animate={reducedMotion ? {} : { x: ['0%', '-50%'] }}
          transition={reducedMotion ? {} : { duration: 28, repeat: Infinity, ease: 'linear' }}
          className="flex gap-14 items-center w-max"
        >
          {items.map((t, i) => (
            <div
              key={t.name + i}
              className="flex items-center gap-3 shrink-0 px-6 py-3 rounded-full bg-sky-50 border border-hairline"
              title={t.name}
            >
              {t.icon_url ? (
                <img src={t.icon_url} alt={t.name} loading="lazy" className="h-7 w-7 object-contain" />
              ) : (
                <Sparkles className="h-5 w-5 text-brandblue" />
              )}
              <span className="text-[12px] font-semibold tracking-wide text-navy-deep">{t.name}</span>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

/* ─── 8. Case-study crosslink ──────────────────────────────────────────── */

function CaseStudyCrosslink({ slug }) {
  return (
    <section className="py-20 sm:py-24 bg-sky-50" data-testid="pd-cs-crosslink">
      <div className="container mx-auto">
        <Link
          to={`/case-studies/${slug}`}
          className="group block rounded-3xl p-10 sm:p-12 bg-gradient-to-br from-navy-deep via-[#1F4373] to-[#2F6FB0] text-white overflow-hidden relative shadow-[0_30px_60px_rgba(15,25,45,0.25)]"
        >
          <span aria-hidden="true" className="absolute -right-16 -top-16 h-72 w-72 rounded-full" style={{ background: 'radial-gradient(circle, rgba(232,194,90,0.35), transparent 65%)' }} />
          <div className="relative grid lg:grid-cols-[1fr_auto] items-center gap-8">
            <div>
              <p className="text-xs sm:text-sm font-semibold tracking-[0.2em] uppercase text-[#E8C25A]">The story behind it</p>
              <h3 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight leading-[1.05]">
                Read the full case study →
              </h3>
              <p className="mt-3 text-white/85 text-base sm:text-lg max-w-xl leading-relaxed">
                Get the long-form story: the challenges we faced, how we built it, and the numbers that came out.
              </p>
            </div>
            <span className="shrink-0 inline-flex items-center gap-2 px-5 py-3 rounded-full bg-white text-navy-deep text-[11px] tracking-[0.22em] uppercase font-bold group-hover:bg-[#E8C25A] transition-colors">
              View case study
              <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
            </span>
          </div>
        </Link>
      </div>
    </section>
  );
}

/* ─── 9. Magnetic Prev / Next band ─────────────────────────────────────── */

function PrevNextBand({ prev, next, navigate, reducedMotion }) {
  if (!prev && !next) return null;
  return (
    <section className="py-16 bg-white border-t border-hairline" data-testid="pd-prev-next">
      <div className="container mx-auto flex items-center justify-between gap-6">
        <MagneticNavCard
          testId="pd-prev"
          label="Previous project"
          slug={prev}
          align="left"
          onClick={() => prev && navigate(`/portfolio/${prev}`)}
          reducedMotion={reducedMotion}
        />
        <MagneticNavCard
          testId="pd-next"
          label="Next project"
          slug={next}
          align="right"
          onClick={() => next && navigate(`/portfolio/${next}`)}
          reducedMotion={reducedMotion}
        />
      </div>
    </section>
  );
}

function MagneticNavCard({ testId, label, slug, align, onClick, reducedMotion }) {
  const ref = useRef(null);
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const x = useSpring(mx, { stiffness: 200, damping: 18, mass: 0.5 });
  const y = useSpring(my, { stiffness: 200, damping: 18, mass: 0.5 });

  const onMove = (e) => {
    if (!slug || reducedMotion) return;
    const r = ref.current?.getBoundingClientRect?.();
    if (!r) return;
    const px = e.clientX - (r.left + r.width / 2);
    const py = e.clientY - (r.top + r.height / 2);
    mx.set(Math.max(-8, Math.min(8, px * 0.16)));
    my.set(Math.max(-6, Math.min(6, py * 0.16)));
  };
  const onLeave = () => { mx.set(0); my.set(0); };

  const disabled = !slug;

  return (
    <motion.button
      ref={ref}
      style={{ x, y }}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      whileTap={disabled ? {} : { scale: 0.97 }}
      transition={{ type: 'spring', stiffness: 360, damping: 22 }}
      onClick={onClick}
      disabled={disabled}
      data-testid={testId}
      aria-label={label}
      className={`group inline-flex items-center gap-3 text-left disabled:opacity-30 disabled:cursor-not-allowed ${align === 'right' ? 'flex-row-reverse text-right' : ''}`}
    >
      <span className={`h-14 w-14 rounded-full bg-sky-50 border border-hairline inline-flex items-center justify-center text-navy-deep group-hover:bg-navy-deep group-hover:text-white transition-colors`}>
        {align === 'right' ? <ChevronRight className="h-5 w-5" /> : <ChevronLeft className="h-5 w-5" />}
      </span>
      <span>
        <span className="block text-[10px] font-bold tracking-[0.22em] uppercase text-slatebody/70">{label}</span>
        <span className="block mt-1 text-[15px] font-semibold tracking-tight text-navy-deep group-hover:text-[#C9962E] transition-colors capitalize">
          {slug ? slug.replace(/-/g, ' ') : '—'}
        </span>
      </span>
    </motion.button>
  );
}

/* ─── 10. Related projects ─────────────────────────────────────────────── */

function RelatedProjects({ items }) {
  return (
    <section className="py-20 sm:py-24 bg-sky-50" data-testid="pd-related">
      <div className="container mx-auto">
        <p className="text-xs sm:text-sm font-semibold tracking-[0.2em] uppercase text-brandblue">More work</p>
        <h3 className="mt-3 text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-navy-deep leading-[1.05]">Related projects.</h3>

        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {items.map((r, i) => (
            <motion.div
              key={r.slug || r.title}
              initial={{ opacity: 0, y: 22 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={viewportOnce}
              transition={{ duration: 0.55, delay: i * 0.07, ease: EASE }}
            >
              <Link
                to={`/portfolio/${r.slug}`}
                className="group block rounded-2xl overflow-hidden bg-white border border-hairline shadow-[0_10px_28px_rgba(31,45,69,0.08)] hover:shadow-[0_22px_50px_rgba(31,45,69,0.16)] transition-shadow"
                data-testid={`pd-related-${i}`}
              >
                <div className="relative aspect-[16/10] overflow-hidden bg-sky-100">
                  {r.img ? (
                    <img src={r.img} alt={r.title} loading="lazy" className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-[900ms] group-hover:scale-[1.06] will-change-transform" />
                  ) : (
                    <div aria-hidden="true" className="absolute inset-0" style={{ background: 'linear-gradient(135deg, #E6F1FB 0%, #C9DCEF 55%, #E8C25A20 100%)' }} />
                  )}
                </div>
                <div className="p-6">
                  <p className="text-[10px] font-bold tracking-[0.2em] uppercase text-brandblue">{prettyCategory(r.category) || 'Project'}</p>
                  <h4 className="mt-2.5 text-[15px] font-semibold tracking-tight text-navy-deep leading-snug line-clamp-2 group-hover:text-[#C9962E] transition-colors">{r.title}</h4>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─── 11. Sticky visit-live pill (appears after hero) ──────────────────── */

function StickyVisitPill({ link }) {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 600);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <AnimatePresence>
      {show && (
        <motion.a
          href={link}
          target="_blank"
          rel="noopener noreferrer"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 16 }}
          transition={{ duration: 0.35, ease: EASE }}
          data-testid="pd-sticky-visit-pill"
          className="fixed bottom-6 right-6 sm:bottom-8 sm:right-8 z-40 inline-flex items-center gap-2 px-5 py-3 rounded-full bg-[#C9962E] hover:bg-[#B8851D] text-white text-[11px] tracking-[0.22em] uppercase font-bold shadow-[0_18px_38px_rgba(201,150,46,0.5)] transition-all hover:scale-[1.04]"
        >
          Visit Live Site
          <ExternalLink className="h-3.5 w-3.5" />
        </motion.a>
      )}
    </AnimatePresence>
  );
}
