import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import axios from 'axios';
import {
  MapPin, Mail, Phone, Globe, ArrowRight, Loader2,
  Facebook, Twitter, Linkedin, Youtube, User,
} from 'lucide-react';

import SectionHeading from '@/components/brand/SectionHeading';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { PrimaryButton } from '@/components/brand/Buttons';
import { viewportOnce } from '@/lib/motion';
import { useContactData } from '@/hooks/useContactData';

const EASE = [0.22, 1, 0.36, 1];

const SOCIAL_ICONS = {
  facebook: Facebook,
  twitter: Twitter,
  linkedin: Linkedin,
  youtube: Youtube,
};

const FALLBACK_HEADER = {
  kicker: 'Contact',
  heading: "Let's Build Something Together",
  subhead: "Tell us about your project \u2014 we'll get back within one business day.",
};

const EMPTY_FORM = { name: '', email: '', phone: '', company: '', message: '' };

function toArray(v) {
  return Array.isArray(v) ? v : v ? [v] : [];
}

export default function Contact() {
  const { data } = useContactData();
  const header = data?.sections?.contactHeader?.data || FALLBACK_HEADER;
  const contact = data?.settings?.contact || {};
  const socials = data?.settings?.socials || [];

  const addressLines = toArray(contact.address);
  const emails = toArray(contact.email);
  const phones = toArray(contact.phone);
  const website = contact.website || '';
  const offices = Array.isArray(contact.offices) ? contact.offices.filter(Boolean) : [];
  const hasOffices = offices.length > 0;

  // Legacy single-map fallback — only used when no offices array is present.
  const addressString = addressLines.join(' ').trim();
  const legacyMapUrl = addressString
    ? `https://www.google.com/maps?q=${encodeURIComponent(addressString)}&output=embed`
    : null;

  const [form, setForm] = useState(EMPTY_FORM);
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const setField = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const validate = () => {
    const next = {};
    if (!form.name.trim()) next.name = 'Please enter your name.';
    if (!form.email.trim()) next.email = 'Email is required.';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) next.email = 'Please enter a valid email.';
    if (!form.message.trim()) next.message = 'Tell us about your project.';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    if (!validate() || submitting) return;
    setSubmitting(true);
    try {
      // Reuse the existing /api/contact endpoint (same payload shape as the
      // home CtaBand form). Map "company" + "message" → brief so we don't
      // require a backend schema change.
      const brief = form.company.trim()
        ? `[${form.company.trim()}] ${form.message.trim()}`
        : form.message.trim();
      await axios.post(`${process.env.REACT_APP_BACKEND_URL}/api/contact`, {
        name: form.name.trim(),
        email: form.email.trim(),
        phone: form.phone.trim() || undefined,
        brief,
      });
      toast.success("Message sent! We'll reach out within one business day.");
      setForm(EMPTY_FORM);
      setErrors({});
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Something went wrong. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      {/* ─── Header ─────────────────────────────────────────────────── */}
      <section className="relative pt-36 pb-12 sm:pt-44 sm:pb-16 overflow-hidden bg-sky-50">
        <div
          aria-hidden="true"
          className="absolute inset-0 opacity-70 pointer-events-none"
          style={{
            background:
              'radial-gradient(700px 400px at 12% 18%, rgba(47,111,176,0.10), transparent 65%), radial-gradient(560px 320px at 88% 90%, rgba(232,194,90,0.10), transparent 70%)',
          }}
        />
        <div className="relative container mx-auto" data-testid="contact-header">
          <SectionHeading
            eyebrow={header.kicker || 'Contact'}
            title={header.heading}
            subtitle={header.subhead}
            align="center"
          />
        </div>
      </section>

      {/* ─── Body: form (left) + details (right) ────────────────────── */}
      <section className="py-14 sm:py-20 bg-white">
        <div className="container mx-auto">
          <div className="grid lg:grid-cols-[1.1fr_1fr] gap-10 lg:gap-14 items-start">
            {/* LEFT: Form */}
            <motion.form
              onSubmit={onSubmit}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={viewportOnce}
              transition={{ duration: 0.5, ease: EASE }}
              className="rounded-3xl bg-white border border-hairline shadow-card p-7 sm:p-10"
              data-testid="contact-form"
              noValidate
            >
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-navy-deep">
                Send us a message
              </h2>
              <p className="mt-2 text-sm text-slatebody">
                We&rsquo;ll never share your details with third parties.
              </p>

              <div className="mt-7 grid sm:grid-cols-2 gap-5">
                <div>
                  <Label htmlFor="c-name" className="text-xs font-semibold text-navy-deep">
                    Full Name <span className="text-[#C9962E]">*</span>
                  </Label>
                  <Input
                    id="c-name"
                    value={form.name}
                    onChange={(e) => setField('name', e.target.value)}
                    placeholder="John Doe"
                    className={`mt-1.5 rounded-xl ${errors.name ? 'border-red-400' : 'border-hairline'}`}
                    data-testid="contact-input-name"
                    autoComplete="name"
                  />
                  {errors.name && <p className="mt-1 text-xs text-red-600" role="alert">{errors.name}</p>}
                </div>
                <div>
                  <Label htmlFor="c-email" className="text-xs font-semibold text-navy-deep">
                    Business Email <span className="text-[#C9962E]">*</span>
                  </Label>
                  <Input
                    id="c-email"
                    type="email"
                    value={form.email}
                    onChange={(e) => setField('email', e.target.value)}
                    placeholder="john@company.com"
                    className={`mt-1.5 rounded-xl ${errors.email ? 'border-red-400' : 'border-hairline'}`}
                    data-testid="contact-input-email"
                    autoComplete="email"
                  />
                  {errors.email && <p className="mt-1 text-xs text-red-600" role="alert">{errors.email}</p>}
                </div>
                <div>
                  <Label htmlFor="c-phone" className="text-xs font-semibold text-navy-deep">
                    Phone
                  </Label>
                  <Input
                    id="c-phone"
                    value={form.phone}
                    onChange={(e) => setField('phone', e.target.value)}
                    placeholder="+1 555 000 0000"
                    className="mt-1.5 rounded-xl border-hairline"
                    data-testid="contact-input-phone"
                    autoComplete="tel"
                  />
                </div>
                <div>
                  <Label htmlFor="c-company" className="text-xs font-semibold text-navy-deep">
                    Company
                  </Label>
                  <Input
                    id="c-company"
                    value={form.company}
                    onChange={(e) => setField('company', e.target.value)}
                    placeholder="Acme Corp."
                    className="mt-1.5 rounded-xl border-hairline"
                    data-testid="contact-input-company"
                    autoComplete="organization"
                  />
                </div>
              </div>

              <div className="mt-5">
                <Label htmlFor="c-message" className="text-xs font-semibold text-navy-deep">
                  Message <span className="text-[#C9962E]">*</span>
                </Label>
                <Textarea
                  id="c-message"
                  value={form.message}
                  onChange={(e) => setField('message', e.target.value)}
                  placeholder="Tell us about your AI or software project…"
                  rows={5}
                  className={`mt-1.5 rounded-xl resize-none ${errors.message ? 'border-red-400' : 'border-hairline'}`}
                  data-testid="contact-input-message"
                />
                {errors.message && <p className="mt-1 text-xs text-red-600" role="alert">{errors.message}</p>}
              </div>

              <div className="mt-7">
                <PrimaryButton
                  type="submit"
                  disabled={submitting}
                  data-testid="contact-submit"
                  icon={submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowRight className="h-4 w-4" />}
                >
                  {submitting ? 'Sending…' : 'Send message'}
                </PrimaryButton>
              </div>
            </motion.form>

            {/* RIGHT: Details */}
            <motion.aside
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={viewportOnce}
              transition={{ duration: 0.5, delay: 0.05, ease: EASE }}
              className="rounded-3xl bg-sky-50 border border-hairline p-7 sm:p-10"
              data-testid="contact-details"
            >
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-navy-deep">
                Reach us directly
              </h2>
              <p className="mt-2 text-sm text-slatebody">
                Prefer email or phone? Here&rsquo;s how to find us.
              </p>

              <ul className="mt-7 space-y-5">
                {!hasOffices && addressLines.length > 0 && (
                  <li className="flex gap-3 items-start" data-testid="contact-address">
                    <MapPin className="h-5 w-5 text-brandblue shrink-0 mt-0.5" />
                    <p className="text-base text-navy-deep leading-relaxed">
                      {addressLines.map((line, i) => (
                        <React.Fragment key={i}>
                          {line}
                          {i < addressLines.length - 1 && <br />}
                        </React.Fragment>
                      ))}
                    </p>
                  </li>
                )}

                {emails.length > 0 && (
                  <li className="flex gap-3 items-start">
                    <Mail className="h-5 w-5 text-brandblue shrink-0 mt-0.5" />
                    <div className="flex flex-col gap-1">
                      {emails.map((e) => (
                        <a
                          key={e}
                          href={`mailto:${e}`}
                          className="text-base text-navy-deep hover:text-[#C9962E] transition-colors"
                          data-testid={`contact-email-${e}`}
                        >
                          {e}
                        </a>
                      ))}
                    </div>
                  </li>
                )}

                {!hasOffices && phones.length > 0 && (
                  <li className="flex gap-3 items-start">
                    <Phone className="h-5 w-5 text-brandblue shrink-0 mt-0.5" />
                    <div className="flex flex-col gap-1">
                      {phones.map((p) => (
                        <a
                          key={p}
                          href={`tel:${p.replace(/[\s\u2013-]/g, '')}`}
                          className="text-base text-navy-deep hover:text-[#C9962E] transition-colors"
                          data-testid={`contact-phone-${p}`}
                        >
                          {p}
                        </a>
                      ))}
                    </div>
                  </li>
                )}

                {website && (
                  <li className="flex gap-3 items-start">
                    <Globe className="h-5 w-5 text-brandblue shrink-0 mt-0.5" />
                    <a
                      href={website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-base text-navy-deep hover:text-[#C9962E] transition-colors"
                      data-testid="contact-website"
                    >
                      {website.replace(/^https?:\/\//, '')}
                    </a>
                  </li>
                )}
              </ul>

              {socials.length > 0 && (
                <div className="mt-8 flex items-center gap-3" data-testid="contact-socials">
                  {socials.map((s, i) => {
                    const Icon = SOCIAL_ICONS[(s.platform || '').toLowerCase()] || Globe;
                    return (
                      <a
                        key={`${s.platform}-${i}`}
                        href={s.url || '#'}
                        target={s.url && s.url !== '#' ? '_blank' : undefined}
                        rel={s.url && s.url !== '#' ? 'noopener noreferrer' : undefined}
                        aria-label={s.platform || 'social'}
                        className="h-10 w-10 inline-flex items-center justify-center rounded-full border border-hairline bg-white text-navy hover:bg-gold-gradient hover:text-white hover:border-transparent transition-all"
                      >
                        <Icon className="h-4 w-4" />
                      </a>
                    );
                  })}
                </div>
              )}
            </motion.aside>
          </div>

          {/* ─── Offices (per-branch cards + per-office map) ─────────── */}
          {hasOffices ? (
            <div className="mt-14 sm:mt-20" data-testid="contact-offices">
              <motion.div
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={viewportOnce}
                transition={{ duration: 0.5, ease: EASE }}
                className="text-center mb-10 sm:mb-14"
              >
                <p className="text-xs sm:text-sm uppercase tracking-[0.2em] text-brandblue font-semibold">
                  Find us
                </p>
                <h2 className="mt-3 text-3xl sm:text-4xl font-bold tracking-tight text-navy-deep">
                  Our offices
                </h2>
              </motion.div>

              <div className="space-y-12 sm:space-y-16">
                {offices.map((office, idx) => (
                  <OfficeBlock key={(office.label || 'office') + idx} office={office} index={idx} />
                ))}
              </div>
            </div>
          ) : (
            /* Legacy single-map fallback (only used when offices array is empty) */
            legacyMapUrl && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={viewportOnce}
                transition={{ duration: 0.55, ease: EASE }}
                className="mt-12 sm:mt-16 rounded-3xl overflow-hidden border border-hairline shadow-card"
                data-testid="contact-map"
              >
                <iframe
                  title="Max Global Software — Office Location"
                  src={legacyMapUrl}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  allowFullScreen
                  className="w-full aspect-[16/9] sm:aspect-[21/9] block"
                />
              </motion.div>
            )
          )}
        </div>
      </section>
    </>
  );
}

/**
 * OfficeBlock — single office row: details card + its own keyless Google Map.
 * Alternates the column order on every other office for visual rhythm.
 */
function OfficeBlock({ office, index }) {
  const { label, address, contactPerson, designation, phone } = office || {};
  const mapUrl = address
    ? `https://www.google.com/maps?q=${encodeURIComponent(address)}&output=embed`
    : null;
  // Alternate left/right on desktop; mobile always stacks (details first).
  const flip = index % 2 === 1;
  const testidBase = (label || `office-${index}`)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');

  return (
    <motion.div
      initial={{ opacity: 0, y: 22 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={viewportOnce}
      transition={{ duration: 0.55, ease: EASE }}
      className="grid lg:grid-cols-[1fr_1.15fr] gap-6 lg:gap-10 items-stretch"
      data-testid={`office-${testidBase}`}
    >
      {/* Details card */}
      <div
        className={`rounded-3xl bg-sky-50 border border-hairline p-7 sm:p-9 flex flex-col ${
          flip ? 'lg:order-2' : ''
        }`}
      >
        {label && (
          <p className="text-xs sm:text-sm uppercase tracking-[0.2em] text-[#C9962E] font-bold">
            {label}
          </p>
        )}

        {address && (
          <div className="mt-4 flex gap-3 items-start">
            <MapPin className="h-5 w-5 text-brandblue shrink-0 mt-0.5" />
            <p
              className="text-base sm:text-lg text-navy-deep leading-relaxed"
              data-testid={`office-address-${testidBase}`}
            >
              {address}
            </p>
          </div>
        )}

        {contactPerson && (
          <div className="mt-5 flex gap-3 items-start">
            <User className="h-5 w-5 text-brandblue shrink-0 mt-0.5" />
            <div>
              <p className="text-base text-navy-deep" data-testid={`office-contact-${testidBase}`}>
                Contact: <span className="font-bold">{contactPerson}</span>
              </p>
              {designation && (
                <p
                  className="text-sm text-slatebody mt-0.5"
                  data-testid={`office-designation-${testidBase}`}
                >
                  {designation}
                </p>
              )}
            </div>
          </div>
        )}

        {phone && (
          <div className="mt-5 flex gap-3 items-start">
            <Phone className="h-5 w-5 text-brandblue shrink-0 mt-0.5" />
            <a
              href={`tel:${phone.replace(/[\s\u2013-]/g, '')}`}
              className="text-base text-navy-deep hover:text-[#C9962E] transition-colors"
              data-testid={`office-phone-${testidBase}`}
            >
              {phone}
            </a>
          </div>
        )}
      </div>

      {/* Per-office map */}
      {mapUrl && (
        <div
          className={`rounded-3xl overflow-hidden border border-hairline shadow-card min-h-[280px] ${
            flip ? 'lg:order-1' : ''
          }`}
          data-testid={`office-map-${testidBase}`}
        >
          <iframe
            title={`${label || 'Office'} — Map`}
            src={mapUrl}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            allowFullScreen
            className="w-full h-full min-h-[280px] block"
          />
        </div>
      )}
    </motion.div>
  );
}
