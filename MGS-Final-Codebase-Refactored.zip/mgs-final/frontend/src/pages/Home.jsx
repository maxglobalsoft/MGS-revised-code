import React from 'react';
import Hero from '@/components/sections/Hero';
import ExploreServices from '@/components/sections/ExploreServices';
import Industries from '@/components/sections/Industries';
import Achievements from '@/components/sections/Achievements';
import Portfolio from '@/components/sections/Portfolio';
import CaseStudy from '@/components/sections/CaseStudy';
import OurValues from '@/components/sections/OurValues';
import Technologies from '@/components/sections/Technologies';
import Testimonials from '@/components/sections/Testimonials';
import EsteemedClients from '@/components/sections/EsteemedClients';
import CtaBand from '@/components/sections/CtaBand';
import { useHomeData } from '@/hooks/useHomeData';

export default function Home() {
  const { data } = useHomeData();

  // While loading or on error, every prop is `undefined` and each section
  // falls back to its built-in DEFAULT_* arrays — so the page renders
  // identically until the live data arrives.
  const sections = data?.sections || {};
  const collections = data?.collections || {};

  return (
    <>
      <Hero data={sections.hero?.data} />
      <ExploreServices data={sections.servicesIntro?.data} items={collections.services} />
      <Industries data={sections.industriesIntro?.data} items={collections.industries} />
      <Achievements data={sections.achievements?.data} />
      <Portfolio
        data={sections.portfolioIntro?.data}
        items={collections.portfolioItems}
        categories={collections.portfolioCategories}
      />
      <CaseStudy data={sections.caseStudyIntro?.data} items={collections.caseStudies} />
      <OurValues data={sections.values?.data} items={collections.valuesItems} />
      <Technologies data={sections.technologiesIntro?.data} items={collections.technologies} />
      <Testimonials data={sections.testimonialsIntro?.data} items={collections.testimonials} />
      <EsteemedClients data={sections.clientsIntro?.data} items={collections.clients} />
      <CtaBand data={sections.cta?.data} />
    </>
  );
}
