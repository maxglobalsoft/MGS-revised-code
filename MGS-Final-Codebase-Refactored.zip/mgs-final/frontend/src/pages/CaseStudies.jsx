import React, { useMemo, useState } from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight, ArrowRight, Clock, Image as ImageIcon } from 'lucide-react';

import SectionHeading from '@/components/brand/SectionHeading';
import CtaBand from '@/components/sections/CtaBand';
import { viewportOnce } from '@/lib/motion';
import { useCaseStudiesData } from '@/hooks/useCaseStudiesData';

const EASE = [0.22, 1, 0.36, 1];
const PAGE_SIZE = 6;

const DEFAULT_HEADER = {
  heading: 'Portfolio Case Study',
  subhead:
    'Experience innovation and expertise through our case study. Dive into insightful articles, cutting-edge tech trends, and industry best practices. Join us in exploring the future of technology, one blog post at a time.',
};

const DEFAULT_CATEGORIES = [
  { label: 'All', order: 1 },
  { label: 'Development', order: 2 },
  { label: 'FinTech', order: 3 },
  { label: 'UX Engineering', order: 4 },
  { label: 'Technology', order: 5 },
  { label: 'Creative', order: 6 },
  { label: 'AI & ML', order: 7 },
];

export default function CaseStudies() {
  const { data } = useCaseStudiesData();
  const header = data?.sections?.caseStudiesHeader?.data || DEFAULT_HEADER;
  const ctaData = data?.sections?.cta?.data;
  const categories =
    Array.isArray(data?.collections?.caseStudyCategories) && data.collections.caseStudyCategories.length
      ? data.collections.caseStudyCategories
      : DEFAULT_CATEGORIES;
  const items = Array.isArray(data?.collections?.caseStudies) ? data.collections.caseStudies : [];

  const [activeCat, setActiveCat] = useState('All');
  const [page, setPage] = useState(1);

  const filtered = useMemo(() => {
    if (activeCat === 'All') return items;
    return items.filter((c) => (c.category || '').toLowerCase() === activeCat.toLowerCase());
  }, [items, activeCat]);

  const featured = filtered[0];
  const rest = filtered.slice(1);
  const totalPages = Math.max(1, Math.ceil(rest.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);
  const pageItems = rest.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);

  return (
    <>
      {/* ─── Immersive header ───────────────────────────────────────────── */}
      <section className="relative pt-32 pb-16 sm:pt-40 sm:pb-20 overflow-hidden bg-sky-50">
        <AnimatedMesh />
        <div className="container mx-auto relative">
          <SectionHeading title={header.heading} subtitle={header.subhead} align="center" />
        </div>
      </section>

      {/* ─── Filter tabs with sliding indicator ─────────────────────────── */}
      <section className="bg-sky-50 pb-2">
        <div className="container mx-auto">
          <div
            role="tablist"
            data-testid="cs-filter-tabs"
            className="flex flex-wrap justify-center gap-2 sm:gap-3"
          >
            {categories.map((c) => {
              const isActive = activeCat === c.label;
              return (
                <button
                  key={c.label}
                  role="tab"
                  aria-selected={isActive}
                  data-testid={`cs-tab-${c.label.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`}
                  onClick={() => { setActiveCat(c.label); setPage(1); }}
                  className="relative isolate px-5 py-2.5 text-[11px] tracking-[0.18em] uppercase font-bold rounded-full focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60 transition-colors"
                >
                  {isActive && (
                    <motion.span
                      layoutId="cs-tab-pill"
                      transition={{ type: 'spring', stiffness: 380, damping: 32 }}
                      className="absolute inset-0 rounded-full bg-navy-deep shadow-card -z-10"
                    />
                  )}
                  <span className={isActive ? 'text-white' : 'text-navy/70 hover:text-navy'}>{c.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* ─── Featured Spotlight ─────────────────────────────────────────── */}
      <section className="py-20 sm:py-24 bg-sky-50">
        <div className="container mx-auto">
          <AnimatePresence mode="wait">
            {featured && (
              <motion.div
                key={featured.slug || 'featured'}
                initial={{ opacity: 0, y: 24 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -16 }}
                transition={{ duration: 0.5, ease: EASE }}
                data-testid="cs-featured"
              >
                <FeaturedCard cs={featured} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>

      {/* ─── Editorial grid with layout reflow ──────────────────────────── */}
      <section className="pb-24 sm:pb-32 bg-sky-50">
        <div className="container mx-auto">
          <motion.div
            layout
            data-testid="cs-grid"
            className="grid grid-cols-1 md:grid-cols-6 gap-6"
          >
            <AnimatePresence mode="popLayout">
              {pageItems.map((cs, idx) => (
                <CaseStudyCard
                  key={cs.id || cs.slug || idx}
                  cs={cs}
                  index={idx}
                  /* Light masonry rhythm: alternate 3-col / 3-col with one wide row */
                  span={idx === 0 || idx === 3 ? 'md:col-span-4' : 'md:col-span-2'}
                />
              ))}
            </AnimatePresence>
          </motion.div>

          {filtered.length === 0 && (
            <p className="text-center text-slatebody text-sm mt-8 italic">
              No case studies in this category yet.
            </p>
          )}

          {totalPages > 1 && (
            <Pagination
              page={safePage}
              totalPages={totalPages}
              onChange={(n) => { setPage(n); window.scrollTo({ top: window.scrollY - 100, behavior: 'smooth' }); }}
            />
          )}
        </div>
      </section>

      <CtaBand data={ctaData} />
    </>
  );
}

/* ─── Featured card ─────────────────────────────────────────────────────── */

function FeaturedCard({ cs }) {
  const reducedMotion = useReducedMotion();
  return (
    <Link
      to={`/case-studies/${cs.slug}`}
      data-testid="cs-featured-link"
      aria-label={`Read flagship case study: ${cs.title}`}
      className="group relative grid lg:grid-cols-12 gap-0 rounded-3xl overflow-hidden border border-hairline shadow-[0_14px_38px_rgba(31,45,69,0.10)] hover:shadow-[0_22px_56px_rgba(31,45,69,0.16)] transition-shadow duration-500 bg-white focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60"
    >
      <div className="lg:col-span-7 relative aspect-[16/10] lg:aspect-auto lg:h-[440px] overflow-hidden card-sheen bg-sky-100">
        {cs.img ? (
          <motion.img
            layoutId={reducedMotion ? undefined : `cs-hero-${cs.slug}`}
            src={cs.img}
            alt={cs.title}
            loading="eager"
            className="absolute inset-0 w-full h-full object-cover transition-transform duration-[1.4s] ease-out group-hover:scale-[1.06] will-change-transform"
          />
        ) : (
          <ImagePlaceholder />
        )}
        <div className="absolute inset-0 bg-gradient-to-tr from-navy-deep/30 via-navy-deep/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        {cs.metric && (
          <div className="absolute top-5 left-5 px-3 py-1.5 rounded-full bg-white/95 backdrop-blur text-[11px] tracking-[0.14em] uppercase font-bold text-navy">
            {cs.metric}
          </div>
        )}
      </div>
      <div className="lg:col-span-5 p-7 sm:p-10 lg:p-14 flex flex-col justify-center bg-white">
        <p className="text-[11px] font-bold tracking-[0.2em] uppercase text-brandblue">
          Featured · {cs.category || 'Case Study'}
        </p>
        <h2 className="mt-4 text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-navy-deep leading-[1.03] group-hover:text-[#C9962E] transition-colors duration-300">
          {cs.title}
        </h2>
        <div className="mt-6 flex items-center gap-3 text-[12px] text-slatebody">
          {cs.date && <span>{cs.date}</span>}
          {cs.read_time && (
            <>
              <span className="text-slatebody/40">·</span>
              <span className="inline-flex items-center gap-1">
                <Clock className="h-3 w-3" /> {cs.read_time}
              </span>
            </>
          )}
        </div>
        <span className="mt-10 inline-flex items-center gap-2 text-[12px] font-bold tracking-[0.18em] uppercase text-brandblue group-hover:text-navy-deep transition-colors">
          View case study
          <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1.5" />
        </span>
      </div>
    </Link>
  );
}

/* ─── Grid card ─────────────────────────────────────────────────────────── */

function CaseStudyCard({ cs, index, span }) {
  const reducedMotion = useReducedMotion();
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 28, scale: 0.97 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -16, scale: 0.96 }}
      transition={{ duration: 0.5, delay: index * 0.05, ease: EASE }}
      whileHover={{ y: -6 }}
      className={`h-full ${span}`}
    >
      <Link
        to={`/case-studies/${cs.slug}`}
        aria-label={`Read case study: ${cs.title}`}
        data-testid={`cs-card-link-${index}`}
        className="group block h-full rounded-2xl overflow-hidden bg-white border border-hairline shadow-[0_10px_28px_rgba(31,45,69,0.08)] hover:shadow-[0_18px_36px_rgba(31,45,69,0.14)] transition-shadow duration-300 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60"
      >
        <div className="relative aspect-[16/10] overflow-hidden card-sheen bg-sky-100">
          {cs.img ? (
            <motion.img
              layoutId={reducedMotion ? undefined : `cs-hero-${cs.slug}`}
              src={cs.img}
              alt={cs.title}
              loading="lazy"
              className="w-full h-full object-cover transition-transform duration-[900ms] ease-out group-hover:scale-[1.08] will-change-transform"
            />
          ) : (
            <ImagePlaceholder />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-navy-deep/40 via-navy-deep/0 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          {/* Reveal-on-hover CTA */}
          <div className="absolute bottom-4 left-5 right-5 flex items-center justify-between opacity-0 -translate-y-1 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-500">
            <span className="text-[11px] font-bold tracking-[0.18em] uppercase text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.45)]">
              View case study
            </span>
            <span className="h-8 w-8 rounded-full bg-white text-navy inline-flex items-center justify-center shadow-card">
              <ArrowRight className="h-4 w-4" />
            </span>
          </div>
        </div>
        <div className="p-6">
          <p className="text-[11px] font-bold tracking-[0.2em] uppercase text-brandblue">
            {cs.category || 'Case Study'}
          </p>
          <h3 className="mt-3 text-[17px] font-semibold text-navy-deep leading-snug tracking-tight line-clamp-2 group-hover:text-[#C9962E] transition-colors duration-300">
            {cs.title}
          </h3>
          <div className="mt-5 flex items-center gap-3 text-[11px] text-slatebody">
            {cs.date && <span>{cs.date}</span>}
            {cs.date && cs.read_time && <span className="text-slatebody/40">·</span>}
            {cs.read_time && (
              <span className="inline-flex items-center gap-1">
                <Clock className="h-3 w-3" /> {cs.read_time}
              </span>
            )}
          </div>
        </div>
      </Link>
    </motion.div>
  );
}

/* ─── Branded image placeholder ─────────────────────────────────────────── */

function ImagePlaceholder() {
  return (
    <div
      aria-hidden="true"
      className="absolute inset-0 flex items-center justify-center"
      style={{ background: 'linear-gradient(135deg, #E6F1FB 0%, #C9DCEF 55%, #E8C25A20 100%)' }}
    >
      <ImageIcon className="h-10 w-10 text-navy/25" strokeWidth={1.4} />
    </div>
  );
}

/* ─── Pagination ────────────────────────────────────────────────────────── */

function Pagination({ page, totalPages, onChange }) {
  return (
    <div className="mt-12 flex items-center justify-center gap-2" data-testid="cs-pagination">
      <button
        aria-label="Previous page"
        disabled={page === 1}
        onClick={() => onChange(Math.max(1, page - 1))}
        className="h-9 w-9 rounded-full bg-white border border-hairline text-navy inline-flex items-center justify-center disabled:opacity-40 disabled:cursor-not-allowed hover:bg-navy-deep hover:text-white hover:border-transparent transition-colors"
      >
        <ChevronLeft className="h-4 w-4" />
      </button>
      {Array.from({ length: totalPages }, (_, k) => k + 1).map((n) => (
        <button
          key={n}
          aria-label={`Go to page ${n}`}
          onClick={() => onChange(n)}
          className={`h-9 w-9 rounded-full text-sm font-semibold inline-flex items-center justify-center transition-colors ${
            n === page
              ? 'bg-navy-deep text-white shadow-card'
              : 'bg-white border border-hairline text-navy hover:bg-navy-deep hover:text-white hover:border-transparent'
          }`}
        >
          {n}
        </button>
      ))}
      <button
        aria-label="Next page"
        disabled={page === totalPages}
        onClick={() => onChange(Math.min(totalPages, page + 1))}
        className="h-9 w-9 rounded-full bg-white border border-hairline text-navy inline-flex items-center justify-center disabled:opacity-40 disabled:cursor-not-allowed hover:bg-navy-deep hover:text-white hover:border-transparent transition-colors"
      >
        <ChevronRight className="h-4 w-4" />
      </button>
    </div>
  );
}

/* ─── Subtle animated mesh accent behind the header ─────────────────────── */

function AnimatedMesh() {
  const reducedMotion = useReducedMotion();
  return (
    <div className="absolute inset-0 pointer-events-none opacity-60 will-change-transform" aria-hidden="true">
      <motion.div
        className="absolute -top-32 -left-24 w-[520px] h-[520px] rounded-full blur-3xl"
        style={{ background: 'radial-gradient(circle, rgba(47,111,176,0.18), transparent 65%)' }}
        animate={reducedMotion ? {} : { x: [0, 18, 0], y: [0, 12, 0] }}
        transition={{ duration: 22, repeat: Infinity, ease: 'easeInOut' }}
      />
      <motion.div
        className="absolute -bottom-40 -right-24 w-[560px] h-[560px] rounded-full blur-3xl"
        style={{ background: 'radial-gradient(circle, rgba(201,150,46,0.16), transparent 65%)' }}
        animate={reducedMotion ? {} : { x: [0, -14, 0], y: [0, -10, 0] }}
        transition={{ duration: 26, repeat: Infinity, ease: 'easeInOut' }}
      />
    </div>
  );
}
