import React, { useMemo, useState } from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion';
import { Play, X, Quote, Star, ArrowRight } from 'lucide-react';

import SectionHeading from '@/components/brand/SectionHeading';
import { PrimaryButton } from '@/components/brand/Buttons';
import SpotlightCard from '@/components/brand/SpotlightCard';
import TestimonialModal from '@/components/brand/TestimonialModal';
import CtaBand from '@/components/sections/CtaBand';
import { viewportOnce } from '@/lib/motion';
import { useReviewsData } from '@/hooks/useReviewsData';

const EASE = [0.22, 1, 0.36, 1];
const PAGE_SIZE = 6;

/* ─── Static fallback (used if API fails) ─────────────────────────────── */
const FALLBACK = {
  sections: {
    reviewsHeader: {
      data: {
        kicker: 'Reviews',
        heading: "Take Our Clients' Word for It",
        subhead:
          "Do you want to know why so many businesses enjoy working with us? Here's what they have to say.",
      },
    },
  },
  collections: { reviews: [] },
};

/* YouTube/Vimeo embed URL extractor */
function toEmbedUrl(url) {
  if (!url) return null;
  try {
    const u = new URL(url);
    if (u.hostname.includes('youtu.be')) return `https://www.youtube.com/embed/${u.pathname.slice(1)}?autoplay=1`;
    if (u.hostname.includes('youtube.com')) {
      if (u.pathname.startsWith('/embed/')) return `${url}${url.includes('?') ? '&' : '?'}autoplay=1`;
      const v = u.searchParams.get('v');
      if (v) return `https://www.youtube.com/embed/${v}?autoplay=1`;
    }
    if (u.hostname.includes('vimeo.com')) return `https://player.vimeo.com/video/${u.pathname.slice(1)}?autoplay=1`;
    return url;
  } catch (e) {
    return null;
  }
}

function StarRow({ count = 5 }) {
  return (
    <div className="flex items-center gap-0.5" aria-label={`${count} out of 5 stars`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={`h-4 w-4 ${i < count ? 'text-[#E8C25A] fill-[#E8C25A]' : 'text-slatebody/30'}`}
          strokeWidth={1.5}
        />
      ))}
    </div>
  );
}

export default function Reviews() {
  const { data, loading } = useReviewsData();
  const reducedMotion = useReducedMotion();

  const payload = data || FALLBACK;
  const header = payload.sections?.reviewsHeader?.data || FALLBACK.sections.reviewsHeader.data;
  const reviews = payload.collections?.reviews || [];

  const videoReviews = useMemo(() => reviews.filter((r) => r.videoUrl), [reviews]);
  const textReviews = useMemo(() => reviews.filter((r) => !r.videoUrl), [reviews]);

  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const [openVideo, setOpenVideo] = useState(null);
  const [openTestimonial, setOpenTestimonial] = useState(null);

  const shownText = textReviews.slice(0, visibleCount);
  const hasMore = visibleCount < textReviews.length;

  return (
    <>
      {/* ─── Header ─────────────────────────────────────────────────── */}
      <section className="relative pt-36 pb-16 sm:pt-44 sm:pb-20 overflow-hidden bg-sky-50">
        <div
          aria-hidden="true"
          className="absolute inset-0 opacity-70 pointer-events-none"
          style={{
            background:
              'radial-gradient(700px 400px at 12% 18%, rgba(47,111,176,0.10), transparent 65%), radial-gradient(560px 320px at 88% 90%, rgba(232,194,90,0.10), transparent 70%)',
          }}
        />
        <div className="relative container mx-auto" data-testid="reviews-header">
          <SectionHeading
            eyebrow={header.kicker || 'Reviews'}
            title={header.heading}
            subtitle={header.subhead}
            align="center"
          />
        </div>
      </section>

      {/* ─── Featured video testimonials ────────────────────────────── */}
      {videoReviews.length > 0 && (
        <section className="py-16 sm:py-20 bg-white" data-testid="reviews-video-section">
          <div className="container mx-auto">
            <SectionHeading
              eyebrow="Featured"
              title="Hear it straight from our clients"
              subtitle="Tap any video to play their story."
              align="center"
            />
            <div className="mt-12 grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {videoReviews.map((r, i) => (
                <motion.button
                  key={r.id || r.name + i}
                  type="button"
                  onClick={() => setOpenVideo(r)}
                  initial={{ opacity: 0, y: 22 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={viewportOnce}
                  transition={{ duration: 0.55, delay: i * 0.06, ease: EASE }}
                  className="group relative rounded-2xl overflow-hidden bg-navy-deep text-left ring-1 ring-white/10 shadow-[0_10px_28px_rgba(15,25,45,0.08)] hover:shadow-[0_22px_50px_rgba(15,25,45,0.18)] transition-shadow focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60"
                  data-testid={`reviews-video-card-${i}`}
                  aria-label={`Play testimonial from ${r.name}`}
                >
                  <div className="relative aspect-[16/10] overflow-hidden">
                    <img
                      src={r.avatar}
                      alt={r.name}
                      loading="lazy"
                      className="absolute inset-0 w-full h-full object-cover opacity-65 group-hover:opacity-80 transition-opacity duration-500 scale-110 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-tr from-navy-deep/85 via-navy-deep/35 to-transparent" />
                    <span aria-hidden="true" className="absolute inset-0 flex items-center justify-center">
                      <span className="relative inline-flex items-center justify-center h-16 w-16 rounded-full bg-white/95 shadow-[0_10px_28px_rgba(0,0,0,0.35)] group-hover:scale-110 transition-transform duration-500">
                        <Play className="h-7 w-7 text-navy-deep translate-x-[1px]" fill="#0F192D" />
                        <span className="absolute inset-0 rounded-full ring-2 ring-white/40 animate-ping" />
                      </span>
                    </span>
                  </div>
                  <div className="p-5">
                    <StarRow count={r.rating || 5} />
                    <p className="mt-3 text-white text-base sm:text-lg leading-relaxed line-clamp-3">
                      &ldquo;{r.quote}&rdquo;
                    </p>
                    <div className="mt-4 flex items-center gap-3">
                      <img
                        src={r.avatar}
                        alt=""
                        aria-hidden="true"
                        className="h-9 w-9 rounded-full object-cover ring-2 ring-white/15"
                      />
                      <div>
                        <p className="text-sm font-semibold text-white">{r.name}</p>
                        <p className="text-xs text-white/70">
                          {r.role}
                          {r.role && r.company ? ' · ' : ''}
                          {r.company}
                        </p>
                      </div>
                    </div>
                  </div>
                </motion.button>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ─── Text testimonial grid ──────────────────────────────────── */}
      <section className="py-16 sm:py-20 bg-sky-50" data-testid="reviews-grid-section">
        <div className="container mx-auto">
          {videoReviews.length > 0 && (
            <SectionHeading eyebrow="More Voices" title="What it's like to work with MGS" align="center" />
          )}

          {textReviews.length === 0 && !loading && (
            <p className="mt-12 text-center text-base sm:text-lg text-slatebody">
              We&rsquo;re collecting fresh reviews — check back soon.
            </p>
          )}

          {textReviews.length > 0 && (
            <>
              <motion.div layout={!reducedMotion} className="mt-12 grid md:grid-cols-2 gap-6">
                {shownText.map((r, i) => (
                  <motion.button
                    type="button"
                    layout={!reducedMotion}
                    key={r.id || r.name + i}
                    initial={{ opacity: 0, y: 22 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={viewportOnce}
                    transition={{ duration: 0.5, delay: (i % PAGE_SIZE) * 0.05, ease: EASE }}
                    onClick={() => setOpenTestimonial(r)}
                    aria-label={`Read full testimonial from ${r.name}`}
                    className="text-left rounded-2xl focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60"
                    data-testid={`reviews-card-${i}`}
                  >
                    <SpotlightCard className="h-full rounded-2xl bg-white border border-hairline shadow-card p-6 sm:p-7 transition-shadow hover:shadow-soft cursor-pointer">
                      <Quote className="h-7 w-7 text-[#C9962E]/70" />
                      <div className="mt-3">
                        <StarRow count={r.rating || 5} />
                      </div>
                      <p className="mt-4 text-base sm:text-lg text-navy-deep leading-relaxed line-clamp-5">
                        &ldquo;{r.quote}&rdquo;
                      </p>
                      <div className="mt-6 flex items-center gap-3">
                        {r.avatar && (
                          <img
                            src={r.avatar}
                            alt=""
                            aria-hidden="true"
                            loading="lazy"
                            className="h-11 w-11 rounded-full object-cover ring-2 ring-white shadow-sm"
                          />
                        )}
                        <div>
                          <p className="text-sm font-bold text-navy-deep">{r.name}</p>
                          <p className="text-xs text-slatebody">
                            {[r.role, r.company].filter(Boolean).join(r.role && r.company ? ' of ' : '')}
                            {(r.role || r.company) && r.location ? ' · ' : ''}
                            {r.location || ''}
                          </p>
                        </div>
                      </div>
                    </SpotlightCard>
                  </motion.button>
                ))}
              </motion.div>

              {hasMore && (
                <div className="mt-12 text-center">
                  <PrimaryButton onClick={() => setVisibleCount((c) => c + PAGE_SIZE)} data-testid="reviews-load-more">
                    Load More <ArrowRight className="h-4 w-4 ml-1" />
                  </PrimaryButton>
                </div>
              )}
            </>
          )}
        </div>
      </section>

      <CtaBand />

      {/* ─── Video Lightbox ─────────────────────────────────────────── */}
      <AnimatePresence>
        {openVideo && (
          <motion.div
            role="dialog"
            aria-modal="true"
            aria-label="Video testimonial"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-[80] flex items-center justify-center bg-navy-deep/85 backdrop-blur-sm p-4"
            onClick={() => setOpenVideo(null)}
            data-testid="reviews-video-modal"
          >
            <motion.div
              initial={{ scale: 0.92, y: 12, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              transition={{ duration: 0.3, ease: EASE }}
              className="relative w-full max-w-4xl aspect-video rounded-2xl overflow-hidden bg-black ring-1 ring-white/10 shadow-[0_30px_70px_rgba(0,0,0,0.55)]"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                type="button"
                aria-label="Close video"
                onClick={() => setOpenVideo(null)}
                className="absolute top-3 right-3 z-10 h-9 w-9 inline-flex items-center justify-center rounded-full bg-white/90 hover:bg-white text-navy-deep transition-colors"
                data-testid="reviews-video-close"
              >
                <X className="h-4 w-4" />
              </button>
              {toEmbedUrl(openVideo.videoUrl) ? (
                <iframe
                  src={toEmbedUrl(openVideo.videoUrl)}
                  title={`Testimonial — ${openVideo.name}`}
                  className="absolute inset-0 w-full h-full"
                  allow="autoplay; encrypted-media; picture-in-picture"
                  allowFullScreen
                />
              ) : (
                <div className="absolute inset-0 flex items-center justify-center text-white/70 text-sm">
                  Unable to load this video right now.
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ─── Shared TestimonialModal ─────────────────────────────────── */}
      <TestimonialModal testimonial={openTestimonial} onClose={() => setOpenTestimonial(null)} />
    </>
  );
}
