import React from 'react';
import { motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, ChevronDown, Sparkles, BrainCircuit, Monitor, Smartphone, Building2, Palette, ShieldCheck, Bot, Boxes } from 'lucide-react';

import PageHero from '@/components/layout/PageHero';
import TiltCard from '@/components/brand/TiltCard';
import SpotlightCard from '@/components/brand/SpotlightCard';
import SectionHeading from '@/components/brand/SectionHeading';
import { PrimaryButton } from '@/components/brand/Buttons';
import CtaBand from '@/components/sections/CtaBand';
import { viewportOnce } from '@/lib/motion';
import { useServicesData } from '@/hooks/useServicesData';
import { resolveIcon } from '@/lib/iconMap';

/* ─── Static fallbacks (used while loading or if the API is unreachable) ──── */

const DEFAULT_HEADER = {
  heading: 'AI-First Services & Engineering',
  subhead:
    "From generative AI and intelligent agents to machine learning, computer vision, and full-stack web, mobile & enterprise engineering — production-ready solutions for clients worldwide. Let's talk.",
  crumb: 'Services',
};

const DEFAULT_INDUSTRIES_INTRO = {
  heading: 'Industries We Serve with Our AI & Software Development',
  paragraph:
    "We build software tailored to your industry's unique needs. Whether you're in finance, healthcare, retail, or beyond, our AI-driven development streamlines operations and gives you a competitive edge.",
};

const DEFAULT_PROJECTS_INTRO = { heading: 'Recent Projects', cta_label: 'Explore More' };

const DEFAULT_SERVICE_CARDS = [
  { title: 'Artificial Intelligence', desc: 'Generative AI, LLM apps, copilots, and intelligent automation built on GPT, Gemini, and Claude.', icon: Sparkles, image: 'https://images.unsplash.com/photo-1677756119517-756a188d2d94?w=900&q=70', highlighted: true },
  { title: 'Machine Learning', desc: 'Predictive models, recommendation engines, and decision intelligence trained on your data.', icon: BrainCircuit, image: 'https://images.unsplash.com/photo-1555255707-c07966088b7b?w=900&q=70' },
  { title: 'Web Development', desc: 'Cutting-edge, scalable web platforms tailored to elevate your online presence.', icon: Monitor, image: 'https://images.unsplash.com/photo-1551434678-e076c223a692?w=900&q=70' },
  { title: 'Mobile App Development', desc: 'High-performance iOS & Android apps with AI built into the core experience.', icon: Smartphone, image: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?w=900&q=70' },
  { title: 'Enterprise Application', desc: 'Robust ERP and enterprise platforms that streamline complex operations.', icon: Building2, image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=900&q=70' },
  { title: 'UI & UX Design', desc: 'User-centric, conversion-focused interfaces designed to engage and convert.', icon: Palette, image: 'https://images.unsplash.com/photo-1545235617-9465d2a55698?w=900&q=70' },
  { title: 'Testing & QA', desc: 'End-to-end quality assurance and AI evaluation pipelines for production reliability.', icon: ShieldCheck, image: 'https://images.unsplash.com/photo-1581090700227-1e37b190418e?w=900&q=70' },
  { title: 'Robotic Process Automation', desc: 'Automating repetitive workflows to cut cost and free your team for higher-value work.', icon: Bot, image: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=900&q=70' },
  { title: 'Blockchain', desc: 'Secure, transparent, decentralized solutions for modern business needs.', icon: Boxes, image: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=900&q=70' },
];

const DEFAULT_SERVICE_INDUSTRIES = [
  { label: 'Transportation & Logistics', icon: 'Truck' },
  { label: 'E-Commerce & Retail', icon: 'ShoppingCart' },
  { label: 'FinTech', icon: 'Banknote' },
  { label: 'Healthcare', icon: 'HeartPulse' },
  { label: 'Real Estate', icon: 'Building2' },
  { label: 'Education', icon: 'GraduationCap', highlighted: true },
  { label: 'Manufacturing', icon: 'Factory' },
  { label: 'Telecommunication', icon: 'Radio' },
  { label: 'Insurance', icon: 'ShieldCheck' },
  { label: 'Marketing & Advertising', icon: 'Megaphone' },
  { label: 'Public Services', icon: 'Landmark' },
  { label: 'Professional Services', icon: 'Briefcase' },
];

const DEFAULT_RECENT_PROJECTS = [
  { title: 'Helping Life Happen — a web app that drives financial literacy', image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1100&q=70', tech_stack: 'Laravel · Vue.js · CSS', link: '#' },
  { title: 'Data collection & reporting tools for IDM', image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1100&q=70', tech_stack: 'React · Node.js · PostgreSQL', link: '#' },
  { title: 'Workflow solution for a leading digitization company', image: 'https://images.unsplash.com/photo-1559028012-481c04fa702d?w=1100&q=70', tech_stack: 'Next.js · FastAPI · MongoDB', link: '#' },
];

/* ─── Page component ──────────────────────────────────────────────────────── */

export default function Services() {
  const { data } = useServicesData();
  const navigate = useNavigate();

  const header = data?.sections?.servicesHeader?.data || DEFAULT_HEADER;
  const indIntro = data?.sections?.servicesIndustriesIntro?.data || DEFAULT_INDUSTRIES_INTRO;
  const projIntro = data?.sections?.recentProjectsIntro?.data || DEFAULT_PROJECTS_INTRO;
  const ctaData = data?.sections?.cta?.data;

  const liveCards = data?.collections?.serviceCards;
  const serviceCards =
    Array.isArray(liveCards) && liveCards.length
      ? liveCards.map((c, i) => ({
          ...c,
          icon: resolveIcon(c.icon, DEFAULT_SERVICE_CARDS[i % DEFAULT_SERVICE_CARDS.length].icon),
        }))
      : DEFAULT_SERVICE_CARDS;

  const liveIndustries = data?.collections?.serviceIndustries;
  const industries =
    Array.isArray(liveIndustries) && liveIndustries.length ? liveIndustries : DEFAULT_SERVICE_INDUSTRIES;

  const liveProjects = data?.collections?.recentProjects;
  const projects = Array.isArray(liveProjects) && liveProjects.length ? liveProjects : DEFAULT_RECENT_PROJECTS;

  return (
    <>
      <PageHero title={header.heading} subtitle={header.subhead} crumb={header.crumb || 'Services'} />

      {/* ─── Services grid (image cards + overlapping icon) ─────────────── */}
      <section id="services-grid" className="py-16 bg-sky-50">
        <div className="container mx-auto">
          <div
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            data-testid="services-grid"
          >
            {serviceCards.map((c, i) => (
              <ServiceCard key={c.id || c.title || i} card={c} index={i} />
            ))}
          </div>

          <div className="mt-12 flex justify-center">
            <Link to="/contact">
              <PrimaryButton
                data-testid="services-lets-connect"
                icon={<ArrowRight className="h-4 w-4" />}
              >
                Let&apos;s Connect
              </PrimaryButton>
            </Link>
          </div>
        </div>
      </section>

      {/* ─── Industries we serve (icon chips) ───────────────────────────── */}
      <section className="py-20 bg-white">
        <div className="container mx-auto">
          <SectionHeading
            title={indIntro.heading}
            subtitle={indIntro.paragraph}
            align="center"
          />

          <div
            className="mt-12 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4"
            data-testid="service-industries-grid"
          >
            {industries.map((it, i) => (
              <IndustryChip key={it.id || it.label || i} item={it} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* ─── Recent Projects ─────────────────────────────────────────────── */}
      <section className="py-20 bg-sky-50">
        <div className="container mx-auto">
          <SectionHeading title={projIntro.heading} align="center" />

          <div
            className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-6"
            data-testid="recent-projects-grid"
          >
            {projects.map((p, i) => (
              <ProjectCard key={p.id || p.title || i} project={p} index={i} />
            ))}
          </div>

          <div className="mt-12 flex justify-center">
            <PrimaryButton
              data-testid="services-explore-more"
              icon={<ChevronDown className="h-4 w-4" />}
              onClick={() => navigate('/case-studies')}
            >
              {projIntro.cta_label || 'Explore More'}
            </PrimaryButton>
          </div>
        </div>
      </section>

      {/* Reuse the home CtaBand — pulls data from /api/page/services sections.cta if seeded */}
      <CtaBand data={ctaData} />
    </>
  );
}

/* ─── Sub-components ─────────────────────────────────────────────────────── */

function ServiceCard({ card, index = 0 }) {
  const Icon = card.icon || Sparkles;
  const highlighted = !!card.highlighted;
  return (
    <motion.div
      initial={{ opacity: 0, y: 32, scale: 0.96 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={viewportOnce}
      transition={{ duration: 0.6, delay: index * 0.06, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -8 }}
      className="h-full"
    >
      <Link
        to="/contact"
        aria-label={`Get in touch about ${card.title}`}
        data-testid={`service-card-link-${index}`}
        className="block h-full rounded-2xl focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60"
      >
        <TiltCard
          className={`group relative h-full rounded-2xl overflow-hidden border shadow-card transition-shadow duration-300 hover:shadow-[0_20px_44px_rgba(31,45,69,0.18)] cursor-pointer ${
            highlighted ? 'border-transparent' : 'border-hairline'
          } bg-white`}
        >
        {/* Background image (or solid gradient on highlighted) */}
        <div className="relative h-44 overflow-hidden card-sheen">
          {card.image ? (
            <img
              src={card.image}
              alt={card.title}
              loading="lazy"
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-[900ms] ease-out group-hover:scale-[1.12]"
            />
          ) : (
            <div className="absolute inset-0 bg-gradient-to-br from-brandblue to-navy-deep" />
          )}
          {/* Gradient overlay differs by highlighted state */}
          <div
            className={`absolute inset-0 transition-opacity duration-500 ${
              highlighted
                ? 'bg-gradient-to-br from-[#2F6FB0]/85 via-[#2BA8E0]/65 to-[#1F2D45]/85'
                : 'bg-gradient-to-t from-navy-deep/60 via-navy-deep/10 to-transparent group-hover:from-navy-deep/40'
            }`}
          />
          {highlighted && (
            <div className="absolute inset-0 p-6 flex flex-col justify-center">
              <h3 className="text-white text-2xl font-bold leading-tight drop-shadow-[0_2px_4px_rgba(0,0,0,0.25)]">{card.title}</h3>
              <p className="mt-2 text-white/90 text-sm leading-relaxed max-w-xs">{card.desc}</p>
            </div>
          )}
        </div>

        {/* Overlapping circular icon (top-left of bottom band) */}
        <div className="relative px-6">
          <motion.div
            whileHover={{ rotate: -10, scale: 1.15 }}
            transition={{ type: 'spring', stiffness: 340, damping: 16 }}
            className="absolute -top-6 left-6 h-12 w-12 rounded-full bg-white shadow-card border border-hairline inline-flex items-center justify-center transition-all duration-300 group-hover:shadow-gold group-hover:border-[#C9962E]/40"
          >
            <Icon className="h-5 w-5 text-brandblue group-hover:text-[#C9962E] transition-colors duration-300" />
          </motion.div>
        </div>

        {/* Bottom band: title (and desc when not highlighted) */}
        {!highlighted && (
          <div className="p-6 pt-9">
            <h3 className="text-base font-semibold text-navy leading-tight transition-colors duration-300 group-hover:text-[#C9962E]">
              {card.title}
            </h3>
            {card.desc && (
              <p className="mt-2 text-[13px] text-slatebody leading-relaxed line-clamp-3">{card.desc}</p>
            )}
          </div>
        )}
        {highlighted && <div className="p-6 pt-9" />}
      </TiltCard>
      </Link>
    </motion.div>
  );
}

function IndustryChip({ item, index = 0 }) {
  const Icon = resolveIcon(item.icon, Building2);
  return (
    <motion.div
      initial={{ opacity: 0, y: 24, scale: 0.96 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={viewportOnce}
      transition={{ duration: 0.55, delay: index * 0.05, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -6, scale: 1.02 }}
      className="h-full"
    >
      <Link
        to="/contact"
        aria-label={`Get in touch about ${item.label}`}
        data-testid={`industry-chip-link-${index}`}
        className="block h-full rounded-2xl focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60"
      >
        <SpotlightCard
          className="h-full rounded-2xl border border-hairline overflow-hidden cursor-pointer group chip-hover-shadow"
          surfaceClassName="chip-hover-fill"
        >
          <div className="px-5 py-7 text-center relative">
            <motion.div
              whileHover={{ rotate: -8, scale: 1.12 }}
              transition={{ type: 'spring', stiffness: 320, damping: 16 }}
              className="mx-auto h-12 w-12 rounded-full inline-flex items-center justify-center bg-sky-100 text-brandblue transition-all duration-500 group-hover:bg-white group-hover:text-[#C9962E] group-hover:shadow-[0_8px_20px_rgba(255,255,255,0.45)]"
            >
              <Icon className="h-5 w-5" />
            </motion.div>
            <div className="mt-3 text-sm leading-tight tracking-wide font-semibold text-navy transition-all duration-500 group-hover:text-white group-hover:font-bold group-hover:drop-shadow-[0_2px_4px_rgba(0,0,0,0.45)]">
              {item.label}
            </div>
          </div>
        </SpotlightCard>
      </Link>
    </motion.div>
  );
}

function ProjectCard({ project, index = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 32, scale: 0.96 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={viewportOnce}
      transition={{ duration: 0.6, delay: index * 0.08, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -8 }}
      className="h-full"
    >
      <Link
        to="/case-studies"
        aria-label={`See case study: ${project.title}`}
        data-testid={`project-card-link-${index}`}
        className="block h-full rounded-2xl focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60"
      >
        <TiltCard className="group h-full rounded-2xl overflow-hidden bg-white border border-hairline shadow-card hover:shadow-[0_20px_44px_rgba(31,45,69,0.18)] transition-shadow duration-300 cursor-pointer">
          <div className="relative h-44 overflow-hidden card-sheen">
            {project.image && (
              <img
                src={project.image}
                alt={project.title}
                loading="lazy"
                className="w-full h-full object-cover transition-transform duration-[900ms] ease-out group-hover:scale-[1.12]"
              />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-navy-deep/30 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          </div>
          <div className="p-5">
            <h4 className="text-sm font-semibold text-navy leading-snug line-clamp-2 transition-colors duration-300 group-hover:text-[#C9962E]">
              {project.title}
            </h4>
            {project.tech_stack && (
              <p className="mt-2 text-[12px] text-slatebody">
                <span className="font-semibold text-navy/80">Tech Stack:</span> {project.tech_stack}
              </p>
            )}
            <span className="mt-3 inline-flex items-center gap-1 text-[12px] font-semibold text-brandblue group-hover:text-[#C9962E] transition-colors">
              View project
              <ArrowRight className="h-3 w-3 transition-transform duration-300 group-hover:translate-x-1" />
            </span>
          </div>
        </TiltCard>
      </Link>
    </motion.div>
  );
}
