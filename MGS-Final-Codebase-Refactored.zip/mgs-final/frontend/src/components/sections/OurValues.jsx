import React from 'react';
import { motion } from 'framer-motion';
import { Users, Award, Handshake, Sparkles } from 'lucide-react';
import { fadeUp, staggerParent, viewportOnce } from '@/lib/motion';
import SectionHeading from '@/components/brand/SectionHeading';
import { HOME } from '@/constants/testIds';
import { resolveIcon } from '@/lib/iconMap';

const DEFAULT_VALUES = [
  {
    title: 'Team Work',
    icon: Users,
    desc: 'Cross-functional pods of engineers, designers, and ML specialists working as your extended team.',
    img: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=900&q=70',
  },
  {
    title: 'Quality',
    icon: Award,
    desc: 'Hardened delivery process, end-to-end QA, and AI evaluation pipelines for production reliability.',
    img: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=900&q=70',
  },
  {
    title: 'Long Relationship',
    icon: Handshake,
    desc: 'We invest in long-term partnerships — many of our clients have been with us for 5+ years.',
    img: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?w=900&q=70',
  },
  {
    title: 'Dedication',
    icon: Sparkles,
    desc: 'Outcome-focused teams that own delivery and continuously improve until success metrics are hit.',
    img: 'https://images.unsplash.com/photo-1521791136064-7986c2920216?w=900&q=70',
  },
];

const DEFAULT_HEADING = 'Our Values';
const DEFAULT_SUBTITLE =
  "With a focus on innovation and outcomes, we build AI and software solutions tailored to each client's unique goals — helping them achieve real business results efficiently.";
const DEFAULT_CERTS = ['ISO 9001', 'ISO 27001', 'SOC 2 Type II', 'GDPR', 'NASSCOM', 'CMMI Level 3'];

export default function OurValues({ data, items }) {
  const heading = data?.heading || DEFAULT_HEADING;
  const subtitle = data?.subtitle || DEFAULT_SUBTITLE;
  const certs =
    Array.isArray(data?.certifications) && data.certifications.length
      ? data.certifications
      : DEFAULT_CERTS;
  const values =
    Array.isArray(items) && items.length
      ? items.map((v, idx) => ({
          ...v,
          icon: resolveIcon(v.icon, DEFAULT_VALUES[idx % DEFAULT_VALUES.length].icon),
        }))
      : DEFAULT_VALUES;
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={viewportOnce}
            className="text-center mb-12"
          >
            <SectionHeading
              title={heading}
              subtitle={subtitle}
              align="center"
            />
          </motion.div>

        <motion.div
          data-testid={HOME.valuesGrid}
          variants={staggerParent(0.08)}
          initial="hidden"
          whileInView="show"
          viewport={viewportOnce}
          className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5"
        >
          {values.map((v) => {
            const Icon = v.icon;
            return (
              <motion.div
                key={v.title}
                variants={fadeUp}
                whileHover={{ y: -6 }}
                className="group relative rounded-2xl overflow-hidden border border-hairline bg-sky-50 shadow-card"
              >
                <div className="relative h-32 overflow-hidden">
                  <img
                    src={v.img}
                    alt={v.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-deep/80 to-transparent" />
                  <div className="absolute bottom-3 left-3 flex items-center gap-2">
                    <span className="h-8 w-8 rounded-lg bg-gold-gradient inline-flex items-center justify-center">
                      <Icon className="h-4 w-4 text-white" />
                    </span>
                    <h3 className="text-white font-semibold">{v.title}</h3>
                  </div>
                </div>
                <div className="p-5">
                  <p className="text-sm text-slatebody leading-relaxed">{v.desc}</p>
                </div>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Certification strip */}
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={viewportOnce}
          className="mt-10 flex flex-wrap items-center justify-center gap-3"
        >
          {certs.map((b) => (
            <span
              key={b}
              className="text-[12px] font-semibold px-3 py-1.5 rounded-full bg-sky-100 text-navy border border-hairline"
            >
              {b}
            </span>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
