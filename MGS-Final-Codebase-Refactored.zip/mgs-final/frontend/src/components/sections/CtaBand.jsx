import React, { useState } from 'react';
import axios from 'axios';
import { motion } from 'framer-motion';
import { ShieldCheck, Star, TrendingUp, Briefcase, ArrowRight, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { PrimaryButton, SecondaryButton } from '@/components/brand/Buttons';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { fadeUp, viewportOnce } from '@/lib/motion';
import { HOME } from '@/constants/testIds';

const DEFAULT_BADGES = [
  { label: 'Clutch', score: '5.0', icon: Star },
  { label: 'Trustpilot', score: '5.0', icon: ShieldCheck },
  { label: 'techreviewer', score: '5.0', icon: TrendingUp },
  { label: 'glassdoor', score: '5.0', icon: Briefcase },
];

const BADGE_ICONS_BY_INDEX = [Star, ShieldCheck, TrendingUp, Briefcase];
const DEFAULT_FORM_TITLE = 'What can we help you with?';
const DEFAULT_REASSURANCE =
  "We'll never share your details with third parties. We won't spam you.";

const EMPTY = { name: '', email: '', country: 'us', phone: '', brief: '' };

export default function CtaBand({ data }) {
  const [form, setForm] = useState(EMPTY);
  const [loading, setLoading] = useState(false);

  const badges =
    Array.isArray(data?.badges) && data.badges.length
      ? data.badges.map((b, idx) => ({
          ...b,
          icon: b.icon && typeof b.icon === 'function'
            ? b.icon
            : BADGE_ICONS_BY_INDEX[idx % BADGE_ICONS_BY_INDEX.length],
        }))
      : DEFAULT_BADGES;
  const formTitle = data?.form_title || DEFAULT_FORM_TITLE;
  const reassurance = data?.reassurance || DEFAULT_REASSURANCE;

  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const onSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await axios.post(`${process.env.REACT_APP_BACKEND_URL}/api/contact`, {
        name: form.name,
        email: form.email,
        phone: form.phone || undefined,
        country: form.country || undefined,
        brief: form.brief || undefined,
      });
      toast.success("Message sent! We'll reach out within one business day.");
      setForm(EMPTY);
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <section
      id="cta"
      className="py-24 relative overflow-hidden"
      style={{
        background:
          'linear-gradient(120deg, #1F2D45 0%, #2F6FB0 45%, #C9962E 100%)',
      }}
    >
      {/* subtle particles */}
      <svg className="absolute inset-0 w-full h-full opacity-[0.08]" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="ctadots" x="0" y="0" width="28" height="28" patternUnits="userSpaceOnUse">
            <circle cx="2" cy="2" r="1.2" fill="#fff" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#ctadots)" />
      </svg>

      <div className="container mx-auto grid lg:grid-cols-2 gap-10 items-center relative">
        {/* Left */}
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={viewportOnce}
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white leading-tight">
            Gain An Upper Edge
            <br />
            Over Your Competitors
            <br />
            With <span className="text-[#FFD988]">AI-Driven Development</span>
          </h2>

          <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-3">
            {badges.map((b) => {
              const Icon = b.icon;
              return (
                <div
                  key={b.label}
                  className="rounded-xl bg-white/12 backdrop-blur px-3 py-2.5 border border-white/15"
                >
                  <div className="flex items-center gap-2">
                    <Icon className="h-4 w-4 text-[#FFD988]" />
                    <span className="text-[11px] text-white/85 font-semibold">{b.label}</span>
                  </div>
                  <div className="text-white font-bold mt-0.5">{b.score}</div>
                </div>
              );
            })}
          </div>

          <div className="mt-7">
            <SecondaryButton
              className="bg-white text-navy"
              icon={<ArrowRight className="h-4 w-4" />}
            >
              Let's Connect
            </SecondaryButton>
          </div>
        </motion.div>

        {/* Right - form */}
        <motion.form
          data-testid={HOME.ctaForm}
          onSubmit={onSubmit}
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={viewportOnce}
          className="rounded-2xl bg-white p-7 shadow-soft border border-white/30"
        >
          <h3 className="text-xl font-bold text-navy-deep">{formTitle}</h3>

          <div className="mt-5 grid gap-4">
            <div>
              <Label htmlFor="full-name" className="text-xs text-slatebody">Full Name</Label>
              <Input id="full-name" placeholder="John Doe" required value={form.name}
                onChange={(e) => set('name', e.target.value)} className="mt-1 rounded-lg border-hairline" />
            </div>
            <div>
              <Label htmlFor="email" className="text-xs text-slatebody">Business Email</Label>
              <Input id="email" type="email" placeholder="john@company.com" required value={form.email}
                onChange={(e) => set('email', e.target.value)} className="mt-1 rounded-lg border-hairline" />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <Label className="text-xs text-slatebody">Country</Label>
                <Select value={form.country} onValueChange={(v) => set('country', v)}>
                  <SelectTrigger className="mt-1 rounded-lg border-hairline"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="us">🇺🇸 US</SelectItem>
                    <SelectItem value="in">🇮🇳 IN</SelectItem>
                    <SelectItem value="uk">🇬🇧 UK</SelectItem>
                    <SelectItem value="de">🇩🇪 DE</SelectItem>
                    <SelectItem value="ae">🇦🇪 AE</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="col-span-2">
                <Label htmlFor="phone" className="text-xs text-slatebody">Phone Number</Label>
                <Input id="phone" placeholder="+1 555 000 0000" value={form.phone}
                  onChange={(e) => set('phone', e.target.value)} className="mt-1 rounded-lg border-hairline" />
              </div>
            </div>
            <div>
              <Label htmlFor="brief" className="text-xs text-slatebody">Requirement Brief</Label>
              <Textarea id="brief" placeholder="Tell us about your AI project…" rows={3}
                value={form.brief} onChange={(e) => set('brief', e.target.value)}
                className="mt-1 rounded-lg border-hairline resize-none" />
            </div>
          </div>

          <div className="mt-5">
            <PrimaryButton
              data-testid={HOME.ctaSubmit}
              type="submit"
              disabled={loading}
              className="w-full"
              icon={loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowRight className="h-4 w-4" />}
            >
              {loading ? 'Sending…' : 'Get Started'}
            </PrimaryButton>
          </div>

          <p className="mt-3 text-[11px] text-slatebody text-center">
            {reassurance}
          </p>
        </motion.form>
      </div>
    </section>
  );
}
