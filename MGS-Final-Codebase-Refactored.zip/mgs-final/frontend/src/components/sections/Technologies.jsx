import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { PrimaryButton } from '@/components/brand/Buttons';
import { fadeUp, staggerParent, viewportOnce } from '@/lib/motion';
import SectionHeading from '@/components/brand/SectionHeading';
import { HOME } from '@/constants/testIds';

const techTabs = [
  { id: 'ai', label: 'AI / ML' },
  { id: 'frontend', label: 'Frontend' },
  { id: 'backend', label: 'Backend' },
  { id: 'mobile', label: 'Mobile' },
  { id: 'ecom', label: 'E-Commerce' },
  { id: 'db', label: 'Database' },
];

// using cdn.simpleicons.org which renders SVG by slug & hex color
const icon = (slug, color) => `https://cdn.simpleicons.org/${slug}/${color}`;

const DEFAULT_TECHS = {
  ai: [
    { name: 'OpenAI', img: icon('openai', '412991') },
    { name: 'Claude', img: icon('anthropic', 'D97757') },
    { name: 'Gemini', img: icon('googlegemini', '8E75B2') },
    { name: 'LangChain', img: icon('langchain', '1C3C3C') },
    { name: 'LlamaIndex', img: icon('meta', '0867EC') },
    { name: 'Hugging Face', img: icon('huggingface', 'FFD21E') },
    { name: 'PyTorch', img: icon('pytorch', 'EE4C2C') },
    { name: 'TensorFlow', img: icon('tensorflow', 'FF6F00') },
    { name: 'scikit-learn', img: icon('scikitlearn', 'F7931E') },
    { name: 'OpenCV', img: icon('opencv', '5C3EE8') },
    { name: 'FastAPI', img: icon('fastapi', '009688') },
    { name: 'Python', img: icon('python', '3776AB') },
  ],
  frontend: [
    { name: 'React', img: icon('react', '61DAFB') },
    { name: 'Next.js', img: icon('nextdotjs', '000000') },
    { name: 'Angular', img: icon('angular', 'DD0031') },
    { name: 'Vue.js', img: icon('vuedotjs', '4FC08D') },
    { name: 'HTML5', img: icon('html5', 'E34F26') },
    { name: 'Tailwind', img: icon('tailwindcss', '06B6D4') },
  ],
  backend: [
    { name: 'Node.js', img: icon('nodedotjs', '339933') },
    { name: 'Python', img: icon('python', '3776AB') },
    { name: 'FastAPI', img: icon('fastapi', '009688') },
    { name: '.NET', img: icon('dotnet', '512BD4') },
    { name: 'ASP.NET', img: icon('dotnet', '512BD4') },
  ],
  mobile: [
    { name: 'React Native', img: icon('react', '61DAFB') },
    { name: 'Flutter', img: icon('flutter', '02569B') },
  ],
  ecom: [
    { name: 'Shopify', img: icon('shopify', '7AB55C') },
    { name: 'Magento', img: icon('magento', 'EE672F') },
    { name: 'WooCommerce', img: icon('woocommerce', '96588A') },
  ],
  db: [
    { name: 'PostgreSQL', img: icon('postgresql', '4169E1') },
    { name: 'MongoDB', img: icon('mongodb', '47A248') },
    { name: 'AWS', img: icon('amazonaws', 'FF9900') },
    { name: 'Azure', img: icon('microsoftazure', '0078D4') },
    { name: 'GCP', img: icon('googlecloud', '4285F4') },
  ],
};

const DEFAULT_TITLE = 'Technologies & Platform';
const DEFAULT_SUBTITLE = 'A merged AI + full-stack engineering toolbox.';

export default function Technologies({ data, items }) {
  const title = data?.title || DEFAULT_TITLE;
  const subtitle = data?.subtitle || DEFAULT_SUBTITLE;

  // Group live items by category, with default fallback per category.
  const techs = (() => {
    if (Array.isArray(items) && items.length) {
      const grouped = {};
      items.forEach((t) => {
        const key = t.category || 'ai';
        if (!grouped[key]) grouped[key] = [];
        grouped[key].push({ name: t.name, img: t.img });
      });
      // ensure every tab has at least the default fallback
      techTabs.forEach((tab) => {
        if (!grouped[tab.id]?.length) grouped[tab.id] = DEFAULT_TECHS[tab.id] || [];
      });
      return grouped;
    }
    return DEFAULT_TECHS;
  })();
  return (
    <section className="py-20 bg-sky-100/60">
      <div className="container mx-auto">
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={viewportOnce}
          className="text-center mb-10"
        >
          <SectionHeading
            title={title}
            subtitle={subtitle}
            align="center"
          />
        </motion.div>

        <Tabs defaultValue="ai" data-testid={HOME.technologiesTabs}>
          <div className="flex justify-center">
            <TabsList className="bg-white border border-hairline p-1.5 rounded-full flex flex-wrap gap-1 h-auto">
              {techTabs.map((t) => (
                <TabsTrigger
                  key={t.id}
                  value={t.id}
                  className="rounded-full px-4 py-2 text-xs font-semibold data-[state=active]:bg-gold-gradient data-[state=active]:text-white data-[state=active]:shadow-gold text-navy/70"
                >
                  {t.label}
                </TabsTrigger>
              ))}
            </TabsList>
          </div>

          {techTabs.map((t) => (
            <TabsContent key={t.id} value={t.id} className="mt-10">
              <motion.div
                key={t.id}
                variants={staggerParent(0.05)}
                initial="hidden"
                animate="show"
                className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-6"
              >
                {(techs[t.id] || []).map((tech) => (
                  <motion.div
                    key={tech.name}
                    variants={fadeUp}
                    className="flex flex-col items-center text-center"
                  >
                    <div className="h-12 w-12 rounded-xl bg-white border border-hairline shadow-card flex items-center justify-center overflow-hidden gscale">
                      <img
                        src={tech.img}
                        alt=""
                        className="h-7 w-7 object-contain"
                        loading="lazy"
                        onError={(e) => {
                          e.currentTarget.style.display = 'none';
                          e.currentTarget.parentElement.innerHTML =
                            `<span class="text-[11px] font-bold text-navy">${tech.name.slice(0, 3).toUpperCase()}</span>`;
                        }}
                      />
                    </div>
                    <span className="mt-2 text-xs text-slatebody">{tech.name}</span>
                  </motion.div>
                ))}
              </motion.div>
            </TabsContent>
          ))}
        </Tabs>

        <div className="flex justify-center mt-10">
          <PrimaryButton icon={<ArrowRight className="h-4 w-4" />}>Explore More</PrimaryButton>
        </div>
      </div>
    </section>
  );
}
