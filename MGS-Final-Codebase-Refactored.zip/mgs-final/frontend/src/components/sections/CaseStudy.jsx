import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { Pause, Play, ArrowRight } from 'lucide-react';
import { PrimaryButton } from '@/components/brand/Buttons';
import { HOME } from '@/constants/testIds';

const DEFAULT_STUDIES = [
  {
    brand: 'circle',
    title: 'AI lead-qualification for a property platform',
    img: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=1100&q=70',
    metric: '+38% qualified leads',
  },
  {
    brand: 'stari',
    title: 'Generative AI booking concierge for hospitality',
    img: 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=1100&q=70',
    metric: '−42% support tickets',
  },
  {
    brand: 'avon.',
    title: 'Computer-vision quality control on the factory floor',
    img: 'https://images.unsplash.com/photo-1565728744382-61accd4aa148?w=1100&q=70',
    metric: '99.2% defect catch-rate',
  },
];

const DEFAULT_HEADING = 'Case Study';

export default function CaseStudy({ data, items }) {
  const heading = data?.heading || DEFAULT_HEADING;
  const studies = Array.isArray(items) && items.length ? items : DEFAULT_STUDIES;
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (paused) return;
    const t = setInterval(() => setI((v) => (v + 1) % studies.length), 4500);
    return () => clearInterval(t);
  }, [paused, studies.length]);

  return (
    <section
      id="case-study"
      className="py-24 relative overflow-hidden"
      style={{
        background:
          'linear-gradient(180deg, #2F6FB0 0%, #537EA8 60%, #E8C25A 100%)',
      }}
    >
      <div className="container mx-auto text-center">
        <h2 className="text-3xl sm:text-4xl font-bold text-white">{heading}</h2>
      </div>

      <div
        className="container mx-auto mt-10"
        data-testid={HOME.caseStudyCarousel}
        onMouseEnter={() => setPaused(true)}
        onMouseLeave={() => setPaused(false)}
      >
        <div className="grid lg:grid-cols-3 gap-6">
          {studies.map((s, idx) => {
            const Inner = (
              <>
                <div className="h-12 flex items-center px-5 border-b border-hairline bg-sky-50">
                  <span className="text-sm font-bold text-navy lowercase">{s.brand}</span>
                </div>
                <div className="relative h-48 overflow-hidden">
                  <img src={s.img} alt={s.title} className="w-full h-full object-cover" />
                  <div className="absolute bottom-3 right-3 text-[11px] bg-navy-deep/85 text-white px-2 py-1 rounded-full">
                    {s.metric}
                  </div>
                </div>
                <div className="p-5">
                  <p className="text-sm text-navy font-medium leading-snug">{s.title}</p>
                </div>
              </>
            );
            return (
              <motion.article
                key={s.id || s.brand || idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.6, delay: idx * 0.08, ease: [0.22, 1, 0.36, 1] }}
                animate={{
                  scale: idx === i ? 1.04 : 1,
                  boxShadow: idx === i ? '0 30px 80px rgba(31,45,69,0.25)' : '0 8px 30px rgba(31,45,69,0.12)',
                }}
                className="rounded-2xl bg-white overflow-hidden border border-white/30"
              >
                {s.slug ? (
                  <Link to={`/case-studies/${s.slug}`} className="block hover:opacity-95 transition-opacity">
                    {Inner}
                  </Link>
                ) : (
                  Inner
                )}
              </motion.article>
            );
          })}
        </div>

        <div className="mt-10 flex items-center justify-center gap-4">
          <button
            onClick={() => setPaused((v) => !v)}
            className="h-11 w-11 rounded-full bg-white/95 text-navy inline-flex items-center justify-center shadow-card hover:scale-105 transition"
            aria-label={paused ? 'Play' : 'Pause'}
          >
            {paused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
          </button>
          <PrimaryButton icon={<ArrowRight className="h-4 w-4" />} onClick={() => navigate('/case-studies')}>
            View Case Studies
          </PrimaryButton>
        </div>
      </div>
    </section>
  );
}
