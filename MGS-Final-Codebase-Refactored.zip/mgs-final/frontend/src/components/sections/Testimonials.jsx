import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Quote, ChevronLeft, ChevronRight } from 'lucide-react';
import { HOME } from '@/constants/testIds';
import TestimonialModal from '@/components/brand/TestimonialModal';

const DEFAULT_TESTIMONIALS = [
  {
    quote:
      "They're very willing to assemble the team that we ask for. The team we currently have is impressive — they keep their promises, and they always show up with bright ideas.",
    name: 'Jorge Quintero',
    role: 'Director',
    company: 'Fifty Blue',
    location: 'Dubai, UAE',
    avatar: 'https://i.pravatar.cc/120?img=12',
  },
  {
    quote:
      'MGS shipped our compliance copilot in 9 weeks. The RAG accuracy on our regulated content is well above what we expected.',
    name: 'Priya Menon',
    role: 'Head of AI',
    company: 'FintraCore',
    location: 'Bengaluru, India',
    avatar: 'https://i.pravatar.cc/120?img=47',
  },
  {
    quote:
      "Their AI agents now handle 70% of inbound support. We've reduced response times from hours to seconds without compromising quality.",
    name: 'Marc Dubois',
    role: 'COO',
    company: 'NorthArc Retail',
    location: 'Paris, France',
    avatar: 'https://i.pravatar.cc/120?img=33',
  },
  {
    quote:
      'They feel like an extension of our team — not a vendor. We trust them with our most critical AI roadmap items.',
    name: 'Sara Lindquist',
    role: 'CTO',
    company: 'MediTrust Health',
    location: 'Stockholm, Sweden',
    avatar: 'https://i.pravatar.cc/120?img=5',
  },
  {
    quote:
      'From discovery to deployment, MGS combines true AI expertise with rock-solid engineering discipline.',
    name: 'Daniel Kim',
    role: 'VP Eng',
    company: 'BrightLogic',
    location: 'Seoul, South Korea',
    avatar: 'https://i.pravatar.cc/120?img=68',
  },
];

const DEFAULT_HEADING = 'Client Speaks';

// Build the subline shown beneath the author name on each card.
function subline(t) {
  const roleCompany = [t.role, t.company].filter(Boolean).join(t.role && t.company ? ' of ' : '');
  if (!roleCompany && !t.location) return '';
  if (!roleCompany) return t.location;
  if (!t.location) return roleCompany;
  return `${roleCompany} · ${t.location}`;
}

export default function Testimonials({ data, items }) {
  const heading = data?.heading || DEFAULT_HEADING;
  const testimonials =
    Array.isArray(items) && items.length ? items : DEFAULT_TESTIMONIALS;
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  const [openTestimonial, setOpenTestimonial] = useState(null);

  useEffect(() => {
    if (paused || openTestimonial) return;
    const t = setInterval(() => setI((v) => (v + 1) % testimonials.length), 5000);
    return () => clearInterval(t);
  }, [paused, openTestimonial, testimonials.length]);

  const visible = [
    testimonials[i % testimonials.length],
    testimonials[(i + 1) % testimonials.length],
    testimonials[(i + 2) % testimonials.length],
  ];

  return (
    <section
      className="py-20 relative overflow-hidden"
      style={{
        background:
          'linear-gradient(135deg, #2F6FB0 0%, #537EA8 45%, #C9962E 100%)',
      }}
    >
      <div className="container mx-auto">
        <h2 className="text-center text-3xl sm:text-4xl font-bold text-white">{heading}</h2>

        <div
          className="mt-10"
          onMouseEnter={() => setPaused(true)}
          onMouseLeave={() => setPaused(false)}
          data-testid={HOME.testimonialsCarousel}
        >
          <div className="grid lg:grid-cols-3 gap-5">
            <AnimatePresence mode="popLayout">
              {visible.map((t, idx) => (
                <motion.button
                  type="button"
                  key={t.name + idx + i}
                  initial={{ opacity: 0, y: 30, scale: 0.96 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -20, scale: 0.96 }}
                  transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1], delay: idx * 0.05 }}
                  onClick={() => setOpenTestimonial(t)}
                  aria-label={`Read full testimonial from ${t.name}`}
                  className="rounded-2xl bg-white border border-white/30 p-6 shadow-soft text-left cursor-pointer hover:-translate-y-0.5 transition-transform focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/70"
                  data-testid={`home-testimonial-card-${idx}`}
                >
                  <Quote className="h-6 w-6 text-[#C9962E]" />
                  <p className="mt-3 text-sm text-navy-deep leading-relaxed">"{t.quote}"</p>
                  <div className="mt-5 flex items-center gap-3">
                    <img
                      src={t.avatar}
                      alt={t.name}
                      className="h-11 w-11 rounded-full object-cover ring-2 ring-white"
                    />
                    <div>
                      <div className="text-sm font-semibold text-navy">{t.name}</div>
                      <div className="text-[11px] text-slatebody">{subline(t)}</div>
                    </div>
                  </div>
                </motion.button>
              ))}
            </AnimatePresence>
          </div>

          <div className="mt-8 flex items-center justify-center gap-3">
            <button
              onClick={() => setI((v) => (v - 1 + testimonials.length) % testimonials.length)}
              className="h-10 w-10 rounded-full bg-white/95 text-navy inline-flex items-center justify-center shadow-card hover:scale-105 transition"
              aria-label="Previous"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <div className="flex gap-1.5">
              {testimonials.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setI(idx)}
                  className={`h-1.5 rounded-full transition-all ${
                    idx === i % testimonials.length ? 'w-6 bg-white' : 'w-2 bg-white/40'
                  }`}
                  aria-label={`Go to ${idx + 1}`}
                />
              ))}
            </div>
            <button
              onClick={() => setI((v) => (v + 1) % testimonials.length)}
              className="h-10 w-10 rounded-full bg-white/95 text-navy inline-flex items-center justify-center shadow-card hover:scale-105 transition"
              aria-label="Next"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>

          <div className="mt-8 text-center">
            <a
              href="/reviews"
              className="inline-flex items-center gap-1 text-white/95 hover:text-white text-sm font-semibold underline-offset-4 hover:underline"
            >
              View More Feedbacks →
            </a>
          </div>
        </div>
      </div>

      <TestimonialModal testimonial={openTestimonial} onClose={() => setOpenTestimonial(null)} />
    </section>
  );
}
