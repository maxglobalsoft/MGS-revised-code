import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Sparkles, Bot, Database, Eye, Search } from 'lucide-react';
import { PrimaryButton, SecondaryButton } from '@/components/brand/Buttons';
import AICore from '@/components/brand/AICore';
import { fadeUp, staggerParent } from '@/lib/motion';
import { HOME } from '@/constants/testIds';

const floatingTags = [
  { label: 'Generative AI', icon: Sparkles, top: '8%', left: '-6%', delay: 0 },
  { label: 'AI Agents', icon: Bot, top: '24%', right: '-8%', delay: 0.4 },
  { label: 'RAG & Data', icon: Database, bottom: '24%', left: '-10%', delay: 0.8 },
  { label: 'Computer Vision', icon: Eye, bottom: '8%', right: '-4%', delay: 1.2 },
];

const DEFAULT_EYEBROW = 'AI-FIRST SOFTWARE · SINCE 2005';
const DEFAULT_SUBHEAD =
  "Since 2005, Max Global Software has delivered 800+ web portals and 400+ mobile and game apps worldwide. Today we're an AI-first technology partner — building AI-powered apps, chatbots, generative-AI integrations, ML and computer-vision systems, and intelligent enterprise platforms.";
const DEFAULT_CTA_PRIMARY = "Let's Connect";
const DEFAULT_CTA_SECONDARY = 'Explore AI Solutions';
const DEFAULT_TAGS = [
  '20+ years of experience',
  '800+ web portals',
  '400+ apps & games',
  'Founded by Bhupendra Verma',
];
const DEFAULT_PILL_CHIPS = ['AI Apps', 'AI / ML', 'Agents'];
const DEFAULT_MOCKUP_STATS = [
  { label: 'Total Sales', value: '$557,354', change: '+12.4%' },
  { label: 'Weekly Clicks', value: '$60,598', change: '+8.1%' },
];

export default function Hero({ data }) {
  const eyebrow = data?.eyebrow || DEFAULT_EYEBROW;
  const subhead = data?.subhead || DEFAULT_SUBHEAD;
  const ctaPrimary = data?.cta_primary || DEFAULT_CTA_PRIMARY;
  const ctaSecondary = data?.cta_secondary || DEFAULT_CTA_SECONDARY;
  const tags = Array.isArray(data?.tags) && data.tags.length ? data.tags : DEFAULT_TAGS;
  const pillChips =
    Array.isArray(data?.pill_chips) && data.pill_chips.length ? data.pill_chips : DEFAULT_PILL_CHIPS;
  const mockupStats =
    Array.isArray(data?.mockup_stats) && data.mockup_stats.length
      ? data.mockup_stats
      : DEFAULT_MOCKUP_STATS;
  // Allow CMS to override floating-tag labels but keep icons + positions intact.
  const liveFloatingLabels = Array.isArray(data?.floating_tags) ? data.floating_tags : null;
  const tagsResolved = floatingTags.map((t, idx) => ({
    ...t,
    label: liveFloatingLabels?.[idx] || t.label,
  }));
  return (
    <section id="top" className="relative pt-52 pb-28 overflow-hidden">
      {/* Background mesh */}
      <div className="absolute inset-0 bg-sky-200/60" />
      <div className="absolute inset-0 bg-hero-mesh bg-[length:200%_200%] animate-mesh-pan" />
      {/* Faint neural dots */}
      <svg
        className="absolute inset-0 w-full h-full opacity-[0.06] pointer-events-none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <pattern id="dots" x="0" y="0" width="22" height="22" patternUnits="userSpaceOnUse">
            <circle cx="2" cy="2" r="1.2" fill="#2F6FB0" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#dots)" />
      </svg>

      <div className="container mx-auto relative">
        <div className="grid lg:grid-cols-12 gap-10 items-center">
          {/* Left copy */}
          <motion.div
            variants={staggerParent(0.12, 0.1)}
            initial="hidden"
            animate="show"
            className="lg:col-span-6"
          >
            <motion.span
              variants={fadeUp}
              className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/70 border border-hairline backdrop-blur text-xs sm:text-sm font-semibold tracking-[0.18em] text-brandblue"
            >
              <Sparkles className="h-3 w-3 text-[#C9962E]" />
              {eyebrow}
            </motion.span>

            <motion.h1
              variants={fadeUp}
              className="mt-5 font-bold leading-[1.05] tracking-tight text-navy-deep text-4xl sm:text-5xl lg:text-6xl"
            >
              Powering Businesses With{' '}
              <span className="text-gradient-blue-gold">Tech Innovation</span> &amp;{' '}
              <span className="text-gold">Transformative Digital Solutions</span>
            </motion.h1>

            <motion.p
              variants={fadeUp}
              className="mt-6 max-w-xl text-slatebody text-base sm:text-[15px] leading-relaxed"
            >
              {subhead}
            </motion.p>

            <motion.div variants={fadeUp} className="mt-8 flex flex-wrap items-center gap-3">
              <PrimaryButton
                data-testid={HOME.heroCtaPrimary}
                icon={<ArrowRight className="h-4 w-4" />}
                onClick={() => document.getElementById('cta')?.scrollIntoView({ behavior: 'smooth' })}
              >
                {ctaPrimary}
              </PrimaryButton>
              <SecondaryButton
                data-testid={HOME.heroCtaSecondary}
                onClick={() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' })}
              >
                {ctaSecondary}
              </SecondaryButton>
            </motion.div>

            <motion.div variants={fadeUp} className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-2 text-[12px] text-navy/65">
              <div className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                {tags[0] || ''}
              </div>
              {tags.slice(1, 3).map((t, idx) => (
                <div key={`${t}-${idx}`}>{t}</div>
              ))}
              {tags[3] && <div className="hidden sm:block">{tags[3]}</div>}
            </motion.div>
          </motion.div>

          {/* Right mockup */}
          <div className="lg:col-span-6 relative">
            <motion.div
              initial={{ opacity: 0, y: 30, rotate: -1 }}
              animate={{ opacity: 1, y: 0, rotate: 0 }}
              transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1], delay: 0.2 }}
              className="relative"
            >
              <motion.div
                animate={{ y: [0, -12, 0] }}
                transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
                className="relative"
              >
                <HeroMockup mockupStats={mockupStats} pillChips={pillChips} />
              </motion.div>

              {/* Floating tags */}
              {tagsResolved.map((t) => {
                const Icon = t.icon;
                return (
                  <motion.div
                    key={t.label}
                    initial={{ opacity: 0, scale: 0.85 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.6 + t.delay * 0.2, duration: 0.5 }}
                    style={{ top: t.top, left: t.left, right: t.right, bottom: t.bottom }}
                    className="absolute z-20"
                  >
                    <motion.div
                      animate={{ y: [0, -6, 0], x: [0, 4, 0] }}
                      transition={{
                        duration: 5 + t.delay,
                        repeat: Infinity,
                        ease: 'easeInOut',
                        delay: t.delay,
                      }}
                      className="flex items-center gap-2 rounded-full bg-white/90 backdrop-blur px-3 py-2 shadow-card border border-hairline"
                    >
                      <span className="h-6 w-6 rounded-full bg-gold-gradient inline-flex items-center justify-center">
                        <Icon className="h-3.5 w-3.5 text-white" />
                      </span>
                      <span className="text-[12px] font-semibold text-navy">{t.label}</span>
                    </motion.div>
                  </motion.div>
                );
              })}
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* Rich Projects Monitoring dashboard mockup — matches the original Figma:
   header w/ tabs + search · 2 stat headers · multi-color bars · heat-map ·
   dark "Product Analytics" card with the AI Core · timeline area chart.
   + small phone mockup top-left + 3 pill chips below. */
function HeroMockup({ mockupStats = DEFAULT_MOCKUP_STATS, pillChips = DEFAULT_PILL_CHIPS }) {
  const stat0 = mockupStats[0] || DEFAULT_MOCKUP_STATS[0];
  const stat1 = mockupStats[1] || DEFAULT_MOCKUP_STATS[1];
  return (
    <div className="relative mx-auto max-w-[580px] pb-10">
      {/* Main dashboard card */}
      <div className="relative rounded-2xl bg-white shadow-soft border border-hairline overflow-hidden">
        {/* Top bar */}
        <div className="h-11 flex items-center justify-between px-4 border-b border-hairline bg-white">
          <div className="flex items-center gap-3">
            <div className="text-sm font-semibold text-navy">Projects Monitoring</div>
            <div className="hidden sm:flex gap-1">
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-sky-100 text-brandblue font-semibold">
                Active
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full text-slatebody">All</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Search className="h-3.5 w-3.5 text-mute" />
            <div className="h-5 w-5 rounded-full bg-gold-gradient" />
          </div>
        </div>

        <div className="p-4">
          {/* Stat headers */}
          <div className="grid grid-cols-2 gap-3 mb-3">
            <div className="rounded-lg bg-sky-50 border border-hairline px-3 py-2">
              <div className="text-[10px] text-mute">{stat0.label}</div>
              <div className="text-base font-bold text-navy">{stat0.value}</div>
              <div className="text-[10px] text-emerald-600 font-semibold">{stat0.change}</div>
            </div>
            <div className="rounded-lg bg-sky-50 border border-hairline px-3 py-2">
              <div className="text-[10px] text-mute">{stat1.label}</div>
              <div className="text-base font-bold text-navy">{stat1.value}</div>
              <div className="text-[10px] text-emerald-600 font-semibold">{stat1.change}</div>
            </div>
          </div>

          <div className="grid grid-cols-5 gap-3">
            {/* Left: bar chart + heatmap */}
            <div className="col-span-3 space-y-3">
              <div className="rounded-lg bg-white border border-hairline p-2.5">
                <div className="flex items-center justify-between mb-1.5">
                  <div className="text-[10px] text-mute">Performance</div>
                  <div className="text-[9px] text-slatebody">Last 10 wks</div>
                </div>
                <div className="flex items-end gap-1 h-14">
                  {[42, 65, 50, 80, 55, 75, 90, 60, 70, 85].map((h, i) => (
                    <motion.div
                      key={i}
                      initial={{ height: 0 }}
                      animate={{ height: `${h}%` }}
                      transition={{ duration: 0.7, delay: 0.6 + i * 0.05, ease: [0.22, 1, 0.36, 1] }}
                      className="flex-1 rounded-sm"
                      style={{
                        background:
                          i % 3 === 0 ? '#2BA8E0' : i % 3 === 1 ? '#2F6FB0' : '#E8C25A',
                      }}
                    />
                  ))}
                </div>
              </div>

              {/* Heatmap */}
              <div className="rounded-lg bg-white border border-hairline p-2.5">
                <div className="text-[10px] text-mute mb-1.5">Activity</div>
                <div className="grid grid-cols-14 gap-[2px]" style={{ gridTemplateColumns: 'repeat(14, minmax(0, 1fr))' }}>
                  {Array.from({ length: 42 }).map((_, i) => {
                    const intensity = 0.15 + (((i * 13) % 10) / 10) * 0.75;
                    return (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, scale: 0.6 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.3, delay: 0.9 + i * 0.012 }}
                        className="aspect-square rounded-[2px]"
                        style={{ background: `rgba(43,168,224,${intensity})` }}
                      />
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Right: dark Product Analytics with AI Core */}
            <div className="col-span-2 rounded-lg bg-navy-deep p-3 relative overflow-hidden">
              <div
                className="absolute inset-0 opacity-30"
                style={{
                  background:
                    'radial-gradient(circle at 50% 50%, rgba(43,168,224,0.5) 0%, transparent 70%)',
                }}
              />
              <div className="relative">
                <div className="text-[9px] uppercase tracking-wider text-white/55">Product</div>
                <div className="text-xs font-semibold text-white mb-1">AI Analytics</div>
                <div className="flex justify-center mt-1">
                  <AICore size={138} dark />
                </div>
                <div className="mt-1 text-center">
                  <div className="text-[9px] text-white/55">Neural Activity</div>
                  <div className="text-[11px] font-bold text-[#FFE08A]">98.4%</div>
                </div>
              </div>
            </div>
          </div>

          {/* Timeline */}
          <div className="mt-3 rounded-lg bg-white border border-hairline p-2.5">
            <div className="flex items-center justify-between mb-1">
              <div className="text-[10px] text-mute">Timeline</div>
              <div className="text-[9px] text-slatebody">30 days</div>
            </div>
            <svg viewBox="0 0 300 50" className="w-full h-10">
              <defs>
                <linearGradient id="tg" x1="0" x2="0" y1="0" y2="1">
                  <stop offset="0" stopColor="#2BA8E0" stopOpacity="0.5" />
                  <stop offset="1" stopColor="#2BA8E0" stopOpacity="0" />
                </linearGradient>
              </defs>
              <motion.path
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ duration: 1.6, delay: 1.2, ease: [0.22, 1, 0.36, 1] }}
                d="M0,40 C30,35 50,15 80,25 C110,35 130,5 160,18 C190,32 220,10 250,20 C275,28 290,15 300,18"
                fill="none"
                stroke="#2F6FB0"
                strokeWidth="1.6"
              />
              <path
                d="M0,40 C30,35 50,15 80,25 C110,35 130,5 160,18 C190,32 220,10 250,20 C275,28 290,15 300,18 L300,50 L0,50 Z"
                fill="url(#tg)"
              />
            </svg>
          </div>
        </div>
      </div>

      {/* Phone mockup (top-left, overlapping) */}
      <div className="absolute -left-10 -top-8 w-28 rounded-[20px] bg-navy-deep shadow-soft p-1.5 hidden sm:block z-10">
        <div className="rounded-[14px] bg-gradient-to-br from-[#2F6FB0] to-[#1F2D45] h-40 p-2 relative overflow-hidden">
          <div className="h-2 w-8 bg-white/30 rounded mb-2" />
          <div className="h-2 w-14 bg-white/40 rounded mb-3" />
          <div className="rounded-lg bg-white/10 backdrop-blur p-2">
            <div className="h-1.5 w-full bg-white/30 rounded mb-1" />
            <div className="h-1.5 w-2/3 bg-white/20 rounded" />
          </div>
          <div className="absolute bottom-2 right-2 h-6 w-6 rounded-full bg-gold-gradient" />
        </div>
      </div>

      {/* Pill chips beneath the card */}
      <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 flex gap-2 z-10">
        {pillChips.map((c, i) => (
          <motion.span
            key={`${c}-${i}`}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.4 + i * 0.12, duration: 0.5 }}
            className="text-[11px] font-semibold px-3 py-1.5 rounded-full bg-white border border-hairline shadow-card text-navy"
          >
            {c}
          </motion.span>
        ))}
      </div>
    </div>
  );
}
