import React from 'react';
import { motion } from 'framer-motion';
import {
  Sparkles,
  Bot,
  BrainCircuit,
  Eye,
  Workflow,
  Plug,
  ArrowRight,
  ChevronDown,
} from 'lucide-react';
import { PrimaryButton } from '@/components/brand/Buttons';
import SectionHeading from '@/components/brand/SectionHeading';
import SpotlightCard from '@/components/brand/SpotlightCard';
import { fadeUp, staggerParent, viewportOnce } from '@/lib/motion';
import { HOME } from '@/constants/testIds';
import { resolveIcon } from '@/lib/iconMap';

const DEFAULT_SERVICES = [
  {
    icon: Sparkles,
    title: 'AI-Powered Web & Mobile Apps',
    desc: 'Intelligent applications with AI built into the core experience — built for performance, scale, and outcomes.',
  },
  {
    icon: Bot,
    title: 'Generative AI & Chatbots',
    desc: 'Custom copilots, assistants, and content engines on GPT, Gemini, and Claude — tuned to your domain.',
  },
  {
    icon: BrainCircuit,
    title: 'Machine Learning & Predictive Analytics',
    desc: 'Recommendation systems, forecasting, and decision-intelligence models trained on your data.',
  },
  {
    icon: Eye,
    title: 'NLP & Computer Vision',
    desc: 'Language understanding, document AI, and image/video analysis for real-world business workflows.',
  },
  {
    icon: Workflow,
    title: 'Workflow Automation',
    desc: 'AI that streamlines real operations — intelligent enterprise platforms that remove repetitive work.',
  },
  {
    icon: Plug,
    title: 'AI Integration & Consulting',
    desc: 'We assess, strategize, and embed AI into your existing products and processes — no rip-and-replace.',
  },
];

const DEFAULT_TITLE = 'Explore Services';
const DEFAULT_SUBTITLE = 'AI-first capabilities, backed by 20+ years of full-stack engineering.';
const DEFAULT_FOOTER_NOTE =
  'Plus web development, mobile apps, ERP solutions, gaming & animation, UI/UX design, and IT-enabled services.';

export default function ExploreServices({ data, items }) {
  const title = data?.title || DEFAULT_TITLE;
  const subtitle = data?.subtitle || DEFAULT_SUBTITLE;
  const footerNote = data?.footer_note || DEFAULT_FOOTER_NOTE;
  const services =
    Array.isArray(items) && items.length
      ? items.map((s, idx) => ({
          ...s,
          icon: resolveIcon(s.icon, DEFAULT_SERVICES[idx % DEFAULT_SERVICES.length].icon),
        }))
      : DEFAULT_SERVICES;
  return (
    <section id="services" className="py-20 bg-white">
      <div className="container mx-auto">
        {/* Rounded panel wraps everything (centered title inside) */}
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={viewportOnce}
          className="rounded-[28px] bg-gradient-to-b from-sky-100 to-sky-200/60 border border-hairline shadow-soft p-8 lg:p-12 relative overflow-hidden"
        >
          <div className="absolute -top-24 -right-24 h-72 w-72 rounded-full bg-[#2BA8E0]/10 blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -left-24 h-72 w-72 rounded-full bg-[#E8C25A]/10 blur-3xl pointer-events-none" />

          <SectionHeading
            title={title}
            subtitle={subtitle}
            align="center"
            className="relative"
          />

          <motion.div
            data-testid={HOME.servicesGrid}
            variants={staggerParent(0.07)}
            initial="hidden"
            whileInView="show"
            viewport={viewportOnce}
            className="relative mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-5"
          >
            {services.map((s) => {
              const Icon = s.icon;
              return (
                <motion.div
                  key={s.title}
                  variants={fadeUp}
                  whileHover={{ y: -6 }}
                  transition={{ type: 'spring', stiffness: 280, damping: 22 }}
                  className="h-full"
                >
                  <SpotlightCard className="h-full">
                    <div className="relative p-6 h-full">
                      {/* Navy square icon */}
                      <div className="h-12 w-12 rounded-xl bg-navy-deep inline-flex items-center justify-center text-white shadow-card group-hover:bg-gold-gradient transition-colors duration-300">
                        <Icon className="h-5 w-5" />
                      </div>
                      <h3 className="mt-5 text-lg font-semibold text-navy">{s.title}</h3>
                      <p className="mt-2 text-sm text-slatebody leading-relaxed">{s.desc}</p>
                    </div>
                  </SpotlightCard>
                </motion.div>
              );
            })}
          </motion.div>
        </motion.div>

        <p className="text-center text-xs text-slatebody/80 mt-6 italic">
          {footerNote}
        </p>

        {/* Centered Explore More with chevron - sits BELOW the panel */}
        <div className="flex justify-center mt-6">
          <PrimaryButton icon={<ChevronDown className="h-4 w-4" />}>Explore More</PrimaryButton>
        </div>
      </div>
    </section>
  );
}
