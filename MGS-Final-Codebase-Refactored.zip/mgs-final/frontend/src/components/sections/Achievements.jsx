import React from 'react';
import { motion } from 'framer-motion';
import CountUp from '@/components/brand/CountUp';
import { fadeUp, staggerParent, viewportOnce } from '@/lib/motion';
import { HOME } from '@/constants/testIds';

// Real Max Global Software stats per Company Profile §5.
const DEFAULT_STATS = [
  { value: 20, suffix: '+', label: 'Years of Experience' },
  { value: 800, suffix: '+', label: 'Web Portals Delivered' },
  { value: 400, suffix: '+', label: 'Mobile Apps & Games' },
  { value: 35, suffix: '+', label: 'In-House Experts' },
  { value: 50, suffix: '+', label: 'AI Solutions Deployed' },
];

const DEFAULT_HEADING = 'Company\nAchievements';
const DEFAULT_SUBHEAD = 'Two decades of building software — now leading with AI.';

export default function Achievements({ data }) {
  const stats = Array.isArray(data?.stats) && data.stats.length ? data.stats : DEFAULT_STATS;
  const heading = data?.heading || DEFAULT_HEADING;
  const subhead = data?.subhead || DEFAULT_SUBHEAD;
  const headingLines = String(heading).split(/\n|\r\n/);
  return (
    <section className="py-20 bg-sky-50 relative overflow-hidden">
      <div className="absolute -top-24 -left-24 h-72 w-72 rounded-full bg-[#2BA8E0]/10 blur-3xl" />
      <div className="absolute -bottom-24 -right-24 h-72 w-72 rounded-full bg-[#E8C25A]/10 blur-3xl" />

      <div className="container mx-auto relative grid lg:grid-cols-12 gap-10 items-center">
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={viewportOnce}
          className="lg:col-span-4"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-navy-deep leading-tight">
            {headingLines.map((line, idx) => (
              <React.Fragment key={idx}>
                {line}
                {idx < headingLines.length - 1 && <br />}
              </React.Fragment>
            ))}
          </h2>
          <p className="mt-3 text-slatebody text-sm max-w-xs">
            {subhead}
          </p>
        </motion.div>

        {/* Clean numbers row with hairline dividers (matches Figma) */}
        <motion.div
          data-testid={HOME.achievementsRow}
          variants={staggerParent(0.1)}
          initial="hidden"
          whileInView="show"
          viewport={viewportOnce}
          className="lg:col-span-8 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-y-8 divide-x divide-hairline"
        >
          {stats.map((s, i) => (
            <motion.div
              key={s.label}
              variants={fadeUp}
              className={`px-4 text-center ${i === 0 ? 'border-l border-hairline' : ''}`}
            >
              <div className="text-4xl lg:text-5xl font-bold text-navy-deep leading-none">
                <CountUp to={s.value} suffix={s.suffix} />
              </div>
              <div className="mt-2 text-[11px] uppercase tracking-wider text-slatebody font-semibold">
                {s.label}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
