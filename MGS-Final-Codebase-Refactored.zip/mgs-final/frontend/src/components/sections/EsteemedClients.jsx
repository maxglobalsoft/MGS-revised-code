import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { PrimaryButton } from '@/components/brand/Buttons';
import { fadeUp, viewportOnce } from '@/lib/motion';
import { HOME } from '@/constants/testIds';

const DEFAULT_CLIENTS = [
  'EDISONDA',
  'onet',
  'drEryk',
  'YGGDRASIL',
  'supermenu',
  'treva.',
  'avon.',
  'WARHOL',
  'circle',
  'hexa',
  'NOVA',
  'pluto',
  'kairos',
  'orion',
];

const DEFAULT_HEADING = 'Esteemed Clients';

/**
 * Normalises CMS data into { name, logo? } objects.
 * Accepts:
 *   - 'Acme'                              (string)
 *   - { name: 'Acme' }                    (no logo → styled text)
 *   - { name: 'Acme', logo: '/x.svg' }    (image logo)
 */
function normalise(items) {
  return items
    .map((c) => {
      if (typeof c === 'string') return { name: c };
      if (c && typeof c === 'object') {
        const name = c.name || c.title || '';
        const logo = c.logo || c.image || c.src || null;
        if (!name && !logo) return null;
        return { name, logo };
      }
      return null;
    })
    .filter(Boolean);
}

function ClientLogoCard({ client }) {
  const { name, logo } = client;
  return (
    <div
      data-testid={`client-card-${(name || 'logo').toLowerCase().replace(/[^a-z0-9]+/g, '-')}`}
      className={[
        // Layout
        'client-logo-card group/card relative',
        'flex items-center justify-center',
        'px-6 sm:px-8 py-4 sm:py-5',
        'min-w-[160px] sm:min-w-[180px] min-h-[84px] sm:min-h-[96px]',
        // Surface
        'rounded-2xl bg-white border border-hairline shadow-card',
        // Motion (GPU-friendly: transform, box-shadow, border-color, filter only)
        'will-change-transform',
        'transition-[transform,box-shadow,border-color,filter] duration-300',
        // Brand easing
        '[transition-timing-function:cubic-bezier(0.22,1,0.36,1)]',
        // Hover state — lift + scale + gold ring + soft gold glow + warmer border
        'hover:-translate-y-2 hover:scale-[1.06]',
        'hover:ring-1 hover:ring-[#E8C25A]/40',
        'hover:shadow-[0_14px_34px_rgba(232,194,90,0.25)]',
        'hover:border-[#E8C25A]/45',
        // Stacking
        'hover:z-10',
      ].join(' ')}
    >
      {logo ? (
        <img
          src={logo}
          alt={name || 'Client logo'}
          loading="lazy"
          draggable="false"
          className={[
            'relative z-[1]',
            'max-h-10 sm:max-h-12 w-auto object-contain',
            'transition-[filter,opacity,transform] duration-300',
            '[transition-timing-function:cubic-bezier(0.22,1,0.36,1)]',
            'grayscale opacity-70',
            'group-hover/card:grayscale-0 group-hover/card:opacity-100',
            'group-hover/card:scale-[1.04]',
          ].join(' ')}
        />
      ) : (
        <span
          className={[
            'relative z-[1]',
            'select-none',
            'text-base sm:text-lg font-bold lowercase',
            'tracking-wide text-slatebody/65',
            'transition-[color,letter-spacing,text-shadow] duration-300',
            '[transition-timing-function:cubic-bezier(0.22,1,0.36,1)]',
            // On hover: brand color + a touch of tracking + faint gold text shadow
            'group-hover/card:text-navy-deep group-hover/card:tracking-[0.04em]',
            'group-hover/card:[text-shadow:0_0_18px_rgba(232,194,90,0.30)]',
          ].join(' ')}
        >
          {name}
        </span>
      )}
    </div>
  );
}

export default function EsteemedClients({ data, items }) {
  const heading = data?.heading || DEFAULT_HEADING;
  const clients =
    Array.isArray(items) && items.length
      ? normalise(items)
      : DEFAULT_CLIENTS.map((name) => ({ name }));

  // Duplicate for seamless marquee
  const row = [...clients, ...clients];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto">
        <motion.h2
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={viewportOnce}
          className="text-center text-3xl sm:text-4xl font-bold text-navy-deep"
        >
          {heading}
        </motion.h2>
      </div>

      <div
        data-testid={HOME.clientsMarquee}
        className="mt-10 marquee-mask overflow-visible group"
      >
        {/* Inner wrapper keeps overflow:hidden ONLY for the horizontal scroll,
            while allowing each card's hover lift/glow to escape vertically. */}
        <div className="overflow-x-hidden overflow-y-visible py-4">
          <div className="flex w-max gap-8 sm:gap-10 px-6 animate-marquee-slow group-hover:[animation-play-state:paused]">
            {row.map((c, i) => (
              <ClientLogoCard key={`${c.name || c.logo}-${i}`} client={c} />
            ))}
          </div>
        </div>
      </div>

      <div className="mt-10 flex justify-center">
        <PrimaryButton icon={<ArrowRight className="h-4 w-4" />}>Explore More</PrimaryButton>
      </div>
    </section>
  );
}
