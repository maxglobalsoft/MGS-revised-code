import React from 'react';
import { motion } from 'framer-motion';
import {
  Stethoscope,
  Hotel,
  Factory,
  Store,
  Banknote,
  Building2,
  GraduationCap,
  ArrowRight,
} from 'lucide-react';
import { PrimaryButton } from '@/components/brand/Buttons';
import SpotlightCard from '@/components/brand/SpotlightCard';
import { fadeUp, staggerParent, viewportOnce } from '@/lib/motion';
import { HOME } from '@/constants/testIds';
import { resolveIcon } from '@/lib/iconMap';

const DEFAULT_INDUSTRIES = [
  { icon: Stethoscope, title: 'Healthcare', desc: 'AI diagnostics support, clinical documentation, and patient-care automation.' },
  { icon: Hotel, title: 'Hospitality', desc: 'AI booking concierges, dynamic pricing, and guest-experience personalization.' },
  { icon: Factory, title: 'Manufacturing', desc: 'Predictive maintenance, computer-vision quality control, and supply-chain optimization.' },
  { icon: Store, title: 'Retail & E-commerce', desc: 'Recommendation engines, demand forecasting, and AI shopping assistants.' },
  { icon: Banknote, title: 'Fintech', desc: 'Fraud detection, risk scoring, document automation, and compliance copilots.' },
  { icon: Building2, title: 'Real Estate', desc: 'AI property matching, virtual tours, and lead-qualification agents.' },
  { icon: GraduationCap, title: 'Education', desc: 'Adaptive learning, AI tutoring, and automated assessment.' },
];

const DEFAULT_HEADING = 'Industries';
const DEFAULT_SUBHEAD = 'AI use-cases mapped to the realities of your sector.';

export default function Industries({ data, items }) {
  const heading = data?.heading || DEFAULT_HEADING;
  const subhead = data?.subhead || DEFAULT_SUBHEAD;
  const industries =
    Array.isArray(items) && items.length
      ? items.map((it, idx) => ({
          ...it,
          icon: resolveIcon(it.icon, DEFAULT_INDUSTRIES[idx % DEFAULT_INDUSTRIES.length].icon),
        }))
      : DEFAULT_INDUSTRIES;
  return (
    <section id="industries" className="py-20 bg-white">
      <div className="container mx-auto">
        <div className="grid lg:grid-cols-12 gap-10 items-start">
          {/* Left: heading + Explore More button (per Figma) */}
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={viewportOnce}
            className="lg:col-span-3"
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-navy-deep leading-tight">
              {heading}
            </h2>
            <p className="mt-3 text-slatebody text-sm">
              {subhead}
            </p>
            <div className="mt-5">
              <PrimaryButton icon={<ArrowRight className="h-4 w-4" />}>Explore More</PrimaryButton>
            </div>
          </motion.div>

          {/* Right: 7 cards in a grid */}
          <motion.div
            data-testid={HOME.industriesGrid}
            variants={staggerParent(0.06)}
            initial="hidden"
            whileInView="show"
            viewport={viewportOnce}
            className="lg:col-span-9 grid sm:grid-cols-2 lg:grid-cols-3 gap-5"
          >
            {industries.map((it) => {
              const Icon = it.icon;
              return (
                <motion.div
                  key={it.title}
                  variants={fadeUp}
                  whileHover={{ y: -5 }}
                  transition={{ type: 'spring', stiffness: 280, damping: 22 }}
                  className="h-full"
                >
                  <SpotlightCard className="h-full">
                    <div className="p-6 text-center h-full">
                      <div className="mx-auto h-14 w-14 rounded-full border-2 border-brandblue/30 bg-white inline-flex items-center justify-center text-brandblue group-hover:border-[#C9962E] group-hover:text-[#C9962E] transition-colors">
                        <Icon className="h-6 w-6" />
                      </div>
                      <h3 className="mt-4 text-lg font-semibold text-navy">{it.title}</h3>
                      <p className="mt-2 text-sm text-slatebody leading-relaxed">{it.desc}</p>
                    </div>
                  </SpotlightCard>
                </motion.div>
              );
            })}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
