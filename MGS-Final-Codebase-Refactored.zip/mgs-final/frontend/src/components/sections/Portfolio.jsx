import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  BrainCircuit,
  Monitor,
  Smartphone,
  BarChart3,
  ShoppingBag,
} from 'lucide-react';
import TiltCard from '@/components/brand/TiltCard';
import { PrimaryButton } from '@/components/brand/Buttons';
import { fadeUp, viewportOnce } from '@/lib/motion';
import { HOME } from '@/constants/testIds';

// AI & Machine Learning set as default/first tab per the spec.
const DEFAULT_CATEGORIES = [
  { id: 'ai', label: 'AI & Machine Learning', Icon: BrainCircuit },
  { id: 'web', label: 'Web Development', Icon: Monitor },
  { id: 'mobile', label: 'Mobile Development', Icon: Smartphone },
  { id: 'biz', label: 'Business Analytics', Icon: BarChart3 },
  { id: 'ecom', label: 'E-commerce & UI/UX Design', Icon: ShoppingBag },
];

const CATEGORY_ICON_MAP = {
  BrainCircuit,
  Monitor,
  Smartphone,
  BarChart3,
  ShoppingBag,
};

const DEFAULT_HEADING = 'Our Portfolio';
const DEFAULT_SUBHEAD = "A glimpse of the products we've shipped worldwide.";

// [Replace with real MGS project screenshots]
const DEFAULT_PROJECTS = {
  ai: [
    { title: 'Clinical Copilot', tag: 'Healthcare LLM', img: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=900&q=70' },
    { title: 'Retail Recommender', tag: 'Recommendation', img: 'https://images.unsplash.com/photo-1556742393-d75f468bfcb0?w=900&q=70' },
    { title: 'Vision QC Engine', tag: 'Computer Vision', img: 'https://images.unsplash.com/photo-1565728744382-61accd4aa148?w=900&q=70' },
    { title: 'Compliance Copilot', tag: 'Fintech NLP', img: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=900&q=70' },
    { title: 'Document AI', tag: 'NLP · RAG', img: 'https://images.unsplash.com/photo-1453928582365-b6ad33cbcf64?w=900&q=70' },
    { title: 'Predictive Maintenance', tag: 'ML Forecasting', img: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=900&q=70' },
  ],
  web: [
    { title: 'B2B Marketplace', tag: 'Next.js · Stripe', img: 'https://images.unsplash.com/photo-1559028012-481c04fa702d?w=900&q=70' },
    { title: 'Realtor Hub', tag: 'React · Node', img: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=900&q=70' },
    { title: 'EdTech Portal', tag: 'TypeScript', img: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=900&q=70' },
    { title: 'SaaS Dashboard', tag: 'Tailwind · API', img: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=900&q=70' },
    { title: 'Hospitality Portal', tag: 'Booking System', img: 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=900&q=70' },
    { title: 'Investor Hub', tag: 'Finance', img: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=900&q=70' },
  ],
  mobile: [
    { title: 'HealthOne', tag: 'Flutter', img: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?w=900&q=70' },
    { title: 'BankPay', tag: 'React Native', img: 'https://images.unsplash.com/photo-1611174743420-3d7df880ce32?w=900&q=70' },
    { title: 'TravelGo', tag: 'Swift', img: 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=900&q=70' },
    { title: 'FitTrack', tag: 'Kotlin', img: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=900&q=70' },
    { title: 'ChefMate', tag: 'React Native', img: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=900&q=70' },
    { title: 'PetPal', tag: 'Flutter', img: 'https://images.unsplash.com/photo-1450778869180-41d0601e046e?w=900&q=70' },
  ],
  biz: [
    { title: 'Demand Forecast', tag: 'BI · ML', img: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=900&q=70' },
    { title: 'Supply Insights', tag: 'PowerBI', img: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=900&q=70' },
    { title: 'Sales Lens', tag: 'Looker', img: 'https://images.unsplash.com/photo-1543286386-713bdd548da4?w=900&q=70' },
    { title: 'Ops Pulse', tag: 'Tableau', img: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=900&q=70' },
    { title: 'Marketing Mix', tag: 'Analytics', img: 'https://images.unsplash.com/photo-1551434678-e076c223a692?w=900&q=70' },
    { title: 'Revenue OS', tag: 'Decision Eng.', img: 'https://images.unsplash.com/photo-1554224154-26032ffc0d07?w=900&q=70' },
  ],
  ecom: [
    { title: 'Style House', tag: 'Shopify', img: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=900&q=70' },
    { title: 'Auctora', tag: 'Magento', img: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=900&q=70' },
    { title: 'Real Plot', tag: 'WooCommerce', img: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=900&q=70' },
    { title: 'Heyway', tag: 'Headless CMS', img: 'https://images.unsplash.com/photo-1556742111-a301076d9d18?w=900&q=70' },
    { title: 'Acme Storefront', tag: 'Next Commerce', img: 'https://images.unsplash.com/photo-1481437156560-3205f6a55735?w=900&q=70' },
    { title: 'Lumen UX', tag: 'UI/UX', img: 'https://images.unsplash.com/photo-1559028012-481c04fa702d?w=900&q=70' },
  ],
};

export default function Portfolio({ data, items, categories: liveCategories }) {
  const heading = data?.heading || DEFAULT_HEADING;
  const subhead = data?.subhead || DEFAULT_SUBHEAD;

  const categories =
    Array.isArray(liveCategories) && liveCategories.length
      ? liveCategories.map((c) => ({
          id: c.category_id || c.id,
          label: c.label,
          Icon: CATEGORY_ICON_MAP[c.icon] || BrainCircuit,
        }))
      : DEFAULT_CATEGORIES;

  // Group live items by category; fall back to defaults per-category if empty.
  const projects = (() => {
    if (Array.isArray(items) && items.length) {
      const grouped = {};
      items.forEach((p) => {
        const key = p.category || 'ai';
        if (!grouped[key]) grouped[key] = [];
        grouped[key].push({ title: p.title, tag: p.tag, img: p.img });
      });
      // Ensure every visible category has at least an empty array so the active tab never breaks.
      categories.forEach((c) => {
        if (!grouped[c.id]) grouped[c.id] = DEFAULT_PROJECTS[c.id] || [];
      });
      return grouped;
    }
    return DEFAULT_PROJECTS;
  })();

  const firstId = categories[0]?.id || 'ai';
  const [active, setActive] = useState(firstId);

  return (
    <section id="portfolio" className="py-20 bg-white">
      <div className="container mx-auto">
        <div className="flex items-end justify-between flex-wrap gap-4 mb-6">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={viewportOnce}
          >
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-navy-deep">{heading}</h2>
            <p className="mt-2 text-slatebody">
              {subhead}
            </p>
          </motion.div>
          <PrimaryButton icon={<ArrowRight className="h-4 w-4" />}>Explore More</PrimaryButton>
        </div>

        {/* Underline tab bar with sliding gold indicator (layoutId) */}
        <div
          data-testid={HOME.portfolioTabs}
          className="relative border-b border-hairline mt-4 mb-8 overflow-x-auto"
        >
          <div className="flex items-center gap-1 sm:gap-2 min-w-max">
            {categories.map((c) => {
              const Icon = c.Icon;
              const isActive = active === c.id;
              return (
                <button
                  key={c.id}
                  onClick={() => setActive(c.id)}
                  className={`relative px-4 sm:px-5 py-3 inline-flex items-center gap-2 text-sm font-semibold transition-colors ${
                    isActive ? 'text-navy-deep' : 'text-slatebody hover:text-navy'
                  }`}
                >
                  <Icon
                    className={`h-4 w-4 ${
                      isActive ? 'text-[#C9962E]' : 'text-current'
                    }`}
                  />
                  {c.label}
                  {isActive && (
                    <motion.span
                      layoutId="portfolio-underline"
                      className="absolute left-2 right-2 -bottom-px h-[3px] rounded-full bg-gold-gradient"
                      transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                    />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Project grid (filters by active tab) */}
        <AnimatePresence mode="wait">
          <motion.div
            key={active}
            initial={{ opacity: 0, filter: 'blur(8px)', y: 12 }}
            animate={{ opacity: 1, filter: 'blur(0px)', y: 0 }}
            exit={{ opacity: 0, filter: 'blur(8px)', y: -8 }}
            transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
            className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5"
          >
            {projects[active]?.map((p) => (
              <Link
                key={p.title}
                to="/portfolio"
                aria-label={`Open portfolio — ${p.title}`}
                className="block focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60 rounded-2xl"
              >
                <TiltCard
                  className="group rounded-2xl overflow-hidden bg-white border border-hairline shadow-card hover:shadow-soft transition-shadow cursor-pointer"
                >
                  <div className="relative h-52 overflow-hidden">
                    <img
                      src={p.img}
                      alt={p.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-navy-deep/55 via-transparent to-transparent" />
                    <span className="absolute top-3 left-3 text-[10px] font-semibold tracking-wide bg-white/90 backdrop-blur text-navy px-2 py-1 rounded-full">
                      {p.tag}
                    </span>
                  </div>
                  <div className="p-5">
                    <h4 className="text-sm font-semibold text-navy">{p.title}</h4>
                    <span className="mt-1 inline-flex items-center gap-1 text-[12px] text-brandblue group-hover:text-[#C9962E] transition-colors">
                      Read more <ArrowRight className="h-3 w-3 transition-transform duration-300 group-hover:translate-x-1" />
                    </span>
                  </div>
                </TiltCard>
              </Link>
            ))}
          </motion.div>
        </AnimatePresence>

        {/* View-all CTA → dedicated Portfolio page */}
        <div className="mt-12 flex justify-center">
          <Link
            to="/portfolio"
            data-testid="home-portfolio-view-all"
            className="group inline-flex items-center gap-2 text-[11px] tracking-[0.22em] uppercase font-bold text-brandblue hover:text-navy-deep transition-colors px-7 py-3 rounded-full border border-brandblue/30 hover:border-brandblue bg-white shadow-card"
          >
            View all work
            <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1.5" />
          </Link>
        </div>
      </div>
    </section>
  );
}
