import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Linkedin, Youtube, Mail, MapPin, Phone, Globe } from 'lucide-react';
import { HOME } from '@/constants/testIds';
import { useSite } from '@/context/SiteContext';

// Transparent-background MGS logo (white removed)
const DEFAULT_LOGO_URL = '/mgs-logo.png';

const DEFAULT_COLS = [
  {
    title: 'Our Services',
    items: [
      { label: 'AI-Powered Web & Mobile Apps', to: '/services' },
      { label: 'Generative AI & Chatbots', to: '/services' },
      { label: 'Machine Learning & Predictive Analytics', to: '/services' },
      { label: 'NLP & Computer Vision', to: '/services' },
      { label: 'Workflow Automation', to: '/services' },
      { label: 'AI Integration & Consulting', to: '/services' },
      { label: 'Web & Mobile Development', to: '/services' },
      { label: 'ERP Solutions', to: '/services' },
      { label: 'UI/UX Design', to: '/services' },
    ],
  },
  {
    title: "Let's Explore",
    items: [
      { label: 'About / Why MGS', to: '/why-mgs' },
      { label: 'Our Team', to: '/our-team' },
      { label: 'Case Study', to: '/case-studies' },
      { label: 'Career', to: '/career' },
      { label: 'Reviews', to: '/reviews' },
    ],
  },
  {
    title: 'T&C',
    items: [
      { label: 'Content Guidelines', to: '#' },
      { label: 'Legal Disclosure', to: '#' },
      { label: 'Privacy Policy', to: '#' },
      { label: 'Security', to: '#' },
      { label: 'Terms & Services', to: '#' },
    ],
  },
];

const DEFAULT_CONTACT = {
  address: [
    'Samartha Apartment, #202, Door No. 2405,',
    '18th Main Road, Kumaraswamy Layout 2nd Stage,',
    'Bengaluru – 560078, Karnataka, India',
  ],
  phone: ['+91-7795287075', '+91-80-49746380', '+91-80-40935246'],
  email: ['ceo@maxglobalsoft.com', 'info@maxglobalsoft.com'],
  website: 'https://www.maxglobalsoft.com',
};

const DEFAULT_COPYRIGHT =
  '© 2026 Max Global Software. All rights reserved. — Quality Beyond Desires';

const SOCIAL_ICONS = {
  facebook: Facebook,
  twitter: Twitter,
  linkedin: Linkedin,
  youtube: Youtube,
};

export default function Footer() {
  const { data: site } = useSite();

  const LOGO_URL = site?.logo_url || DEFAULT_LOGO_URL;
  const cols =
    Array.isArray(site?.footer_columns) && site.footer_columns.length
      ? site.footer_columns
      : DEFAULT_COLS;
  const contact = { ...DEFAULT_CONTACT, ...(site?.contact || {}) };
  const addressLines = Array.isArray(contact.address)
    ? contact.address
    : typeof contact.address === 'string'
    ? [contact.address]
    : DEFAULT_CONTACT.address;
  const phones = Array.isArray(contact.phone)
    ? contact.phone
    : contact.phone
    ? [contact.phone]
    : DEFAULT_CONTACT.phone;
  const emails = Array.isArray(contact.email)
    ? contact.email
    : contact.email
    ? [contact.email]
    : DEFAULT_CONTACT.email;
  const websiteUrl = contact.website || DEFAULT_CONTACT.website;
  const socials =
    Array.isArray(site?.socials) && site.socials.length
      ? site.socials
      : [
          { platform: 'facebook', url: '#' },
          { platform: 'twitter', url: '#' },
          { platform: 'linkedin', url: '#' },
          { platform: 'youtube', url: '#' },
        ];
  const copyright = site?.copyright || DEFAULT_COPYRIGHT;

  return (
    <footer
      id="footer"
      data-testid={HOME.footer}
      className="relative bg-white text-slatebody pt-16 pb-8 border-t border-hairline"
    >
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#E8C25A]/40 to-transparent" />

      <div className="container mx-auto grid grid-cols-1 md:grid-cols-12 gap-10">
        {/* Brand col */}
        <div className="md:col-span-3">
          <img
            src={LOGO_URL}
            alt="Max Global Software"
            className="h-40 w-auto object-contain -mb-6"
          />

          {/* ISO Certifications — directly under the logo */}
          <div className="mb-5 max-w-[260px]">
            <div className="grid grid-cols-2 gap-2.5">
              <a
                href="#"
                aria-label="ISO 9001:2015 Certified"
                className="group block rounded-md bg-white border border-hairline p-1.5 hover:shadow-card hover:border-[#C9962E]/40 transition-all"
                title="ISO 9001:2015 Quality Management Certified"
              >
                <img
                  src="/iso-9001.png"
                  alt="ISO 9001:2015 Certified"
                  className="w-full h-auto object-contain transition-transform duration-500 group-hover:scale-[1.05]"
                  loading="lazy"
                />
              </a>
              <a
                href="#"
                aria-label="ISO 20000-1:2018 Certified"
                className="group block rounded-md bg-white border border-hairline p-1.5 hover:shadow-card hover:border-[#C9962E]/40 transition-all"
                title="ISO 20000-1:2018 IT Service Management Certified"
              >
                <img
                  src="/iso-20000.jpeg"
                  alt="ISO 20000-1:2018 Certified"
                  className="w-full h-auto object-contain transition-transform duration-500 group-hover:scale-[1.05]"
                  loading="lazy"
                />
              </a>
            </div>
          </div>

          <p className="text-sm text-slatebody leading-relaxed">
            AI-first software since 2005 — turning ideas into intelligent, scalable, future-ready
            digital solutions.
          </p>
          <div className="mt-5 flex items-center gap-3">
            {socials.map((s, i) => {
              const Icon = SOCIAL_ICONS[s.platform?.toLowerCase()] || Globe;
              return (
                <a
                  key={`${s.platform}-${i}`}
                  href={s.url || '#'}
                  aria-label={s.platform || 'social'}
                  target={s.url && s.url !== '#' ? '_blank' : undefined}
                  rel={s.url && s.url !== '#' ? 'noopener noreferrer' : undefined}
                  className="h-9 w-9 inline-flex items-center justify-center rounded-full border border-hairline text-navy hover:bg-gold-gradient hover:text-white hover:border-transparent transition-all"
                >
                  <Icon className="h-4 w-4" />
                </a>
              );
            })}
          </div>
        </div>

        {/* Columns */}
        {cols.map((col) => (
          <div key={col.title} className="md:col-span-2">
            <h4 className="text-navy-deep font-semibold mb-4">{col.title}</h4>
            <ul className="space-y-2">
              {col.items.map((it) => {
                const isInternal = it.to && it.to.startsWith('/');
                const content = (
                  <span className="text-sm text-slatebody hover:text-[#C9962E] transition-colors">
                    {it.label}
                  </span>
                );
                return (
                  <li key={it.label}>
                    {isInternal ? (
                      <Link to={it.to}>{content}</Link>
                    ) : (
                      <a href={it.to || '#'}>{content}</a>
                    )}
                  </li>
                );
              })}
            </ul>
          </div>
        ))}

        {/* Find Us */}
        <div className="md:col-span-3">
          <h4 className="text-navy-deep font-semibold mb-4">Find Us</h4>
          <ul className="space-y-3 text-sm">
            <li className="flex gap-2 items-start text-slatebody">
              <MapPin className="h-4 w-4 mt-1 text-brandblue shrink-0" />
              <span>
                {addressLines.map((line, idx) => (
                  <React.Fragment key={idx}>
                    {line}
                    {idx < addressLines.length - 1 && <br />}
                  </React.Fragment>
                ))}
              </span>
            </li>
            <li className="flex gap-2 items-center text-slatebody">
              <Phone className="h-4 w-4 text-brandblue shrink-0" />
              <span>
                {phones.map((p, idx) => (
                  <React.Fragment key={p}>
                    {p}
                    {idx < phones.length - 1 && (idx % 2 === 0 ? ' \u00a0|\u00a0 ' : <br />)}
                  </React.Fragment>
                ))}
              </span>
            </li>
            <li className="flex gap-2 items-center text-slatebody">
              <Mail className="h-4 w-4 text-brandblue shrink-0" />
              <span>
                {emails.map((e, idx) => (
                  <React.Fragment key={e}>
                    <a href={`mailto:${e}`} className="hover:text-[#C9962E] transition-colors">
                      {e}
                    </a>
                    {idx < emails.length - 1 && <br />}
                  </React.Fragment>
                ))}
              </span>
            </li>
            <li className="flex gap-2 items-center text-slatebody">
              <Globe className="h-4 w-4 text-brandblue shrink-0" />
              <a
                href={websiteUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-[#C9962E] transition-colors"
              >
                {websiteUrl.replace(/^https?:\/\//, '')}
              </a>
            </li>
          </ul>
        </div>
      </div>

      <div className="container mx-auto mt-12 pt-6 border-t border-hairline flex flex-col md:flex-row items-center justify-between gap-3">
        <p className="text-xs text-slatebody">{copyright}</p>
        <p className="text-xs text-slatebody">Founded 2005 · Led by Bhupendra Verma</p>
      </div>
    </footer>
  );
}
