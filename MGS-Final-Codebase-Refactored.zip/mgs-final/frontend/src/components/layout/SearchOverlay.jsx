import React, { useEffect, useMemo, useRef, useState } from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Search, X, ArrowRight, Loader2, CornerDownLeft } from 'lucide-react';

import api from '@/lib/api';

const EASE = [0.22, 1, 0.36, 1];

/* Group order + accent colors per type */
const TYPE_ORDER = ['Page', 'Service', 'Industry', 'Case Study', 'Project', 'Team'];

export default function SearchOverlay({ open, onClose }) {
  const reducedMotion = useReducedMotion();
  const navigate = useNavigate();
  const inputRef = useRef(null);
  const overlayRef = useRef(null);

  const [q, setQ] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [active, setActive] = useState(0);

  // Focus + body scroll lock + global Escape close
  useEffect(() => {
    if (!open) return undefined;
    const prev = document.activeElement;
    document.body.style.overflow = 'hidden';
    setTimeout(() => inputRef.current?.focus(), 60);
    const onEsc = (e) => { if (e.key === 'Escape') onClose?.(); };
    document.addEventListener('keydown', onEsc);
    return () => {
      document.body.style.overflow = '';
      document.removeEventListener('keydown', onEsc);
      try { prev?.focus?.(); } catch (_) { /* noop */ }
    };
  }, [open, onClose]);

  // Debounced search
  useEffect(() => {
    if (!open) return undefined;
    const term = q.trim();
    setActive(0);
    if (term.length < 2) {
      setResults([]);
      setLoading(false);
      return undefined;
    }
    setLoading(true);
    const timer = setTimeout(() => {
      api.get(`/search?q=${encodeURIComponent(term)}`)
        .then((res) => setResults(Array.isArray(res.data?.results) ? res.data.results : []))
        .catch(() => setResults([]))
        .finally(() => setLoading(false));
    }, 250);
    return () => clearTimeout(timer);
  }, [q, open]);

  // Reset on close
  useEffect(() => {
    if (!open) {
      setQ('');
      setResults([]);
      setActive(0);
    }
  }, [open]);

  // Flat list for keyboard nav
  const flatResults = useMemo(() => results, [results]);

  const grouped = useMemo(() => {
    const map = {};
    flatResults.forEach((r) => {
      const k = r.type || 'Page';
      if (!map[k]) map[k] = [];
      map[k].push(r);
    });
    return TYPE_ORDER
      .filter((t) => map[t]?.length)
      .map((t) => ({ type: t, items: map[t] }));
  }, [flatResults]);

  const go = (r) => {
    if (!r) return;
    navigate(r.url || '/');
    onClose?.();
  };

  const onKeyDown = (e) => {
    if (e.key === 'Escape') { onClose?.(); return; }
    if (!flatResults.length) return;
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActive((i) => Math.min(flatResults.length - 1, i + 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActive((i) => Math.max(0, i - 1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      go(flatResults[active]);
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          ref={overlayRef}
          role="dialog"
          aria-modal="true"
          aria-label="Site search"
          data-testid="search-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25, ease: EASE }}
          onClick={(e) => { if (e.target === overlayRef.current) onClose?.(); }}
          className="fixed inset-0 z-[90] bg-navy-deep/55 backdrop-blur-sm flex items-start justify-center p-4 pt-[12vh] sm:pt-[18vh]"
        >
          <motion.div
            initial={reducedMotion ? { opacity: 0 } : { opacity: 0, y: -20, scale: 0.96 }}
            animate={reducedMotion ? { opacity: 1 } : { opacity: 1, y: 0, scale: 1 }}
            exit={reducedMotion ? { opacity: 0 } : { opacity: 0, y: -10, scale: 0.97 }}
            transition={{ duration: 0.35, ease: EASE }}
            className="w-full max-w-2xl rounded-2xl overflow-hidden bg-white shadow-[0_30px_80px_rgba(15,25,45,0.4)] ring-1 ring-white/20"
            onKeyDown={onKeyDown}
          >
            {/* Input row */}
            <div className="relative flex items-center gap-3 px-5 py-4 border-b border-hairline">
              <Search className="h-5 w-5 text-brandblue shrink-0" strokeWidth={2.4} />
              <input
                ref={inputRef}
                type="text"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search services, case studies, team…"
                data-testid="search-input"
                className="flex-1 bg-transparent outline-none text-navy-deep text-[15px] placeholder:text-slatebody/60"
              />
              {loading && <Loader2 className="h-4 w-4 animate-spin text-brandblue" />}
              <button
                type="button"
                aria-label="Close search"
                onClick={onClose}
                data-testid="search-close"
                className="h-8 w-8 rounded-full bg-sky-50 hover:bg-sky-100 text-navy/70 hover:text-navy-deep inline-flex items-center justify-center transition-colors"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Animated gold underline */}
            <motion.div
              aria-hidden="true"
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              exit={{ scaleX: 0 }}
              transition={{ duration: 0.6, ease: EASE, delay: 0.1 }}
              style={{ transformOrigin: 'left' }}
              className="h-[2px] bg-gradient-to-r from-[#2BA8E0] via-[#2F6FB0] to-[#E8C25A]"
            />

            {/* Results / empty / hint */}
            <div className="max-h-[55vh] overflow-y-auto" data-testid="search-results">
              {q.trim().length < 2 ? (
                <SearchHint />
              ) : !loading && flatResults.length === 0 ? (
                <p className="px-5 py-10 text-center text-sm text-slatebody">
                  No matches for <span className="font-semibold text-navy-deep">"{q}"</span>.
                </p>
              ) : (
                <motion.ul
                  initial="hidden"
                  animate="show"
                  variants={{
                    hidden: {},
                    show: { transition: { staggerChildren: 0.035 } },
                  }}
                  className="py-3"
                >
                  {grouped.map((group) => (
                    <li key={group.type} className="px-2">
                      <p className="px-3 mt-3 mb-1 text-[10px] font-bold tracking-[0.22em] uppercase text-brandblue">
                        {group.type}
                      </p>
                      <ul>
                        {group.items.map((r) => {
                          const flatIdx = flatResults.indexOf(r);
                          const isActive = flatIdx === active;
                          return (
                            <motion.li
                              key={`${r.type}-${r.url}-${r.title}`}
                              variants={{
                                hidden: { opacity: 0, y: -4 },
                                show: { opacity: 1, y: 0, transition: { duration: 0.28, ease: EASE } },
                              }}
                            >
                              <button
                                type="button"
                                onClick={() => go(r)}
                                onMouseEnter={() => setActive(flatIdx)}
                                data-testid={`search-result-${flatIdx}`}
                                className={[
                                  'group w-full text-left flex items-center gap-3 px-3 py-3 rounded-xl transition-colors',
                                  isActive ? 'bg-sky-50' : 'hover:bg-sky-50/70',
                                ].join(' ')}
                              >
                                <div className="flex-1 min-w-0">
                                  <p className="text-[13.5px] font-semibold tracking-tight text-navy-deep leading-snug truncate">
                                    {r.title}
                                  </p>
                                  {r.snippet && (
                                    <p className="mt-0.5 text-[12px] text-slatebody/85 truncate">
                                      {r.snippet}
                                    </p>
                                  )}
                                </div>
                                <ArrowRight
                                  className={[
                                    'h-4 w-4 shrink-0 transition-all duration-300',
                                    isActive
                                      ? 'text-[#C9962E] translate-x-0 opacity-100'
                                      : 'text-navy/30 -translate-x-1 opacity-0 group-hover:translate-x-0 group-hover:opacity-100',
                                  ].join(' ')}
                                  strokeWidth={2.5}
                                />
                              </button>
                            </motion.li>
                          );
                        })}
                      </ul>
                    </li>
                  ))}
                </motion.ul>
              )}
            </div>

            {/* Footer hint */}
            <div className="flex items-center justify-between gap-4 px-5 py-2.5 bg-sky-50/60 border-t border-hairline text-[11px] text-slatebody/85">
              <span className="inline-flex items-center gap-1.5">
                <kbd className="px-1.5 py-0.5 rounded bg-white border border-hairline font-mono text-[10px]">↑↓</kbd>
                Navigate
                <kbd className="ml-2 px-1.5 py-0.5 rounded bg-white border border-hairline font-mono text-[10px] inline-flex items-center gap-1">
                  <CornerDownLeft className="h-2.5 w-2.5" /> Enter
                </kbd>
                Open
              </span>
              <span className="inline-flex items-center gap-1.5">
                <kbd className="px-1.5 py-0.5 rounded bg-white border border-hairline font-mono text-[10px]">Esc</kbd>
                Close
              </span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function SearchHint() {
  const SUGGESTIONS = ['AI', 'Healthcare', 'Generative AI', 'Portfolio', 'Why MGS'];
  return (
    <div className="px-5 py-8">
      <p className="text-[12px] tracking-[0.2em] uppercase font-bold text-brandblue mb-3">Try searching</p>
      <div className="flex flex-wrap gap-2" data-testid="search-suggestions">
        {SUGGESTIONS.map((s) => (
          <span
            key={s}
            className="px-3 py-1.5 rounded-full bg-sky-50 text-navy text-[11.5px] tracking-[0.15em] uppercase font-bold border border-hairline"
          >
            {s}
          </span>
        ))}
      </div>
      <p className="mt-6 text-[12px] text-slatebody/80">
        Pages, services, case studies, projects, and team members are all searchable.
      </p>
    </div>
  );
}
