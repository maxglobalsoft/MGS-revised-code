import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence, useReducedMotion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X, ChevronDown } from 'lucide-react';
import { PrimaryButton } from '@/components/brand/Buttons';
import { HOME } from '@/constants/testIds';
import { useSite } from '@/context/SiteContext';
import SearchOverlay from '@/components/layout/SearchOverlay';
import GlobeSearchButton from '@/components/layout/GlobeSearchButton';

const DEFAULT_LOGO_URL = '/mgs-logo.png';
const EASE = [0.22, 1, 0.36, 1];

// Route-based nav links. `hash` items navigate to home then smooth-scroll to that section.
// `children` items render as a dropdown submenu.
const DEFAULT_LINKS = [
  { label: 'About Us', children: [
    { label: 'Why MGS', to: '/why-mgs' },
    { label: 'Our Team', to: '/our-team' },
  ]},
  { label: 'Services', to: '/services' },
  { label: 'Industries', to: '/industries' },
  { label: 'Portfolio', to: '/portfolio' },
  { label: 'Case Study', to: '/case-studies' },
  { label: 'Career', to: '/career' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { data: site } = useSite();

  const LOGO_URL = site?.logo_url || DEFAULT_LOGO_URL;
  const links =
    Array.isArray(site?.nav_links) && site.nav_links.length
      ? site.nav_links.map((l) => ({
          label: l.label,
          to: l.to,
          hash: l.hash,
          children: Array.isArray(l.children) && l.children.length ? l.children : undefined,
        }))
      : DEFAULT_LINKS;

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Cmd/Ctrl + K → open search overlay
  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const handleHashClick = (e, l) => {
    if (!l.hash) return;
    e.preventDefault();
    setOpen(false);
    if (location.pathname === l.to) {
      document.getElementById(l.hash.replace('#', ''))?.scrollIntoView({ behavior: 'smooth' });
    } else {
      navigate(l.to + l.hash);
    }
  };

  const isActive = (l) => {
    if (l.children) {
      return l.children.some((c) => c.to && location.pathname.startsWith(c.to));
    }
    if (l.hash) return false;
    if (l.to === '/') return location.pathname === '/';
    return location.pathname.startsWith(l.to);
  };

  return (
    <motion.header
      data-testid={HOME.navbar}
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.55, ease: EASE }}
      className={[
        'fixed top-0 inset-x-0 z-50 transition-all duration-300',
        scrolled
          ? 'bg-white/85 backdrop-blur-md shadow-soft border-b border-hairline'
          : 'bg-transparent',
      ].join(' ')}
    >
      <div className="relative flex items-center justify-between pr-4 sm:pr-6 lg:pr-10">
        <Link to="/" className="flex items-center gap-2 pl-2 sm:pl-4 lg:pl-6" data-testid={HOME.navLogo}>
          <img
            src={LOGO_URL}
            alt="Max Global Software — Quality Beyond Desires"
            className="h-36 lg:h-40 w-auto object-contain"
          />
        </Link>

        <nav className="hidden lg:flex items-center gap-1">
          {links.map((l) =>
            l.children ? (
              <DropdownNavItem
                key={l.label}
                link={l}
                active={isActive(l)}
                onHashClick={handleHashClick}
              />
            ) : (
              <TopNavItem
                key={l.label}
                link={l}
                active={isActive(l)}
                onHashClick={handleHashClick}
              />
            )
          )}
        </nav>

        <div className="flex items-center gap-3">
          <GlobeSearchButton onClick={() => setSearchOpen(true)} />
          <Link to="/contact" className="hidden sm:inline-flex">
            <PrimaryButton data-testid={HOME.navContact}>Contact</PrimaryButton>
          </Link>
          <button
            className="lg:hidden h-10 w-10 inline-flex items-center justify-center rounded-full bg-white border border-hairline text-navy"
            onClick={() => setOpen((v) => !v)}
            aria-label="Toggle menu"
            aria-expanded={open}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <MobileMenu
            links={links}
            onClose={() => setOpen(false)}
            onHashClick={handleHashClick}
          />
        )}
      </AnimatePresence>

      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />
    </motion.header>
  );
}

/* ─── Top-level nav item (simple link) ─────────────────────────────────── */

function TopNavItem({ link, active, onHashClick }) {
  const reducedMotion = useReducedMotion();
  const base =
    'group relative inline-flex items-center px-4 py-2.5 rounded-full text-[12px] tracking-[0.16em] uppercase font-bold transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60';
  const tone = active ? 'text-navy-deep' : 'text-navy/75 hover:text-navy-deep';

  const inner = (
    <>
      {/* Hover pill background */}
      <span
        aria-hidden="true"
        className="absolute inset-0 rounded-full bg-white shadow-soft opacity-0 scale-95 transition-all duration-300 ease-out group-hover:opacity-100 group-hover:scale-100 -z-10"
      />
      {/* Label with subtle lift */}
      <motion.span
        className="relative"
        whileHover={reducedMotion ? {} : { y: -1 }}
        transition={{ duration: 0.2, ease: EASE }}
      >
        {link.label}
      </motion.span>
      {/* Hover gold underline (grows from left) */}
      <span
        aria-hidden="true"
        className="absolute left-4 right-4 -bottom-0.5 h-[2px] rounded-full bg-gold-gradient origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-300 ease-out"
      />
      {/* Active-page underline (layoutId) */}
      {active && (
        <motion.span
          layoutId="nav-underline"
          className="absolute left-4 right-4 -bottom-0.5 h-[3px] rounded-full bg-gold-gradient"
          transition={{ type: 'spring', stiffness: 380, damping: 30 }}
        />
      )}
    </>
  );

  if (link.hash) {
    return (
      <a
        href={link.to + link.hash}
        onClick={(e) => onHashClick(e, link)}
        className={`${base} ${tone}`}
        data-testid={`nav-item-${slugify(link.label)}`}
      >
        {inner}
      </a>
    );
  }

  return (
    <NavLink
      to={link.to}
      end={link.to === '/'}
      className={`${base} ${tone}`}
      data-testid={`nav-item-${slugify(link.label)}`}
    >
      {inner}
    </NavLink>
  );
}

/* ─── Dropdown nav item (parent with children) ─────────────────────────── */

function DropdownNavItem({ link, active }) {
  const [open, setOpen] = useState(false);
  const reducedMotion = useReducedMotion();
  const closeTimer = useRef(null);
  const wrapperRef = useRef(null);

  const openMenu = () => {
    if (closeTimer.current) {
      clearTimeout(closeTimer.current);
      closeTimer.current = null;
    }
    setOpen(true);
  };
  const scheduleClose = () => {
    if (closeTimer.current) clearTimeout(closeTimer.current);
    closeTimer.current = setTimeout(() => setOpen(false), 160);
  };

  // Click-outside + Escape close
  useEffect(() => {
    const onDoc = (e) => {
      if (!wrapperRef.current?.contains(e.target)) {
        if (closeTimer.current) {
          clearTimeout(closeTimer.current);
          closeTimer.current = null;
        }
        setOpen(false);
      }
    };
    const onKey = (e) => { if (e.key === 'Escape') setOpen(false); };
    if (open) {
      document.addEventListener('mousedown', onDoc);
      document.addEventListener('keydown', onKey);
    }
    return () => {
      document.removeEventListener('mousedown', onDoc);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const onTriggerKeyDown = (e) => {
    if (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown') {
      e.preventDefault();
      openMenu();
    }
  };

  return (
    <div
      ref={wrapperRef}
      onMouseEnter={openMenu}
      onMouseLeave={scheduleClose}
      className="relative inline-flex"
    >
      <button
        type="button"
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
        onFocus={openMenu}
        onKeyDown={onTriggerKeyDown}
        data-testid={`nav-item-${slugify(link.label)}`}
        className={[
          'group relative inline-flex items-center gap-1.5 px-4 py-2.5 rounded-full text-[12px] tracking-[0.16em] uppercase font-bold transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60',
          active || open ? 'text-navy-deep' : 'text-navy/75 hover:text-navy-deep',
        ].join(' ')}
      >
        {/* Hover/open pill background */}
        <span
          aria-hidden="true"
          className={[
            'absolute inset-0 rounded-full bg-white shadow-soft transition-all duration-300 ease-out -z-10',
            open ? 'opacity-100 scale-100' : 'opacity-0 scale-95 group-hover:opacity-100 group-hover:scale-100',
          ].join(' ')}
        />
        <motion.span
          className="relative"
          whileHover={reducedMotion ? {} : { y: -1 }}
          transition={{ duration: 0.2, ease: EASE }}
        >
          {link.label}
        </motion.span>
        <motion.span
          animate={{ rotate: open ? 180 : 0 }}
          transition={{ duration: 0.25, ease: EASE }}
          className="relative inline-flex"
        >
          <ChevronDown className="h-3.5 w-3.5" strokeWidth={2.5} />
        </motion.span>

        {/* Hover gold underline */}
        <span
          aria-hidden="true"
          className={[
            'absolute left-4 right-4 -bottom-0.5 h-[2px] rounded-full bg-gold-gradient origin-left transition-transform duration-300 ease-out',
            open ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100',
          ].join(' ')}
        />
        {active && (
          <motion.span
            layoutId="nav-underline"
            className="absolute left-4 right-4 -bottom-0.5 h-[3px] rounded-full bg-gold-gradient"
            transition={{ type: 'spring', stiffness: 380, damping: 30 }}
          />
        )}
      </button>

      <AnimatePresence>
        {open && (
          <>
            {/* Invisible bridge — cursor can travel from parent to items without closing */}
            <div aria-hidden="true" className="absolute left-0 right-0 top-full h-3" />
            <motion.div
              role="menu"
              aria-label={`${link.label} submenu`}
              data-testid={`nav-dropdown-${slugify(link.label)}`}
              initial={reducedMotion ? { opacity: 0 } : { opacity: 0, y: -8 }}
              animate={reducedMotion ? { opacity: 1 } : { opacity: 1, y: 0 }}
              exit={reducedMotion ? { opacity: 0 } : { opacity: 0, y: -6 }}
              transition={{ duration: 0.3, ease: EASE }}
              className="absolute left-[calc(50%-52px)] -translate-x-1/2 top-[calc(100%+8px)] flex flex-col items-center gap-1.5"
            >
              <motion.ul
                initial="hidden"
                animate="show"
                exit="hidden"
                variants={{
                  hidden: {},
                  show: { transition: { staggerChildren: 0.09, delayChildren: 0.05 } },
                }}
                className="flex flex-col items-center gap-1.5"
              >
                {link.children.map((c) => (
                  <motion.li
                    key={c.label}
                    role="none"
                    variants={{
                      hidden: reducedMotion ? { opacity: 0 } : { opacity: 0, y: -10 },
                      show: reducedMotion
                        ? { opacity: 1, transition: { duration: 0.3, ease: EASE } }
                        : { opacity: 1, y: 0, transition: { duration: 0.45, ease: EASE } },
                    }}
                  >
                    <DropdownLink item={c} onPick={() => setOpen(false)} />
                  </motion.li>
                ))}
              </motion.ul>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

function DropdownLink({ item, onPick }) {
  const reducedMotion = useReducedMotion();
  const btnRef = useRef(null);

  // 3D tilt based on cursor position inside the card
  const tx = useMotionValue(0);
  const ty = useMotionValue(0);
  const rotateX = useSpring(useTransform(ty, [-1, 1], [8, -8]), { stiffness: 220, damping: 18 });
  const rotateY = useSpring(useTransform(tx, [-1, 1], [-10, 10]), { stiffness: 220, damping: 18 });
  // Glow follows cursor inside the pill
  const glowX = useTransform(tx, [-1, 1], ['10%', '90%']);
  const glowY = useTransform(ty, [-1, 1], ['10%', '90%']);

  const onMove = (e) => {
    if (reducedMotion) return;
    const r = btnRef.current?.getBoundingClientRect?.();
    if (!r) return;
    const nx = (e.clientX - r.left) / r.width * 2 - 1; // -1 .. 1
    const ny = (e.clientY - r.top) / r.height * 2 - 1;
    tx.set(nx);
    ty.set(ny);
  };
  const onLeave = () => { tx.set(0); ty.set(0); };

  return (
    <motion.div
      whileHover={reducedMotion ? {} : { scale: 1.05, y: -2 }}
      whileTap={reducedMotion ? {} : { scale: 0.97 }}
      transition={{ type: 'spring', stiffness: 380, damping: 24 }}
      style={{ perspective: '700px' }}
    >
      <motion.div
        ref={btnRef}
        onMouseMove={onMove}
        onMouseLeave={onLeave}
        style={{
          rotateX: reducedMotion ? 0 : rotateX,
          rotateY: reducedMotion ? 0 : rotateY,
          transformStyle: 'preserve-3d',
          willChange: 'transform',
        }}
        transition={{ type: 'spring', stiffness: 220, damping: 18 }}
      >
        <NavLink
          to={item.to}
          role="menuitem"
          onClick={onPick}
          className="group relative inline-flex items-center justify-center whitespace-nowrap rounded-full px-4 py-2 text-[10.5px] tracking-[0.18em] uppercase font-bold text-white bg-navy-deep ring-1 ring-white/10 shadow-[0_8px_22px_rgba(15,25,45,0.32)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60"
        >
          {/* Conic-gradient animated border ring */}
          <motion.span
            aria-hidden="true"
            initial={false}
            animate={reducedMotion ? { opacity: 0 } : { rotate: [0, 360], opacity: 1 }}
            transition={reducedMotion ? {} : { rotate: { duration: 4, repeat: Infinity, ease: 'linear' }, opacity: { duration: 0.4 } }}
            className="absolute -inset-[1.5px] rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none -z-10"
            style={{
              background:
                'conic-gradient(from 0deg, #C9962E 0deg, #E8C25A 90deg, transparent 180deg, transparent 270deg, #C9962E 360deg)',
              filter: 'blur(0.5px)',
            }}
          />
          {/* Cursor-following bloom glow inside the pill */}
          <motion.span
            aria-hidden="true"
            style={{
              left: reducedMotion ? '50%' : glowX,
              top: reducedMotion ? '50%' : glowY,
              transform: 'translate(-50%, -50%)',
              background:
                'radial-gradient(circle, rgba(232,194,90,0.55) 0%, rgba(201,150,46,0.18) 35%, transparent 70%)',
            }}
            className="pointer-events-none absolute h-20 w-20 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500"
          />
          {/* Diagonal sheen sweep */}
          <span
            aria-hidden="true"
            className="absolute inset-y-0 -left-1/3 w-1/3 -skew-x-12 bg-white/20 blur-md opacity-0 group-hover:opacity-100 transition-all duration-[900ms] ease-out group-hover:translate-x-[420%]"
          />
          {/* Soft inner ambient glow on hover */}
          <span
            aria-hidden="true"
            className="absolute inset-0 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500"
            style={{
              boxShadow:
                'inset 0 0 26px rgba(232,194,90,0.25), inset 0 0 12px rgba(232,194,90,0.18)',
            }}
          />

          {/* Label */}
          <span
            className="relative z-10 inline-block text-white/85 transition-all duration-500 group-hover:text-white group-hover:[text-shadow:0_0_18px_rgba(232,194,90,0.55)]"
            style={{ transform: 'translateZ(20px)' }}
          >
            {item.label}
          </span>
        </NavLink>
      </motion.div>
    </motion.div>
  );
}

/* ─── Mobile menu (accordion for items with children) ──────────────────── */

function MobileMenu({ links, onClose, onHashClick }) {
  return (
    <motion.div
      initial={{ height: 0, opacity: 0 }}
      animate={{ height: 'auto', opacity: 1 }}
      exit={{ height: 0, opacity: 0 }}
      transition={{ duration: 0.3, ease: EASE }}
      className="lg:hidden bg-white border-t border-hairline overflow-hidden"
    >
      <div className="container mx-auto py-4 flex flex-col gap-1">
        {links.map((l) =>
          l.children ? (
            <MobileAccordionItem key={l.label} link={l} onClose={onClose} />
          ) : (
            <MobileLink key={l.label} link={l} onClose={onClose} onHashClick={onHashClick} />
          )
        )}
        <Link
          to="/contact"
          onClick={onClose}
          className="mt-2 block py-2.5 px-2 rounded-lg text-[#C9962E] font-semibold"
        >
          Contact →
        </Link>
      </div>
    </motion.div>
  );
}

function MobileLink({ link, onClose, onHashClick }) {
  const base = 'block py-2.5 px-2 rounded-lg text-navy/85 font-medium hover:bg-sky-50';
  if (link.hash) {
    return (
      <a
        href={link.to + link.hash}
        onClick={(e) => { onHashClick(e, link); onClose(); }}
        className={base}
      >
        {link.label}
      </a>
    );
  }
  return (
    <NavLink
      to={link.to}
      end={link.to === '/'}
      onClick={onClose}
      className={({ isActive }) => base + (isActive ? ' text-navy-deep bg-sky-50' : '')}
    >
      {link.label}
    </NavLink>
  );
}

function MobileAccordionItem({ link, onClose }) {
  const [open, setOpen] = useState(false);
  return (
    <div>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        data-testid={`mobile-nav-accordion-${slugify(link.label)}`}
        className="w-full flex items-center justify-between py-2.5 px-2 rounded-lg text-navy/85 font-medium hover:bg-sky-50"
      >
        <span>{link.label}</span>
        <motion.span animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.25, ease: EASE }}>
          <ChevronDown className="h-4 w-4" />
        </motion.span>
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.ul
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: EASE }}
            className="overflow-hidden pl-3 border-l border-hairline ml-2"
          >
            {link.children.map((c) => (
              <li key={c.label}>
                <NavLink
                  to={c.to}
                  onClick={onClose}
                  className={({ isActive }) =>
                    'block py-2 px-2 rounded-lg text-sm text-navy/80 hover:bg-sky-50' +
                    (isActive ? ' text-navy-deep bg-sky-50' : '')
                  }
                >
                  {c.label}
                </NavLink>
              </li>
            ))}
          </motion.ul>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ─── helpers ──────────────────────────────────────────────────────────── */

function slugify(s) {
  return String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
}
