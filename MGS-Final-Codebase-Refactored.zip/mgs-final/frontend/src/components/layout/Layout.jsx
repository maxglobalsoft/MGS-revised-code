import React from 'react';
import { Outlet } from 'react-router-dom';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import ScrollToTop from '@/components/layout/ScrollToTop';
import AskVicky from '@/components/brand/AskVicky';
import ScrollProgress from '@/components/brand/ScrollProgress';
import { usePageMeta } from '@/hooks/usePageMeta';

export default function Layout() {
  usePageMeta();
  return (
    <div className="min-h-screen bg-sky-50">
      <ScrollProgress />
      <ScrollToTop />
      <Navbar />
      <main>
        <Outlet />
      </main>
      <Footer />
      <AskVicky />
    </div>
  );
}
