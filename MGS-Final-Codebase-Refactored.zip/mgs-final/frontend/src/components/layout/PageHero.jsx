import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';

/**
 * Reusable inner-page top banner.
 * - Light brand-blue background with subtle mesh gradient.
 * - Breadcrumb (Home / Page).
 * - Large navy title + optional subtitle.
 * - Gentle fade-up entrance.
 */
export default function PageHero({ title, subtitle, crumb }) {
  return (
    <section className="relative pt-52 pb-20 overflow-hidden">
      <div className="absolute inset-0 bg-sky-100" />
      <div className="absolute inset-0 bg-hero-mesh bg-[length:200%_200%] animate-mesh-pan" />
      <svg
        className="absolute inset-0 w-full h-full opacity-[0.05] pointer-events-none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <pattern id="pgdots" x="0" y="0" width="22" height="22" patternUnits="userSpaceOnUse">
            <circle cx="2" cy="2" r="1.1" fill="#2F6FB0" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#pgdots)" />
      </svg>

      <div className="container mx-auto relative">
        <motion.nav
          aria-label="Breadcrumb"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          className="flex items-center gap-1 text-[12px] text-slatebody"
        >
          <Link to="/" className="hover:text-brandblue">Home</Link>
          <ChevronRight className="h-3.5 w-3.5 text-mute" />
          <span className="font-semibold text-navy">{crumb || title}</span>
        </motion.nav>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.65, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
          className="mt-4 text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.05] tracking-tight text-navy-deep"
        >
          {title}
        </motion.h1>

        {subtitle && (
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.25, ease: [0.22, 1, 0.36, 1] }}
            className="mt-5 max-w-2xl text-slatebody text-base sm:text-lg leading-relaxed"
          >
            {subtitle}
          </motion.p>
        )}

        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ duration: 0.8, delay: 0.35, ease: [0.22, 1, 0.36, 1] }}
          style={{ transformOrigin: 'left' }}
          className="mt-6 h-[2px] w-24 rounded-full bg-gradient-to-r from-[#2BA8E0] via-[#2F6FB0] to-[#E8C25A]"
        />
      </div>
    </section>
  );
}
