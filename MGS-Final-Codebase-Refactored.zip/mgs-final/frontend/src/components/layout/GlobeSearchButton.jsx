import React, { useRef, useState } from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion';
import { Globe } from 'lucide-react';

/**
 * GlobeSearchButton — premium hover-driven globe trigger.
 *
 * Hover stack (all GPU-friendly, no cursor-magnet displacement so it never
 * blinks):
 *   1. Slow continuous Z-axis spin of the globe glyph (icon always visible)
 *   2. Rotating gold conic ring around the button
 *   3. Two staggered radial pulse waves
 *   4. Orbiting gold satellite dot
 *   5. Radar wedge sweep over the globe
 *   6. Soft outer gold halo + inner bloom
 *   7. Slide-in "Search · ⌘K" hint pill morphing out to the right
 *
 * Stability fix: the *wrapper* owns hover so the visual button doesn't move
 * out from under the cursor. No x/y magnet translate.
 */
export default function GlobeSearchButton({ onClick }) {
  const reduced = useReducedMotion();
  const wrapRef = useRef(null);
  const [hover, setHover] = useState(false);

  return (
    <div
      ref={wrapRef}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      className="relative hidden sm:inline-flex items-center"
      // Larger generous hit area via padding so micro mouse jitter never leaves
      style={{ padding: '6px' }}
    >
      <motion.button
        type="button"
        aria-label="Open site search"
        data-testid="navbar-search-btn"
        onClick={onClick}
        onFocus={() => setHover(true)}
        onBlur={() => setHover(false)}
        whileTap={reduced ? {} : { scale: 0.92 }}
        animate={reduced ? {} : { scale: hover ? 1.06 : 1 }}
        transition={{ type: 'spring', stiffness: 320, damping: 22 }}
        className="group relative h-10 w-10 inline-flex items-center justify-center rounded-full bg-white border border-hairline text-navy-deep shadow-sm focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60"
      >
        {/* (2) Rotating conic gold ring — fills outside, masked by inner disc */}
        <motion.span
          aria-hidden="true"
          animate={reduced ? {} : { rotate: hover ? 360 : 0, opacity: hover ? 1 : 0 }}
          transition={{
            rotate: { duration: 3.2, repeat: hover && !reduced ? Infinity : 0, ease: 'linear' },
            opacity: { duration: 0.3 },
          }}
          className="pointer-events-none absolute -inset-[2px] rounded-full"
          style={{
            background:
              'conic-gradient(from 0deg, #C9962E 0deg, #E8C25A 70deg, transparent 160deg, transparent 280deg, #C9962E 360deg)',
            filter: 'blur(0.4px)',
            zIndex: 0,
          }}
        />
        {/* Mask: solid white disc above the ring so the ring shows as a halo border */}
        <span
          aria-hidden="true"
          className="absolute inset-[1.5px] rounded-full bg-white"
          style={{ zIndex: 1 }}
        />

        {/* (3) Staggered pulse waves */}
        <AnimatePresence>
          {hover && !reduced && (
            <>
              <motion.span
                key="pulse-1"
                aria-hidden="true"
                initial={{ scale: 0.7, opacity: 0.55 }}
                animate={{ scale: 1.85, opacity: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 1.5, repeat: Infinity, ease: 'easeOut' }}
                className="pointer-events-none absolute inset-0 rounded-full border-2 border-[#C9962E]/55"
                style={{ zIndex: 0 }}
              />
              <motion.span
                key="pulse-2"
                aria-hidden="true"
                initial={{ scale: 0.7, opacity: 0.4 }}
                animate={{ scale: 1.85, opacity: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 1.5, repeat: Infinity, ease: 'easeOut', delay: 0.75 }}
                className="pointer-events-none absolute inset-0 rounded-full border-2 border-[#E8C25A]/55"
                style={{ zIndex: 0 }}
              />
            </>
          )}
        </AnimatePresence>

        {/* (6) Inner soft bloom on hover */}
        <span
          aria-hidden="true"
          className="absolute inset-[1.5px] rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500"
          style={{
            background:
              'radial-gradient(circle at 50% 50%, rgba(232,194,90,0.30) 0%, rgba(232,194,90,0.10) 45%, transparent 75%)',
            zIndex: 2,
          }}
        />

        {/* (1) Globe — slow continuous in-plane spin so it stays visible */}
        <motion.span
          aria-hidden="true"
          animate={reduced ? {} : { rotate: hover ? 360 : 0 }}
          transition={{ duration: 5, repeat: hover && !reduced ? Infinity : 0, ease: 'linear' }}
          className="relative inline-flex items-center justify-center"
          style={{ zIndex: 3 }}
        >
          <Globe
            className="h-[18px] w-[18px] text-navy-deep transition-colors duration-300 group-hover:text-[#0E1C3F]"
            strokeWidth={2.1}
          />
        </motion.span>

        {/* (5) Radar wedge sweep over the globe */}
        <AnimatePresence>
          {hover && !reduced && (
            <motion.span
              key="scan"
              aria-hidden="true"
              initial={{ opacity: 0, rotate: 0 }}
              animate={{ opacity: 1, rotate: 360 }}
              exit={{ opacity: 0 }}
              transition={{
                rotate: { duration: 1.8, repeat: Infinity, ease: 'linear' },
                opacity: { duration: 0.25 },
              }}
              className="pointer-events-none absolute inset-[3px] rounded-full"
              style={{
                background:
                  'conic-gradient(from 0deg, transparent 0deg, rgba(201,150,46,0.55) 30deg, transparent 70deg)',
                mixBlendMode: 'multiply',
                zIndex: 3,
              }}
            />
          )}
        </AnimatePresence>

        {/* (4) Orbiting satellite dot */}
        <motion.span
          aria-hidden="true"
          animate={reduced ? {} : { rotate: hover ? 360 : 0, opacity: hover ? 1 : 0 }}
          transition={{
            rotate: { duration: 2.4, repeat: hover && !reduced ? Infinity : 0, ease: 'linear' },
            opacity: { duration: 0.25 },
          }}
          className="pointer-events-none absolute inset-0"
          style={{ zIndex: 4 }}
        >
          <span
            className="absolute left-1/2 -top-[2px] -translate-x-1/2 h-[7px] w-[7px] rounded-full bg-gradient-to-br from-[#FFE8A8] to-[#C9962E]"
            style={{
              boxShadow:
                '0 0 8px 1.5px rgba(232,194,90,0.95), 0 0 16px rgba(232,194,90,0.55)',
            }}
          />
        </motion.span>

        {/* Outer gold shadow halo on hover */}
        <span
          aria-hidden="true"
          className="absolute inset-0 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
          style={{
            boxShadow: '0 10px 28px rgba(201,150,46,0.42)',
            zIndex: 0,
          }}
        />
      </motion.button>

      {/* (7) "Search · ⌘K" hint pill — morphs out to the right */}
      <AnimatePresence>
        {hover && (
          <motion.div
            key="kbd"
            aria-hidden="true"
            initial={{ opacity: 0, x: -10, scale: 0.85 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: -8, scale: 0.9 }}
            transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
            className="ml-2 hidden md:inline-flex items-center gap-1.5 rounded-full bg-[#0F192D]/95 px-3 py-1 text-[10px] tracking-[0.18em] uppercase font-bold text-white/90 ring-1 ring-white/10 shadow-[0_8px_22px_rgba(15,25,45,0.32)] pointer-events-none"
          >
            <span className="text-[#E8C25A]">Search</span>
            <span className="opacity-40">·</span>
            <span className="font-mono normal-case tracking-normal text-white/85">⌘K</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
