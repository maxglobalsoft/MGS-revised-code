import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles } from 'lucide-react';
import { HOME } from '@/constants/testIds';

/**
 * "Ask Vicky" floating AI assistant pill — persistent across every page.
 * Lives in the shared Layout so it shows on all routes, not just Home.
 */
export default function AskVicky() {
  return (
    <motion.button
      data-testid={HOME.askVicky}
      initial={{ opacity: 0, scale: 0.6 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 0.8, duration: 0.5 }}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className="fixed bottom-6 right-6 z-40 flex items-center gap-2 rounded-full bg-navy text-white pl-3 pr-4 py-2 shadow-soft hover:shadow-[0_14px_36px_rgba(31,45,69,0.35)] transition-shadow"
    >
      <span className="h-8 w-8 rounded-full bg-gold-gradient inline-flex items-center justify-center">
        <Sparkles className="h-4 w-4 text-white" />
      </span>
      <span className="text-sm font-semibold">Ask Vicky</span>
    </motion.button>
  );
}
