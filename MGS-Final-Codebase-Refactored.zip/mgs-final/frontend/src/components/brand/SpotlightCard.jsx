import React, { useRef } from 'react';
import { cn } from '@/lib/utils';

/**
 * Premium card wrapper:
 * 1. Soft radial spotlight that follows the cursor (CSS variable driven).
 * 2. Animated conic-gradient border that fades in on hover (gold / teal / brand-blue).
 * 3. Lift + shadow on hover.
 *
 * Customizing the inner surface (e.g. for a gradient-filled card instead of the
 * default white):
 *   - `surfaceStyle` — inline style applied to the inner `.spotlight-bg` layer.
 *   - `surfaceClassName` — Tailwind classes for the inner surface (use to
 *     override the default white background).
 *
 * Pure CSS for performance; no per-frame React state.
 */
export default function SpotlightCard({
  children,
  className,
  surfaceClassName,
  surfaceStyle,
  as: Tag = 'div',
  inset = true,
  ...props
}) {
  const ref = useRef(null);

  const onMove = (e) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    el.style.setProperty('--mx', `${e.clientX - r.left}px`);
    el.style.setProperty('--my', `${e.clientY - r.top}px`);
  };

  return (
    <Tag
      ref={ref}
      onMouseMove={onMove}
      className={cn('spotlight-card group relative', className)}
      {...props}
    >
      {/* Animated conic border (visible only on hover) */}
      <span aria-hidden="true" className="spotlight-border" />
      {/* Inner surface (so the border peeks around the edge) */}
      <span
        aria-hidden="true"
        className={cn('spotlight-bg', inset && 'inset-px', surfaceClassName)}
        style={surfaceStyle}
      />
      {/* Cursor spotlight */}
      <span aria-hidden="true" className="spotlight-glow" />
      <div className="relative z-[1] h-full">{children}</div>
    </Tag>
  );
}
