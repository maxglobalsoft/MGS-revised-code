import React, { useEffect, useRef, useState } from 'react';
import { animate, useInView, useReducedMotion } from 'framer-motion';

/**
 * Animated count-up for free-form metric strings like "+38%", "99.2%",
 * "10x deploy", etc. Animates only the numeric portion in the middle.
 * Reduced-motion safe.
 */
export default function MetricCountUp({ value, duration = 1.6, className }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, amount: 0.4 });
  const reducedMotion = useReducedMotion();
  const [display, setDisplay] = useState(String(value ?? ''));

  useEffect(() => {
    if (!inView) return undefined;
    const str = String(value ?? '');
    const match = str.match(/^([^\d-]*)(-?[\d.,]+)(.*)$/);
    if (!match) {
      setDisplay(str);
      return undefined;
    }
    const [, prefix, num, suffix] = match;
    const target = parseFloat(num.replace(/,/g, ''));
    if (Number.isNaN(target)) {
      setDisplay(str);
      return undefined;
    }
    if (reducedMotion) {
      setDisplay(str);
      return undefined;
    }
    const decimals = (num.split('.')[1] || '').length;
    setDisplay(`${prefix}0${decimals ? '.' + '0'.repeat(decimals) : ''}${suffix}`);
    const controls = animate(0, target, {
      duration,
      ease: [0.22, 1, 0.36, 1],
      onUpdate: (v) => setDisplay(`${prefix}${v.toFixed(decimals)}${suffix}`),
    });
    return () => controls.stop();
  }, [inView, value, duration, reducedMotion]);

  return (
    <span ref={ref} className={className}>
      {display}
    </span>
  );
}
