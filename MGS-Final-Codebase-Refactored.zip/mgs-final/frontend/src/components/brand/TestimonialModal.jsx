import React, { useEffect, useRef } from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion';
import { X, Quote, Star } from 'lucide-react';

const EASE = [0.22, 1, 0.36, 1];

function StarRow({ count = 5 }) {
  return (
    <div className="flex items-center gap-0.5" aria-label={`${count} out of 5 stars`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={`h-4 w-4 ${i < count ? 'text-[#E8C25A] fill-[#E8C25A]' : 'text-slatebody/30'}`}
          strokeWidth={1.5}
        />
      ))}
    </div>
  );
}

/**
 * TestimonialModal — shared popup used by both:
 *   • Reviews page text-testimonial cards
 *   • Home Client Speaks section cards
 *
 * Props:
 *   testimonial: { quote, name, role, company, location, avatar, rating? } | null
 *   onClose:     () => void
 */
export default function TestimonialModal({ testimonial, onClose }) {
  const reducedMotion = useReducedMotion();
  const modalRef = useRef(null);
  const isOpen = !!testimonial;

  // ESC to close + focus trap basics + body scroll lock
  useEffect(() => {
    if (!isOpen) return;

    const prevBodyOverflow = document.body.style.overflow;
    const prevHtmlOverflow = document.documentElement.style.overflow;
    document.body.style.overflow = 'hidden';
    document.documentElement.style.overflow = 'hidden';

    const onKey = (e) => {
      if (e.key === 'Escape') onClose?.();
      if (e.key === 'Tab' && modalRef.current) {
        const focusables = modalRef.current.querySelectorAll(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        if (focusables.length === 0) return;
        const first = focusables[0];
        const last = focusables[focusables.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener('keydown', onKey);

    // Focus the close button after open
    setTimeout(() => {
      modalRef.current?.querySelector('[data-testid="testimonial-modal-close"]')?.focus();
    }, 50);

    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prevBodyOverflow;
      document.documentElement.style.overflow = prevHtmlOverflow;
    };
  }, [isOpen, onClose]);

  const subline = testimonial
    ? [
        [testimonial.role, testimonial.company].filter(Boolean).join(testimonial.role && testimonial.company ? ' of ' : ''),
        testimonial.location,
      ]
        .filter(Boolean)
        .join(' · ')
    : '';

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          role="dialog"
          aria-modal="true"
          aria-label={`Testimonial from ${testimonial?.name || 'client'}`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: reducedMotion ? 0 : 0.25 }}
          className="fixed inset-0 z-[90] flex items-center justify-center bg-navy-deep/75 backdrop-blur-sm p-4 sm:p-6"
          onClick={(e) => { if (e.target === e.currentTarget) onClose?.(); }}
          onMouseDown={(e) => { if (e.target === e.currentTarget) onClose?.(); }}
          data-testid="testimonial-modal-overlay"
        >
          <motion.div
            ref={modalRef}
            initial={{ scale: reducedMotion ? 1 : 0.94, y: reducedMotion ? 0 : 18, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: reducedMotion ? 1 : 0.96, opacity: 0 }}
            transition={{ duration: reducedMotion ? 0 : 0.35, ease: EASE }}
            className="relative w-full max-w-2xl rounded-3xl bg-white shadow-[0_30px_80px_rgba(15,25,45,0.45)] ring-1 ring-black/5 overflow-hidden"
            onClick={(e) => e.stopPropagation()}
            data-testid="testimonial-modal"
          >
            <button
              type="button"
              aria-label="Close testimonial"
              onClick={onClose}
              className="absolute top-4 right-4 z-10 h-10 w-10 inline-flex items-center justify-center rounded-full bg-white border border-hairline text-navy-deep hover:bg-sky-50 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60"
              data-testid="testimonial-modal-close"
            >
              <X className="h-4 w-4" />
            </button>

            <div className="p-8 sm:p-12">
              <Quote className="h-10 w-10 text-[#C9962E]" strokeWidth={1.6} />
              {typeof testimonial.rating === 'number' && (
                <div className="mt-4">
                  <StarRow count={testimonial.rating} />
                </div>
              )}
              <p
                className="mt-6 text-xl sm:text-2xl font-medium text-navy-deep leading-relaxed"
                data-testid="testimonial-modal-quote"
              >
                &ldquo;{testimonial.quote}&rdquo;
              </p>

              <div className="mt-10 flex items-center gap-4">
                {testimonial.avatar ? (
                  <img
                    src={testimonial.avatar}
                    alt=""
                    aria-hidden="true"
                    className="h-14 w-14 rounded-full object-cover ring-2 ring-white shadow-card"
                  />
                ) : (
                  <div className="h-14 w-14 rounded-full bg-sky-100" aria-hidden="true" />
                )}
                <div>
                  <p
                    className="text-base sm:text-lg font-bold text-navy-deep"
                    data-testid="testimonial-modal-name"
                  >
                    {testimonial.name}
                  </p>
                  {subline && (
                    <p className="text-sm text-slatebody mt-0.5" data-testid="testimonial-modal-subline">
                      {subline}
                    </p>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
