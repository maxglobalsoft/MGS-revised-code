import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion';
import { X, Paperclip, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import api from '@/lib/api';

const EASE = [0.22, 1, 0.36, 1];
const MAX_RESUME_BYTES = 10 * 1024 * 1024; // 10 MB

/**
 * ApplyJobModal — opens when a Career page job's "Apply" button is clicked.
 *
 * Props:
 *   job:     { title, ... } | null  (used to set jobTitle on submission)
 *   onClose: () => void
 */
export default function ApplyJobModal({ job, onClose }) {
  const reducedMotion = useReducedMotion();
  const modalRef = useRef(null);
  const fileInputRef = useRef(null);
  const isOpen = !!job;

  const [form, setForm] = useState({
    name: '',
    mobile: '',
    email: '',
    experience: '',
    message: '',
  });
  const [resume, setResume] = useState(null); // File | null
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  // Reset whenever modal re-opens for a different job
  useEffect(() => {
    if (isOpen) {
      setForm({ name: '', mobile: '', email: '', experience: '', message: '' });
      setResume(null);
      setErrors({});
      setSubmitting(false);
    }
  }, [isOpen, job]);

  useEffect(() => {
    if (!isOpen) return;
    const prevBodyOverflow = document.body.style.overflow;
    const prevHtmlOverflow = document.documentElement.style.overflow;
    document.body.style.overflow = 'hidden';
    document.documentElement.style.overflow = 'hidden';

    const onKey = (e) => {
      if (e.key === 'Escape') onClose?.();
      if (e.key === 'Tab' && modalRef.current) {
        const focusables = modalRef.current.querySelectorAll(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        if (focusables.length === 0) return;
        const first = focusables[0];
        const last = focusables[focusables.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener('keydown', onKey);
    setTimeout(() => {
      modalRef.current?.querySelector('[data-testid="apply-input-name"]')?.focus();
    }, 60);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prevBodyOverflow;
      document.documentElement.style.overflow = prevHtmlOverflow;
    };
  }, [isOpen, onClose]);

  const setField = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const validate = () => {
    const next = {};
    if (!form.name.trim()) next.name = 'Please enter your name.';
    if (!form.email.trim()) {
      next.email = 'Email is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      next.email = 'Please enter a valid email.';
    }
    if (!form.message.trim()) next.message = 'Tell us about yourself.';
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleResumePick = (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > MAX_RESUME_BYTES) {
      toast.error('Resume must be 10MB or smaller.');
      e.target.value = '';
      return;
    }
    setResume(f);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate() || submitting) return;
    setSubmitting(true);
    try {
      const fd = new FormData();
      fd.append('jobTitle', job?.title || '');
      fd.append('name', form.name.trim());
      fd.append('email', form.email.trim());
      fd.append('mobile', form.mobile.trim());
      fd.append('experience', form.experience.trim());
      fd.append('message', form.message.trim());
      if (resume) fd.append('resume', resume);

      await api.post('/apply', fd, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      toast.success('Application submitted — we\u2019ll be in touch soon.');
      onClose?.();
    } catch (err) {
      toast.error('Could not submit application. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          role="dialog"
          aria-modal="true"
          aria-label={`Apply for ${job?.title || 'this position'}`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: reducedMotion ? 0 : 0.25 }}
          className="fixed inset-0 z-[90] flex items-center justify-center bg-navy-deep/75 backdrop-blur-sm p-4 sm:p-6"
          onClick={(e) => { if (e.target === e.currentTarget) onClose?.(); }}
          onMouseDown={(e) => { if (e.target === e.currentTarget) onClose?.(); }}
          data-testid="apply-modal-overlay"
        >
          <motion.div
            ref={modalRef}
            initial={{ scale: reducedMotion ? 1 : 0.94, y: reducedMotion ? 0 : 18, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: reducedMotion ? 1 : 0.96, opacity: 0 }}
            transition={{ duration: reducedMotion ? 0 : 0.35, ease: EASE }}
            className="relative w-full max-w-3xl max-h-[92vh] rounded-3xl bg-white shadow-[0_30px_80px_rgba(15,25,45,0.45)] ring-1 ring-black/5 overflow-hidden flex flex-col"
            onClick={(e) => e.stopPropagation()}
            data-testid="apply-modal"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 sm:px-10 py-5 sm:py-6 border-b border-hairline">
              <h3 className="text-lg sm:text-xl font-bold tracking-tight text-navy-deep" data-testid="apply-modal-title">
                Apply for this position
              </h3>
              <button
                type="button"
                aria-label="Close application form"
                onClick={onClose}
                className="h-10 w-10 inline-flex items-center justify-center rounded-full text-navy-deep hover:bg-sky-50 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60"
                data-testid="apply-modal-close"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Body */}
            <form
              onSubmit={handleSubmit}
              className="overflow-y-auto px-6 sm:px-10 py-6 sm:py-8"
              data-testid="apply-form"
              noValidate
            >
              <div className="grid sm:grid-cols-2 gap-5 sm:gap-6">
                <Field
                  label="Your Name"
                  required
                  error={errors.name}
                >
                  <input
                    type="text"
                    value={form.name}
                    onChange={(e) => setField('name', e.target.value)}
                    placeholder="Enter your name"
                    className={inputClass(!!errors.name)}
                    data-testid="apply-input-name"
                    autoComplete="name"
                  />
                </Field>

                <Field label="Mobile Number">
                  <input
                    type="tel"
                    value={form.mobile}
                    onChange={(e) => setField('mobile', e.target.value)}
                    placeholder="Enter your number"
                    className={inputClass(false)}
                    data-testid="apply-input-mobile"
                    autoComplete="tel"
                  />
                </Field>

                <Field label="Email address" required error={errors.email}>
                  <input
                    type="email"
                    value={form.email}
                    onChange={(e) => setField('email', e.target.value)}
                    placeholder="Enter your email id"
                    className={inputClass(!!errors.email)}
                    data-testid="apply-input-email"
                    autoComplete="email"
                  />
                </Field>

                <Field label="Total years of Exp.">
                  <input
                    type="text"
                    value={form.experience}
                    onChange={(e) => setField('experience', e.target.value)}
                    placeholder="Enter your total experience in year"
                    className={inputClass(false)}
                    data-testid="apply-input-experience"
                  />
                </Field>
              </div>

              <div className="mt-5 sm:mt-6">
                <Field label="Your Message / Requirements" required error={errors.message}>
                  <div className="relative">
                    <textarea
                      value={form.message}
                      onChange={(e) => setField('message', e.target.value)}
                      placeholder="Enter Your Message / Requirements"
                      rows={5}
                      className={`${inputClass(!!errors.message)} resize-none pr-12`}
                      data-testid="apply-input-message"
                    />
                    {/* Resume attach button */}
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      title={resume ? `Attached: ${resume.name}` : 'Attach resume (optional)'}
                      aria-label="Attach resume (optional)"
                      className={`absolute bottom-3 right-3 h-9 w-9 inline-flex items-center justify-center rounded-full transition-colors ${
                        resume ? 'bg-[#C9962E]/15 text-[#C9962E]' : 'bg-sky-50 text-navy-deep hover:bg-sky-100'
                      }`}
                      data-testid="apply-attach-resume"
                    >
                      <Paperclip className="h-4 w-4" />
                    </button>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".pdf,.doc,.docx,.rtf,.txt,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                      onChange={handleResumePick}
                      className="hidden"
                      data-testid="apply-resume-input"
                    />
                  </div>
                  {resume && (
                    <p className="mt-2 text-xs text-slatebody" data-testid="apply-resume-name">
                      Attached: <span className="font-semibold text-navy-deep">{resume.name}</span>
                      <button
                        type="button"
                        onClick={() => {
                          setResume(null);
                          if (fileInputRef.current) fileInputRef.current.value = '';
                        }}
                        className="ml-2 underline text-[#C9962E]"
                      >
                        remove
                      </button>
                    </p>
                  )}
                </Field>
              </div>

              <div className="mt-7 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <p className="text-xs sm:text-sm text-slatebody max-w-xs leading-relaxed">
                  We&rsquo;ll never share your details with third parties. We won&rsquo;t spam you.
                </p>
                <button
                  type="submit"
                  disabled={submitting}
                  className="group inline-flex items-center justify-center gap-2 rounded-full px-8 py-3.5 text-sm font-semibold bg-navy-deep text-white hover:bg-[#0F192D] transition-colors shadow-[0_10px_28px_rgba(15,25,45,0.25)] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60 disabled:opacity-60 disabled:cursor-not-allowed"
                  data-testid="apply-submit"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" /> Submitting…
                    </>
                  ) : (
                    'Submit'
                  )}
                </button>
              </div>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function Field({ label, required, error, children }) {
  return (
    <label className="block">
      <span className="block text-sm font-semibold text-navy-deep mb-2">
        {label} {required && <span className="text-[#C9962E]">*</span>}
      </span>
      {children}
      {error && (
        <span className="mt-1.5 block text-xs text-red-600" role="alert">
          {error}
        </span>
      )}
    </label>
  );
}

function inputClass(hasError) {
  return `w-full rounded-xl border ${
    hasError ? 'border-red-400 bg-red-50/30' : 'border-hairline bg-white'
  } px-4 py-3 text-base text-navy-deep placeholder:text-slatebody/55 focus:outline-none focus:border-[#C9962E] focus:ring-2 focus:ring-[#C9962E]/25 transition-colors`;
}
