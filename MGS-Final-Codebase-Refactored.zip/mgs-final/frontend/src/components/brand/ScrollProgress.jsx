import React from 'react';
import { motion, useScroll, useSpring } from 'framer-motion';

/**
 * Top-of-page scroll progress bar — gold gradient, driven by useScroll.
 * Provides a constant "premium" cue that you're moving through curated content.
 */
export default function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 120,
    damping: 22,
    mass: 0.3,
  });

  return (
    <motion.div
      aria-hidden="true"
      className="fixed top-0 left-0 right-0 z-[60] h-[3px] origin-left bg-gold-gradient pointer-events-none"
      style={{ scaleX }}
    />
  );
}
