import React, { useRef } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { cn } from '@/lib/utils';

/**
 * Premium gold→bronze primary button.
 * - Magnetic cursor follow (subtle).
 * - Hover lift + animated sheen sweep across the gold.
 * - Press scale-down with spring.
 * Matches the "premium, never gimmicky" animation brief.
 */
export const PrimaryButton = React.forwardRef(function PrimaryButton(
  { children, className, icon, ...props },
  ref
) {
  const localRef = useRef(null);
  const target = ref || localRef;

  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const x = useSpring(mx, { stiffness: 220, damping: 18, mass: 0.5 });
  const y = useSpring(my, { stiffness: 220, damping: 18, mass: 0.5 });

  const onMove = (e) => {
    const r = target.current?.getBoundingClientRect?.();
    if (!r) return;
    const px = e.clientX - (r.left + r.width / 2);
    const py = e.clientY - (r.top + r.height / 2);
    // limit magnetic pull
    mx.set(Math.max(-6, Math.min(6, px * 0.18)));
    my.set(Math.max(-4, Math.min(4, py * 0.22)));
  };
  const onLeave = () => {
    mx.set(0);
    my.set(0);
  };

  return (
    <motion.button
      ref={target}
      style={{ x, y }}
      onMouseMove={onMove}
      onMouseLeave={onLeave}
      whileHover={{ scale: 1.03 }}
      whileTap={{ scale: 0.96 }}
      transition={{ type: 'spring', stiffness: 360, damping: 22 }}
      className={cn(
        'group relative inline-flex items-center justify-center gap-2 overflow-hidden',
        'rounded-full px-7 py-3 text-sm font-semibold text-white',
        'bg-gold-gradient shadow-gold',
        'transition-shadow duration-300 hover:shadow-[0_18px_44px_rgba(201,150,46,0.5)]',
        'focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#C9962E]/60',
        className
      )}
      {...props}
    >
      <span className="relative z-10 inline-flex items-center gap-2">
        {icon}
        {children}
      </span>
      <span
        aria-hidden
        className="pointer-events-none absolute inset-y-0 -left-1/2 w-1/2 bg-gold-sheen opacity-0 group-hover:opacity-100 group-hover:animate-[sheen_900ms_ease-in-out]"
      />
    </motion.button>
  );
});

export const SecondaryButton = React.forwardRef(function SecondaryButton(
  { children, className, icon, ...props },
  ref
) {
  return (
    <motion.button
      ref={ref}
      whileHover={{ y: -2, scale: 1.02 }}
      whileTap={{ scale: 0.97 }}
      transition={{ type: 'spring', stiffness: 360, damping: 22 }}
      className={cn(
        'inline-flex items-center justify-center gap-2 rounded-full px-7 py-3 text-sm font-semibold',
        'border border-brandblue/30 bg-white text-navy shadow-soft',
        'transition-colors hover:bg-sky-100 hover:border-brandblue/60',
        'focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brandblue/50',
        className
      )}
      {...props}
    >
      {icon}
      {children}
    </motion.button>
  );
});
