import React from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { cn } from '@/lib/utils';

/**
 * Signature section heading reveal — bulletproof: the resting state of every
 * piece is fully visible (`opacity:1`, `y:0`). Animation is a bonus, never a
 * requirement for the text to show up. Heading uses `animate` (fires on mount)
 * so it can never end up hidden behind a viewport-trigger that didn't fire.
 */
export default function SectionHeading({
  eyebrow,
  title,
  subtitle,
  align = 'center',
  light = false,
  className,
}) {
  const isCenter = align === 'center';
  const reducedMotion = useReducedMotion();
  const EASE = [0.22, 1, 0.36, 1];

  return (
    <div
      className={cn(
        isCenter ? 'text-center mx-auto' : 'text-left',
        'max-w-3xl',
        className
      )}
    >
      {eyebrow && (
        <motion.div
          initial={reducedMotion ? false : { opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: EASE }}
          className={cn(
            'text-xs sm:text-sm uppercase tracking-[0.2em] font-semibold mb-3',
            light ? 'text-white/75' : 'text-brandblue'
          )}
        >
          {eyebrow}
        </motion.div>
      )}

      {/* Heading — fires on mount, resting state is fully visible */}
      <motion.h2
        initial={reducedMotion ? false : { opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: EASE }}
        className={cn(
          'text-3xl sm:text-4xl lg:text-5xl font-bold leading-[1.05] tracking-tight',
          light ? 'text-white' : 'text-navy-deep'
        )}
      >
        {title}
      </motion.h2>

      {/* Gradient divider draws L→R (decorative — safe to keep whileInView) */}
      <motion.div
        initial={reducedMotion ? false : { scaleX: 0 }}
        whileInView={{ scaleX: 1 }}
        viewport={{ once: true, amount: 0 }}
        transition={{ duration: 0.8, delay: 0.2, ease: EASE }}
        style={{ transformOrigin: isCenter ? 'center' : 'left' }}
        className={cn(
          'h-[2px] mt-5 rounded-full',
          isCenter ? 'mx-auto w-24' : 'w-24',
          'bg-gradient-to-r from-[#2BA8E0] via-[#2F6FB0] to-[#E8C25A]'
        )}
      />

      {subtitle && (
        <motion.p
          initial={reducedMotion ? false : { opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0 }}
          transition={{ duration: 0.55, delay: 0.3, ease: EASE }}
          className={cn(
            'mt-5 text-base sm:text-lg leading-relaxed',
            light ? 'text-white/80' : 'text-slatebody'
          )}
        >
          {subtitle}
        </motion.p>
      )}
    </div>
  );
}
