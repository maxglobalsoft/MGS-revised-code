import React, { useEffect, useRef } from 'react';
import { motion, AnimatePresence, useReducedMotion } from 'framer-motion';
import { X, User } from 'lucide-react';

const EASE = [0.22, 1, 0.36, 1];

/**
 * TeamMemberModal — premium bio popup for the Our Team grid.
 *
 * Layout:
 *   • White rounded card with soft deep shadow + faint brand/gold radial accents.
 *   • Large circular photo OVERLAPS the top edge of the card (rises above).
 *   • Desktop: photo top-left + name/role beside; Mobile: photo centered on top, stacked.
 *   • Thin gold→teal gradient divider under header. Bio max-w-2xl, scrolls if long.
 *
 * Choreography (skipped under prefers-reduced-motion):
 *   card rise → photo pop → name/role fade-up → divider draws L→R → bio fades up.
 *
 * Props:
 *   member: { name, role, photo, bio } | null
 *   onClose: () => void
 */
export default function TeamMemberModal({ member, onClose }) {
  const reducedMotion = useReducedMotion();
  const modalRef = useRef(null);
  const isOpen = !!member;

  useEffect(() => {
    if (!isOpen) return;
    const prevBodyOverflow = document.body.style.overflow;
    const prevHtmlOverflow = document.documentElement.style.overflow;
    document.body.style.overflow = 'hidden';
    document.documentElement.style.overflow = 'hidden';

    const onKey = (e) => {
      if (e.key === 'Escape') onClose?.();
      if (e.key === 'Tab' && modalRef.current) {
        const focusables = modalRef.current.querySelectorAll(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        if (focusables.length === 0) return;
        const first = focusables[0];
        const last = focusables[focusables.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener('keydown', onKey);
    setTimeout(() => {
      modalRef.current?.querySelector('[data-testid="team-modal-close"]')?.focus();
    }, 50);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prevBodyOverflow;
      document.documentElement.style.overflow = prevHtmlOverflow;
    };
  }, [isOpen, onClose]);

  // Choreography (or static if reduced-motion).
  const cardVariants = reducedMotion
    ? { hidden: { opacity: 1, scale: 1, y: 0 }, show: { opacity: 1, scale: 1, y: 0 } }
    : {
        hidden: { opacity: 0, scale: 0.95, y: 24 },
        show: {
          opacity: 1, scale: 1, y: 0,
          transition: { duration: 0.55, ease: EASE, when: 'beforeChildren', staggerChildren: 0.1, delayChildren: 0.15 },
        },
      };
  const photoVariants = reducedMotion
    ? { hidden: { opacity: 1, scale: 1 }, show: { opacity: 1, scale: 1 } }
    : { hidden: { opacity: 0, scale: 0.55 }, show: { opacity: 1, scale: 1, transition: { type: 'spring', stiffness: 230, damping: 18 } } };
  const fadeUp = reducedMotion
    ? { hidden: { opacity: 1, y: 0 }, show: { opacity: 1, y: 0 } }
    : { hidden: { opacity: 0, y: 14 }, show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: EASE } } };
  const dividerVariants = reducedMotion
    ? { hidden: { scaleX: 1 }, show: { scaleX: 1 } }
    : { hidden: { scaleX: 0 }, show: { scaleX: 1, transition: { duration: 0.65, ease: EASE } } };

  const placeholderName = member?.name && /^\[/.test(String(member.name).trim());
  const displayName = placeholderName ? 'Team Member' : member?.name;
  const photoOffset = 'translate-y-[-50%]'; // overlap by half the photo height

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          role="dialog"
          aria-modal="true"
          aria-label={`Bio for ${displayName || 'team member'}`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: reducedMotion ? 0 : 0.25 }}
          className="fixed inset-0 z-[90] flex items-center justify-center bg-navy-deep/75 backdrop-blur-sm p-4 sm:p-6"
          onClick={(e) => { if (e.target === e.currentTarget) onClose?.(); }}
          onMouseDown={(e) => { if (e.target === e.currentTarget) onClose?.(); }}
          data-testid="team-modal-overlay"
        >
          <motion.div
            ref={modalRef}
            variants={cardVariants}
            initial="hidden"
            animate="show"
            exit={reducedMotion ? undefined : { opacity: 0, scale: 0.96, y: 14, transition: { duration: 0.25, ease: EASE } }}
            className="relative w-full max-w-2xl rounded-3xl bg-white shadow-[0_40px_90px_rgba(15,25,45,0.45)] ring-1 ring-black/5 max-h-[88vh] flex flex-col mt-16 sm:mt-20"
            onClick={(e) => e.stopPropagation()}
            data-testid="team-modal"
          >
            {/* Faint brand/gold radial accent (top-right) */}
            <span
              aria-hidden="true"
              className="pointer-events-none absolute -top-12 -right-12 h-64 w-64 rounded-full overflow-hidden"
              style={{
                background:
                  'radial-gradient(circle, rgba(232,194,90,0.20), rgba(232,194,90,0.06) 55%, transparent 75%)',
              }}
            />
            {/* Faint brand/blue radial accent (bottom-left) */}
            <span
              aria-hidden="true"
              className="pointer-events-none absolute -bottom-12 -left-12 h-64 w-64 rounded-full overflow-hidden"
              style={{
                background:
                  'radial-gradient(circle, rgba(47,111,176,0.12), rgba(47,111,176,0.04) 55%, transparent 75%)',
              }}
            />

            {/* Photo — absolutely positioned to OVERLAP the top edge of the card */}
            <motion.div
              variants={photoVariants}
              className={`absolute top-0 left-1/2 -translate-x-1/2 sm:left-12 sm:translate-x-0 ${photoOffset} z-20`}
            >
              <Photo name={displayName} photo={member?.photo} placeholder={placeholderName} />
            </motion.div>

            {/* Close button */}
            <button
              type="button"
              aria-label="Close bio"
              onClick={onClose}
              className="absolute top-4 right-4 z-30 h-10 w-10 inline-flex items-center justify-center rounded-full bg-white/90 backdrop-blur border border-hairline text-navy-deep hover:bg-sky-50 hover:scale-105 transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-[#C9962E]/60"
              data-testid="team-modal-close"
            >
              <X className="h-4 w-4" />
            </button>

            {/* Body (scrolls). Top padding reserves space for the overlapping photo. */}
            <div className="relative z-10 overflow-y-auto px-6 sm:px-12 pt-24 sm:pt-12 pb-10 sm:pb-12 rounded-3xl">
              {/* Header row — desktop: name/role beside photo (photo absolute-positioned top-left, name pushed right via padding); mobile: name/role centered below photo */}
              <div className="flex flex-col sm:flex-row items-center sm:items-end gap-1 sm:gap-7 text-center sm:text-left sm:pl-44">
                <div className="flex-1 min-w-0">
                  <motion.h3
                    variants={fadeUp}
                    className="text-2xl sm:text-3xl font-bold tracking-tight text-navy-deep leading-tight"
                    data-testid="team-modal-name"
                  >
                    {displayName}
                  </motion.h3>
                  {member?.role && (
                    <motion.p
                      variants={fadeUp}
                      className="mt-1.5 text-sm sm:text-base text-brandblue font-medium"
                      data-testid="team-modal-role"
                    >
                      {member.role}
                    </motion.p>
                  )}
                </div>
              </div>

              {/* Gold → teal divider */}
              <motion.div
                variants={dividerVariants}
                className="mt-7 sm:mt-9 h-px origin-left"
                style={{
                  background:
                    'linear-gradient(90deg, rgba(232,194,90,0) 0%, #E8C25A 18%, #C9962E 45%, #2F6FB0 78%, rgba(47,111,176,0) 100%)',
                }}
              />

              {/* Bio */}
              <motion.div
                variants={fadeUp}
                className="mt-7 sm:mt-9 max-w-2xl"
              >
                {member?.bio && member.bio.trim() ? (
                  <p
                    className="text-base sm:text-lg text-navy-deep/90 leading-relaxed whitespace-pre-line"
                    data-testid="team-modal-bio"
                  >
                    {member.bio}
                  </p>
                ) : (
                  <p
                    className="text-sm sm:text-base italic text-slatebody/80"
                    data-testid="team-modal-bio-empty"
                  >
                    Full bio coming soon.
                  </p>
                )}
              </motion.div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function Photo({ name, photo, placeholder }) {
  const initials = String(name || '?')
    .replace(/\[.*?\]/g, '')
    .trim()
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0])
    .join('')
    .toUpperCase() || '–';

  return (
    <div className="relative">
      {/* Soft glow underneath */}
      <span
        aria-hidden="true"
        className="absolute -inset-3 rounded-full blur-2xl opacity-60"
        style={{
          background:
            'radial-gradient(circle, rgba(232,194,90,0.40), rgba(47,111,176,0.20) 55%, transparent 75%)',
        }}
      />
      {/* Gold gradient ring + thick white border */}
      <div
        className="relative h-32 w-32 sm:h-40 sm:w-40 rounded-full p-[3px]"
        style={{
          background:
            'linear-gradient(135deg, #C9962E 0%, #E8C25A 50%, #2F6FB0 100%)',
        }}
      >
        <div className="h-full w-full rounded-full p-[3px] bg-white">
          <div className="h-full w-full rounded-full overflow-hidden bg-sky-100 shadow-[0_20px_38px_rgba(15,25,45,0.28)]">
            {photo ? (
              <img
                src={photo}
                alt={name || 'Team member'}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                {placeholder ? (
                  <User className="h-12 w-12 text-navy-deep/40" strokeWidth={1.4} />
                ) : (
                  <span className="text-2xl font-bold text-navy-deep/55">
                    {initials}
                  </span>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
