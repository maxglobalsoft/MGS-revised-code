import React from 'react';
import { motion } from 'framer-motion';

/**
 * Signature "AI core" — the page-defining motif.
 * - Glowing circular network: 1 central node + 7 satellites.
 * - Lines draw in on load (pathLength), data-flow shimmer travels along key edges.
 * - Nodes gently pulse on a loop.
 * - Slow-rotating conic-gradient ring sits behind it.
 *
 * Honors prefers-reduced-motion via index.css globally.
 */
export default function AICore({ size = 140, dark = true }) {
  const c = 100;
  const nodes = [
    { id: 'c', x: c, y: c, r: 5.5 },
    { id: 'n1', x: 50, y: 42, r: 3.5 },
    { id: 'n2', x: 150, y: 38, r: 3.5 },
    { id: 'n3', x: 172, y: 92, r: 3.5 },
    { id: 'n4', x: 156, y: 156, r: 3.5 },
    { id: 'n5', x: 84, y: 170, r: 3.5 },
    { id: 'n6', x: 30, y: 130, r: 3.5 },
    { id: 'n7', x: 36, y: 76, r: 3.5 },
  ];
  const find = (id) => nodes.find((n) => n.id === id);
  const links = [
    ['c', 'n1'], ['c', 'n2'], ['c', 'n3'], ['c', 'n4'],
    ['c', 'n5'], ['c', 'n6'], ['c', 'n7'],
    ['n1', 'n2'], ['n2', 'n3'], ['n3', 'n4'],
    ['n4', 'n5'], ['n5', 'n6'], ['n6', 'n7'], ['n7', 'n1'],
  ];

  const accent = dark ? '#FFE08A' : '#E8C25A';
  const nodeColor = dark ? '#2BA8E0' : '#2F6FB0';
  const lineColor = dark ? 'rgba(43,168,224,0.55)' : 'rgba(47,111,176,0.4)';

  return (
    <div
      className="relative"
      style={{ width: size, height: size }}
      aria-hidden="true"
    >
      {/* Slow-rotating conic ring */}
      <motion.div
        className="absolute inset-0 rounded-full"
        style={{
          background:
            'conic-gradient(from 0deg, transparent 0deg, rgba(43,168,224,0.55) 90deg, transparent 180deg, rgba(232,194,90,0.45) 270deg, transparent 360deg)',
          WebkitMaskImage:
            'radial-gradient(circle, transparent 58%, #000 60%, #000 86%, transparent 88%)',
          maskImage:
            'radial-gradient(circle, transparent 58%, #000 60%, #000 86%, transparent 88%)',
        }}
        animate={{ rotate: 360 }}
        transition={{ duration: 18, repeat: Infinity, ease: 'linear' }}
      />

      {/* Outer halo */}
      <div
        className="absolute inset-[10%] rounded-full"
        style={{
          background:
            'radial-gradient(circle at 50% 50%, rgba(43,168,224,0.25) 0%, transparent 60%)',
        }}
      />

      <svg viewBox="0 0 200 200" className="absolute inset-0">
        <defs>
          <radialGradient id="aicGlow" cx="50%" cy="50%">
            <stop offset="0%" stopColor="#2BA8E0" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#2BA8E0" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="aicCore" cx="50%" cy="50%">
            <stop offset="0%" stopColor={accent} stopOpacity="1" />
            <stop offset="80%" stopColor={accent} stopOpacity="0.7" />
            <stop offset="100%" stopColor={accent} stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* Edges (draw-in) */}
        {links.map(([a, b], i) => {
          const A = find(a);
          const B = find(b);
          return (
            <motion.line
              key={`${a}-${b}`}
              x1={A.x}
              y1={A.y}
              x2={B.x}
              y2={B.y}
              stroke={lineColor}
              strokeWidth="0.9"
              initial={{ pathLength: 0, opacity: 0 }}
              animate={{ pathLength: 1, opacity: 1 }}
              transition={{
                duration: 1.4,
                delay: 0.4 + i * 0.05,
                ease: [0.22, 1, 0.36, 1],
              }}
            />
          );
        })}

        {/* Data-flow shimmer dots traveling from center to each outer node */}
        {nodes.slice(1).map((n, i) => (
          <motion.circle
            key={`flow-${n.id}`}
            r={1.6}
            fill={accent}
            initial={{ opacity: 0 }}
            animate={{
              cx: [c, n.x, c],
              cy: [c, n.y, c],
              opacity: [0, 1, 0],
            }}
            transition={{
              duration: 2.8,
              delay: 2 + i * 0.35,
              repeat: Infinity,
              repeatDelay: 1.2,
              ease: 'easeInOut',
            }}
            style={{ filter: 'drop-shadow(0 0 3px ' + accent + ')' }}
          />
        ))}

        {/* Center halo + node */}
        <circle cx={c} cy={c} r={18} fill="url(#aicCore)" />
        <motion.circle
          cx={c}
          cy={c}
          r={nodes[0].r}
          fill={accent}
          initial={{ scale: 0.6, opacity: 0 }}
          animate={{ scale: [1, 1.25, 1], opacity: 1 }}
          transition={{
            scale: { duration: 2.2, repeat: Infinity, ease: 'easeInOut' },
            opacity: { duration: 0.4, delay: 0.2 },
          }}
          style={{ transformOrigin: `${c}px ${c}px` }}
        />

        {/* Satellite nodes */}
        {nodes.slice(1).map((n, i) => (
          <g key={n.id}>
            <circle cx={n.x} cy={n.y} r={6} fill="url(#aicGlow)" />
            <motion.circle
              cx={n.x}
              cy={n.y}
              r={n.r}
              fill={nodeColor}
              initial={{ scale: 0 }}
              animate={{ scale: [1, 1.35, 1] }}
              transition={{
                duration: 2.4,
                delay: 1 + i * 0.15,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
              style={{ transformOrigin: `${n.x}px ${n.y}px` }}
            />
          </g>
        ))}
      </svg>
    </div>
  );
}
