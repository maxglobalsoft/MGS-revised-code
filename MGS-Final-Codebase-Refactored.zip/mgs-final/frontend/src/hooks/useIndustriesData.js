import { useEffect, useState } from 'react';
import api from '@/lib/api';

/**
 * Loads GET /api/page/industries. Falls back to nulls so the Industries
 * page can render its DEFAULT_* arrays when the API is unreachable.
 */
export function useIndustriesData() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    api
      .get('/page/industries')
      .then((res) => {
        if (cancelled) return;
        setData(res.data || null);
      })
      .catch(() => {
        if (cancelled) return;
        setData(null);
      })
      .finally(() => {
        if (cancelled) return;
        setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return { data, loading };
}
