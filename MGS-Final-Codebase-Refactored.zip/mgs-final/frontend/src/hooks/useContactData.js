import { useEffect, useState } from 'react';
import api from '@/lib/api';

/**
 * Fetches the Contact page payload:
 *   { meta, sections: { contactHeader, cta }, settings: { contact, socials } }
 * Falls back to null on error (Contact.jsx renders a sensible default header).
 */
export function useContactData() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    api
      .get('/page/contact')
      .then((res) => { if (!cancelled) setData(res.data || null); })
      .catch(() => { if (!cancelled) setData(null); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, []);

  return { data, loading };
}
