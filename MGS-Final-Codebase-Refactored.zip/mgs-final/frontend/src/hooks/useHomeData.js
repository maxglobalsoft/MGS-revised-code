import { useEffect, useState } from 'react';
import api from '@/lib/api';

/**
 * Loads GET /api/page/home — returns { meta, sections, collections }.
 * Returns nulls while loading or on error so each section component
 * can fall back to its own hardcoded defaults.
 */
export function useHomeData() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    api
      .get('/page/home')
      .then((res) => {
        if (cancelled) return;
        setData(res.data || null);
      })
      .catch(() => {
        if (cancelled) return;
        setData(null);
      })
      .finally(() => {
        if (cancelled) return;
        setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return { data, loading };
}
