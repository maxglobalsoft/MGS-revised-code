import { useEffect, useState } from 'react';
import api from '@/lib/api';

/**
 * Fetches a single static page by slug from /api/pages/{slug}.
 * Status flow:
 *   - loading: initial fetch in flight
 *   - notFound: API returned 404 (or unreachable + null payload)
 *   - data: the page document
 */
export function useStaticPage(slug) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    if (!slug) {
      setLoading(false);
      setNotFound(true);
      return;
    }
    let cancelled = false;
    setLoading(true);
    setNotFound(false);
    api
      .get(`/pages/${slug}`)
      .then((res) => { if (!cancelled) setData(res.data || null); })
      .catch((err) => {
        if (cancelled) return;
        setData(null);
        if (err?.response?.status === 404) setNotFound(true);
        else setNotFound(true);
      })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [slug]);

  return { data, loading, notFound };
}
