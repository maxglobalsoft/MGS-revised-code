import { useEffect, useState } from 'react';
import api from '@/lib/api';

/**
 * Loads GET /api/page/portfolio for the Portfolio (Our Work) page.
 * Falls back to null so the page can render DEFAULT_* arrays on error.
 */
export function usePortfolioData() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    api
      .get('/page/portfolio')
      .then((res) => { if (!cancelled) setData(res.data || null); })
      .catch(() => { if (!cancelled) setData(null); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, []);

  return { data, loading };
}
