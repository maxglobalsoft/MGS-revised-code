import { useEffect, useState } from 'react';
import api from '@/lib/api';

/**
 * Loads GET /api/page/career. Falls back gracefully on error.
 */
export function useCareerData() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api
      .get('/page/career')
      .then((res) => { if (!cancelled) setData(res.data || null); })
      .catch(() => { if (!cancelled) setData(null); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, []);

  return { data, loading };
}
