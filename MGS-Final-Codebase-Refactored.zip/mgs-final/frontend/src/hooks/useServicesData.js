import { useEffect, useState } from 'react';
import api from '@/lib/api';

/**
 * Loads GET /api/page/services. Returns nulls while loading or on error
 * so the Services page can fall back to its DEFAULT_* arrays.
 */
export function useServicesData() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    api
      .get('/page/services')
      .then((res) => {
        if (cancelled) return;
        setData(res.data || null);
      })
      .catch(() => {
        if (cancelled) return;
        setData(null);
      })
      .finally(() => {
        if (cancelled) return;
        setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return { data, loading };
}
