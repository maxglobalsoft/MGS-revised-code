import { useEffect, useState } from 'react';
import api from '@/lib/api';

/**
 * Loads GET /api/portfolio/{slug} for the Portfolio Detail page.
 * `notFound=true` when the API returns 404.
 */
export function usePortfolioDetail(slug) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    if (!slug) return undefined;
    let cancelled = false;
    setLoading(true);
    setNotFound(false);
    api
      .get(`/portfolio/${slug}`)
      .then((res) => { if (!cancelled) setData(res.data || null); })
      .catch((err) => {
        if (cancelled) return;
        if (err?.response?.status === 404) setNotFound(true);
        setData(null);
      })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [slug]);

  return { data, loading, notFound };
}
