import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';

/** Map URL pathname → pageMeta slug used in the DB */
function pathToSlug(pathname) {
  if (pathname === '/' || pathname === '') return 'home';
  // First path segment: /services → services, /case-studies/abc → case-studies
  return pathname.replace(/^\//, '').split('/')[0];
}

/**
 * Call once inside the marketing Layout.
 * On every route change, fetches /api/page/{slug} and updates:
 *   - document.title
 *   - <meta name="description">
 *   - <meta property="og:title|og:description|og:image|og:url"> + twitter equivalents
 * Fails silently — the page still works if the API is down.
 */
function setMeta({ selector, attr, name, content }) {
  if (!content) return;
  let el = document.querySelector(selector);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

export function usePageMeta() {
  const { pathname } = useLocation();

  useEffect(() => {
    // Detail routes own their own meta (set by their page component) — skip the
    // page-level fetch so a slow `/api/page/case-studies` response doesn't race-
    // overwrite the per-case-study title.
    if (/^\/case-studies\/[^/]+$/.test(pathname)) return;
    if (/^\/portfolio\/[^/]+$/.test(pathname)) return;
    // Admin-managed static text pages set their own meta from the `pages` doc.
    if (/^\/p\/[^/]+$/.test(pathname)) return;

    const slug = pathToSlug(pathname);
    axios
      .get(`${process.env.REACT_APP_BACKEND_URL}/api/page/${slug}`)
      .then(({ data }) => {
        const meta = data?.meta;
        if (!meta) return;

        if (meta.title) {
          document.title = meta.title;
        }

        setMeta({ selector: 'meta[name="description"]', attr: 'name', name: 'description', content: meta.description });

        // Open Graph
        setMeta({ selector: 'meta[property="og:title"]', attr: 'property', name: 'og:title', content: meta.title });
        setMeta({ selector: 'meta[property="og:description"]', attr: 'property', name: 'og:description', content: meta.description });
        setMeta({ selector: 'meta[property="og:type"]', attr: 'property', name: 'og:type', content: 'website' });
        setMeta({ selector: 'meta[property="og:url"]', attr: 'property', name: 'og:url', content: window.location.href });

        // Resolve og:image to absolute URL when seeded as a relative path
        const ogImage = meta.og_image || meta.ogImage;
        if (ogImage) {
          const absImage = /^https?:\/\//i.test(ogImage)
            ? ogImage
            : `${window.location.origin}${ogImage.startsWith('/') ? '' : '/'}${ogImage}`;
          setMeta({ selector: 'meta[property="og:image"]', attr: 'property', name: 'og:image', content: absImage });
          setMeta({ selector: 'meta[name="twitter:image"]', attr: 'name', name: 'twitter:image', content: absImage });
        }

        // Twitter cards
        setMeta({ selector: 'meta[name="twitter:card"]', attr: 'name', name: 'twitter:card', content: 'summary_large_image' });
        setMeta({ selector: 'meta[name="twitter:title"]', attr: 'name', name: 'twitter:title', content: meta.title });
        setMeta({ selector: 'meta[name="twitter:description"]', attr: 'name', name: 'twitter:description', content: meta.description });
      })
      .catch(() => {
        // Silently ignore — CMS unavailable should not break the page
      });
  }, [pathname]);
}
