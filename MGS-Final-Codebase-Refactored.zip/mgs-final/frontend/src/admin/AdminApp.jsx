import React, { useEffect } from 'react';
import { Routes, Route, Navigate, Outlet, useNavigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'sonner';
import { AuthProvider, useAuth } from './context/AuthContext';
import AdminLayout from './components/AdminLayout';

import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import ContactsInbox from './pages/ContactsInbox';
import ApplicationsInbox from './pages/ApplicationsInbox';
import SectionsEditor from './pages/SectionsEditor';
import CollectionsPage from './pages/CollectionsPage';
import CollectionEditor from './pages/CollectionEditor';
import MediaLibrary from './pages/MediaLibrary';
import SiteSettings from './pages/SiteSettings';
import UsersEditor from './pages/UsersEditor';

const adminQueryClient = new QueryClient({
  defaultOptions: { queries: { staleTime: 30_000, refetchOnWindowFocus: false } },
});

function ProtectedRoute() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !user) navigate('/admin/login', { replace: true });
  }, [user, loading, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#1F2D45] flex items-center justify-center">
        <div className="w-6 h-6 border-2 border-[#C9962E] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }
  if (!user) return null;
  return <Outlet />;
}

function SuperAdminRoute() {
  const { user, isSuperAdmin } = useAuth();
  if (!user) return null;
  if (!isSuperAdmin) return <Navigate to="/admin" replace />;
  return <Outlet />;
}

export default function AdminApp() {
  return (
    <QueryClientProvider client={adminQueryClient}>
      <AuthProvider>
        <Toaster position="top-right" richColors />
        <Routes>
          <Route path="login" element={<Login />} />
          <Route element={<ProtectedRoute />}>
            <Route element={<AdminLayout />}>
              <Route index element={<Dashboard />} />
              <Route path="sections" element={<SectionsEditor />} />
              <Route path="collections" element={<CollectionsPage />} />
              <Route path="collections/:name" element={<CollectionEditor />} />
              <Route path="media" element={<MediaLibrary />} />
              <Route element={<SuperAdminRoute />}>
                <Route path="contacts" element={<ContactsInbox />} />
                <Route path="applications" element={<ApplicationsInbox />} />
                <Route path="settings" element={<SiteSettings />} />
                <Route path="users" element={<UsersEditor />} />
              </Route>
            </Route>
          </Route>
          <Route path="*" element={<Navigate to="/admin" replace />} />
        </Routes>
      </AuthProvider>
    </QueryClientProvider>
  );
}
