import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Trash2, Mail, Phone, Globe, Loader2, RefreshCw } from 'lucide-react';
import api from '../api';

export default function ContactsInbox() {
  const qc = useQueryClient();
  const [deleting, setDeleting] = useState(null);

  const { data: contacts = [], isLoading } = useQuery({
    queryKey: ['admin-contacts'],
    queryFn: () => api.get('/admin/contact-submissions').then((r) => r.data),
  });

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this submission?')) return;
    setDeleting(id);
    try {
      await api.delete(`/admin/contact-submissions/${id}`);
      qc.invalidateQueries({ queryKey: ['admin-contacts'] });
      toast.success('Submission deleted');
    } catch {
      toast.error('Could not delete submission');
    } finally {
      setDeleting(null);
    }
  };

  return (
    <div className="space-y-6" data-testid="contacts-inbox">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#1F2D45]">Contact Inbox</h1>
          <p className="text-slate-500 text-sm mt-1">{contacts.length} submission{contacts.length !== 1 ? 's' : ''}</p>
        </div>
        <button
          onClick={() => qc.invalidateQueries({ queryKey: ['admin-contacts'] })}
          className="flex items-center gap-2 px-4 py-2 rounded-lg border border-slate-200 text-sm text-slate-600 hover:bg-slate-50 transition-colors"
        >
          <RefreshCw className="w-4 h-4" /> Refresh
        </button>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        {isLoading ? (
          <div className="flex justify-center py-16">
            <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
          </div>
        ) : contacts.length === 0 ? (
          <div className="text-center py-16">
            <Mail className="w-10 h-10 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-400">No contact submissions yet.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  {['Name', 'Email', 'Phone', 'Country', 'Brief', 'Date', ''].map((h) => (
                    <th key={h} className="text-left px-5 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wide">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {contacts.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50/50 transition-colors" data-testid={`contact-row-${c.id}`}>
                    <td className="px-5 py-4 font-medium text-slate-800">{c.name}</td>
                    <td className="px-5 py-4 text-slate-600">
                      <a href={`mailto:${c.email}`} className="hover:text-[#C9962E] flex items-center gap-1">
                        <Mail className="w-3.5 h-3.5" />{c.email}
                      </a>
                    </td>
                    <td className="px-5 py-4 text-slate-500">{c.phone || '—'}</td>
                    <td className="px-5 py-4 text-slate-500">{c.country || '—'}</td>
                    <td className="px-5 py-4 text-slate-500 max-w-xs truncate">{c.brief || '—'}</td>
                    <td className="px-5 py-4 text-slate-400 whitespace-nowrap">
                      {new Date(c.submitted_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                    </td>
                    <td className="px-5 py-4">
                      <button
                        onClick={() => handleDelete(c.id)}
                        disabled={deleting === c.id}
                        data-testid={`delete-contact-${c.id}`}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition-colors disabled:opacity-50"
                      >
                        {deleting === c.id
                          ? <Loader2 className="w-4 h-4 animate-spin" />
                          : <Trash2 className="w-4 h-4" />
                        }
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
