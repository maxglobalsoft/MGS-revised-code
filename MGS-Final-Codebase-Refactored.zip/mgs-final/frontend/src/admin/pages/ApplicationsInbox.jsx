import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Trash2, Mail, Loader2, RefreshCw, Briefcase, Paperclip, ChevronDown, ChevronUp } from 'lucide-react';
import api from '../api';

export default function ApplicationsInbox() {
  const qc = useQueryClient();
  const [deleting, setDeleting] = useState(null);
  const [expanded, setExpanded] = useState(null); // application id

  const { data: applications = [], isLoading } = useQuery({
    queryKey: ['admin-applications'],
    queryFn: () => api.get('/admin/applications').then((r) => r.data),
  });

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this application?')) return;
    setDeleting(id);
    try {
      await api.delete(`/admin/applications/${id}`);
      qc.invalidateQueries({ queryKey: ['admin-applications'] });
      toast.success('Application deleted');
    } catch {
      toast.error('Could not delete application');
    } finally {
      setDeleting(null);
    }
  };

  return (
    <div className="space-y-6" data-testid="applications-inbox">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#1F2D45]">Applications</h1>
          <p className="text-slate-500 text-sm mt-1">
            {applications.length} application{applications.length !== 1 ? 's' : ''}
          </p>
        </div>
        <button
          onClick={() => qc.invalidateQueries({ queryKey: ['admin-applications'] })}
          className="flex items-center gap-2 px-4 py-2 rounded-lg border border-slate-200 text-sm text-slate-600 hover:bg-slate-50 transition-colors"
        >
          <RefreshCw className="w-4 h-4" /> Refresh
        </button>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        {isLoading ? (
          <div className="flex justify-center py-16">
            <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
          </div>
        ) : applications.length === 0 ? (
          <div className="text-center py-16">
            <Briefcase className="w-10 h-10 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-400">No applications yet.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  {['Job', 'Name', 'Email', 'Mobile', 'Exp.', 'Resume', 'Date', ''].map((h) => (
                    <th key={h} className="text-left px-5 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wide">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {applications.map((a) => {
                  const isOpen = expanded === a.id;
                  return (
                    <React.Fragment key={a.id}>
                      <tr
                        className="hover:bg-slate-50/50 transition-colors cursor-pointer"
                        onClick={() => setExpanded(isOpen ? null : a.id)}
                        data-testid={`application-row-${a.id}`}
                      >
                        <td className="px-5 py-4 font-semibold text-slate-800 max-w-[200px] truncate">
                          <div className="flex items-center gap-2">
                            {isOpen ? <ChevronUp className="w-4 h-4 text-slate-400 shrink-0" /> : <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />}
                            <span className="truncate">{a.jobTitle || '—'}</span>
                          </div>
                        </td>
                        <td className="px-5 py-4 font-medium text-slate-800">{a.name}</td>
                        <td className="px-5 py-4 text-slate-600">
                          <a href={`mailto:${a.email}`} className="hover:text-[#C9962E] flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                            <Mail className="w-3.5 h-3.5" />{a.email}
                          </a>
                        </td>
                        <td className="px-5 py-4 text-slate-500">{a.mobile || '—'}</td>
                        <td className="px-5 py-4 text-slate-500">{a.experience || '—'}</td>
                        <td className="px-5 py-4">
                          {a.resumeUrl ? (
                            <a
                              href={a.resumeUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              onClick={(e) => e.stopPropagation()}
                              className="inline-flex items-center gap-1 text-[#C9962E] hover:underline"
                              data-testid={`application-resume-${a.id}`}
                            >
                              <Paperclip className="w-3.5 h-3.5" />
                              {a.resumeName || 'Resume'}
                            </a>
                          ) : (
                            <span className="text-slate-400">—</span>
                          )}
                        </td>
                        <td className="px-5 py-4 text-slate-400 whitespace-nowrap">
                          {new Date(a.createdAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                        </td>
                        <td className="px-5 py-4">
                          <button
                            onClick={(e) => { e.stopPropagation(); handleDelete(a.id); }}
                            disabled={deleting === a.id}
                            data-testid={`delete-application-${a.id}`}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition-colors disabled:opacity-50"
                          >
                            {deleting === a.id
                              ? <Loader2 className="w-4 h-4 animate-spin" />
                              : <Trash2 className="w-4 h-4" />
                            }
                          </button>
                        </td>
                      </tr>
                      {isOpen && (
                        <tr className="bg-slate-50">
                          <td colSpan={8} className="px-5 py-4">
                            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">
                              Message / Requirements
                            </div>
                            <p className="text-sm text-slate-700 whitespace-pre-line leading-relaxed">
                              {a.message || '—'}
                            </p>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
