import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../api';
import { Mail, Layers, Database, Image, Users, ArrowRight, Loader2 } from 'lucide-react';

function StatCard({ icon: Icon, label, value, to, color }) {
  return (
    <Link
      to={to}
      data-testid={`stat-card-${label.toLowerCase().replace(/\s/g, '-')}`}
      className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 flex items-center gap-5 hover:shadow-md transition-shadow group"
    >
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${color}`}>
        <Icon className="w-6 h-6 text-white" />
      </div>
      <div className="flex-1">
        <p className="text-sm text-slate-500">{label}</p>
        <p className="text-2xl font-bold text-[#1F2D45] mt-0.5">
          {value ?? <Loader2 className="w-5 h-5 animate-spin text-slate-400 inline" />}
        </p>
      </div>
      <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-[#C9962E] transition-colors" />
    </Link>
  );
}

export default function Dashboard() {
  const { user, isSuperAdmin } = useAuth();

  const { data: contacts = [] } = useQuery({
    queryKey: ['admin-contacts'],
    queryFn: () => api.get('/admin/contact-submissions').then((r) => r.data),
    enabled: isSuperAdmin,
  });
  const { data: sections = [] } = useQuery({
    queryKey: ['admin-sections'],
    queryFn: () => api.get('/admin/sections').then((r) => r.data),
  });
  const { data: media = [] } = useQuery({
    queryKey: ['admin-media'],
    queryFn: () => api.get('/admin/media').then((r) => r.data),
  });
  const { data: services = [] } = useQuery({
    queryKey: ['admin-col-services'],
    queryFn: () => api.get('/admin/services').then((r) => r.data),
  });

  return (
    <div className="space-y-8" data-testid="admin-dashboard">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-[#1F2D45]">
          Good to see you, {user?.name || 'Admin'}
        </h1>
        <p className="text-slate-500 text-sm mt-1">Manage your MGS website content from here.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {isSuperAdmin && (
          <StatCard icon={Mail} label="Contact Leads" value={contacts.length} to="/admin/contacts" color="bg-blue-500" />
        )}
        <StatCard icon={Layers} label="Sections" value={sections.length} to="/admin/sections" color="bg-[#1F2D45]" />
        <StatCard icon={Database} label="Services" value={services.length} to="/admin/collections" color="bg-amber-500" />
        <StatCard icon={Image} label="Media Files" value={media.length} to="/admin/media" color="bg-emerald-500" />
      </div>

      {/* Recent Contacts */}
      {isSuperAdmin && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <h2 className="font-semibold text-[#1F2D45]">Recent Contact Submissions</h2>
          <Link to="/admin/contacts" className="text-sm text-[#C9962E] hover:underline font-medium">
            View all
          </Link>
        </div>
        {contacts.length === 0 ? (
          <p className="text-slate-400 text-sm text-center py-10">No submissions yet.</p>
        ) : (
          <div className="divide-y divide-slate-100">
            {contacts.slice(0, 5).map((c) => (
              <div key={c.id} className="px-6 py-4 flex items-start justify-between gap-4">
                <div>
                  <p className="text-sm font-medium text-slate-800">{c.name}</p>
                  <p className="text-xs text-slate-400">{c.email}</p>
                  {c.brief && (
                    <p className="text-xs text-slate-500 mt-1 max-w-md truncate">{c.brief}</p>
                  )}
                </div>
                <span className="text-xs text-slate-400 whitespace-nowrap shrink-0">
                  {new Date(c.submitted_at).toLocaleDateString()}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
      )}
    </div>
  );
}
