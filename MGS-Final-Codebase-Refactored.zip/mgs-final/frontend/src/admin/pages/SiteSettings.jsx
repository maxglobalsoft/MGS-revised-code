import React, { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Save, Loader2, Plus, Trash2 } from 'lucide-react';
import api from '../api';

function FieldRow({ label, value, onChange, type = 'text', mono = false }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1.5">{label}</label>
      {type === 'textarea' ? (
        <textarea value={value} onChange={(e) => onChange(e.target.value)} rows={2}
          className={`w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#C9962E]/40 resize-none ${mono ? 'font-mono' : ''}`} />
      ) : (
        <input type="text" value={value} onChange={(e) => onChange(e.target.value)}
          className={`w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#C9962E]/40 ${mono ? 'font-mono' : ''}`} />
      )}
    </div>
  );
}

function ListField({ label, items, onChange }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1.5">{label}</label>
      <div className="space-y-2">
        {items.map((item, i) => (
          <div key={i} className="flex gap-2">
            <input value={item} onChange={(e) => { const arr = [...items]; arr[i] = e.target.value; onChange(arr); }}
              className="flex-1 px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#C9962E]/40" />
            <button onClick={() => onChange(items.filter((_, j) => j !== i))} className="p-2 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition-colors">
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        ))}
        <button onClick={() => onChange([...items, ''])} className="flex items-center gap-1.5 text-xs text-[#C9962E] hover:underline">
          <Plus className="w-3.5 h-3.5" /> Add
        </button>
      </div>
    </div>
  );
}

export default function SiteSettings() {
  const qc = useQueryClient();
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState(null);

  const { data: settings, isLoading } = useQuery({
    queryKey: ['admin-settings'],
    queryFn: () => api.get('/admin/settings').then((r) => r.data),
  });

  const initialized = React.useRef(false);
  useEffect(() => {
    if (settings && !initialized.current) {
      initialized.current = true;
      setForm(settings);
    }
  }, [settings]);

  const set = (path, val) => {
    setForm((prev) => {
      const next = { ...prev };
      const keys = path.split('.');
      let cur = next;
      for (let i = 0; i < keys.length - 1; i++) {
        cur[keys[i]] = { ...cur[keys[i]] };
        cur = cur[keys[i]];
      }
      cur[keys[keys.length - 1]] = val;
      return next;
    });
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const payload = {
        logo_url: form.logo_url,
        contact: form.contact,
        socials: form.socials,
        nav_links: form.nav_links,
        footer_columns: form.footer_columns,
        copyright: form.copyright,
      };
      await api.put('/admin/settings', payload);
      qc.invalidateQueries({ queryKey: ['admin-settings'] });
      toast.success('Settings saved');
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Failed to save');
    } finally {
      setSaving(false);
    }
  };

  if (isLoading || !form) return <div className="flex justify-center py-20"><Loader2 className="w-6 h-6 animate-spin text-slate-400" /></div>;

  return (
    <div className="space-y-8 max-w-2xl" data-testid="site-settings">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#1F2D45]">Site Settings</h1>
          <p className="text-slate-500 text-sm mt-1">Manage global site contact info and branding.</p>
        </div>
        <button onClick={handleSave} disabled={saving} data-testid="save-settings-btn"
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#1F2D45] text-white text-sm font-semibold hover:bg-[#2a3d5e] disabled:opacity-60 transition-colors">
          {saving && <Loader2 className="w-4 h-4 animate-spin" />}
          <Save className="w-4 h-4" /> Save Changes
        </button>
      </div>

      <Section title="Branding">
        <FieldRow label="Logo URL" value={form.logo_url || ''} onChange={(v) => set('logo_url', v)} mono />
        <FieldRow label="Copyright" value={form.copyright || ''} onChange={(v) => set('copyright', v)} />
      </Section>

      <Section title="Contact">
        <ListField label="Address (legacy — used only when no Offices defined below)" items={form.contact?.address || []} onChange={(v) => set('contact.address', v)} />
        <ListField label="Phone (shared)" items={form.contact?.phone || []} onChange={(v) => set('contact.phone', v)} />
        <ListField label="Email (shared)" items={form.contact?.email || []} onChange={(v) => set('contact.email', v)} />
        <FieldRow label="Website" value={form.contact?.website || ''} onChange={(v) => set('contact.website', v)} mono />
      </Section>

      <Section title="Offices (Branch Locations)">
        <p className="text-[12px] text-slate-500 -mt-1">
          Each office gets its own card + map on the Contact page. Add as many as you need.
        </p>
        <OfficesEditor value={form.contact?.offices || []} onChange={(v) => set('contact.offices', v)} />
      </Section>

      <Section title="Navigation Menu (Top Nav)">
        <p className="text-[12px] text-slate-500 -mt-1">
          JSON array. Each item: <code className="bg-slate-100 px-1.5 py-0.5 rounded">{`{label, to?}`}</code>.
          Parent menu with submenu: <code className="bg-slate-100 px-1.5 py-0.5 rounded">{`{label, children: [{label, to}, ...]}`}</code>.
        </p>
        <NavLinksEditor value={form.nav_links || []} onChange={(v) => set('nav_links', v)} />
      </Section>
    </div>
  );
}

function NavLinksEditor({ value, onChange }) {
  const [text, setText] = React.useState(() => JSON.stringify(value, null, 2));
  const [err, setErr] = React.useState(null);

  React.useEffect(() => {
    setText(JSON.stringify(value, null, 2));
  }, [value]);

  const onBlur = () => {
    try {
      const parsed = JSON.parse(text);
      if (!Array.isArray(parsed)) throw new Error('Must be a JSON array');
      setErr(null);
      onChange(parsed);
    } catch (e) {
      setErr(e.message);
    }
  };

  return (
    <div className="space-y-2">
      <textarea
        data-testid="nav-links-editor"
        value={text}
        onChange={(e) => setText(e.target.value)}
        onBlur={onBlur}
        spellCheck={false}
        className="w-full min-h-[260px] font-mono text-[12px] leading-relaxed bg-slate-50 border border-slate-200 rounded-lg px-3 py-2.5 text-slate-800 focus:outline-none focus:ring-2 focus:ring-brandblue/40"
      />
      {err && <p className="text-[12px] text-rose-600">Invalid JSON: {err}</p>}
    </div>
  );
}

function OfficesEditor({ value, onChange }) {
  const offices = Array.isArray(value) ? value : [];

  const update = (idx, key, v) => {
    const next = offices.map((o, i) => (i === idx ? { ...o, [key]: v } : o));
    onChange(next);
  };

  const remove = (idx) => {
    if (!window.confirm('Remove this office?')) return;
    onChange(offices.filter((_, i) => i !== idx));
  };

  const add = () => {
    onChange([
      ...offices,
      { label: 'New Office', address: '', contactPerson: '', designation: '', phone: '' },
    ]);
  };

  return (
    <div className="space-y-4" data-testid="offices-editor">
      {offices.length === 0 && (
        <p className="text-[12px] text-slate-500 italic">No offices yet. Click + Add Office below to create one.</p>
      )}
      {offices.map((o, i) => (
        <div
          key={i}
          className="rounded-lg border border-slate-200 bg-slate-50/60 p-4 space-y-3"
          data-testid={`office-row-${i}`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Office #{i + 1}
            </span>
            <button
              type="button"
              onClick={() => remove(i)}
              className="p-1.5 rounded-md text-slate-400 hover:text-red-500 hover:bg-red-50 transition-colors"
              data-testid={`office-remove-${i}`}
              aria-label="Remove office"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>

          <FieldRow
            label="Label (e.g. Head Office — Bengaluru)"
            value={o.label || ''}
            onChange={(v) => update(i, 'label', v)}
          />
          <FieldRow
            label="Address"
            type="textarea"
            value={o.address || ''}
            onChange={(v) => update(i, 'address', v)}
          />
          <div className="grid sm:grid-cols-2 gap-3">
            <FieldRow
              label="Contact Person"
              value={o.contactPerson || ''}
              onChange={(v) => update(i, 'contactPerson', v)}
            />
            <FieldRow
              label="Designation"
              value={o.designation || ''}
              onChange={(v) => update(i, 'designation', v)}
            />
          </div>
          <FieldRow
            label="Phone"
            value={o.phone || ''}
            onChange={(v) => update(i, 'phone', v)}
          />
        </div>
      ))}
      <button
        type="button"
        onClick={add}
        className="flex items-center gap-1.5 text-xs text-[#C9962E] hover:underline"
        data-testid="office-add-btn"
      >
        <Plus className="w-3.5 h-3.5" /> Add Office
      </button>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-5">
      <h2 className="font-semibold text-slate-800 text-sm border-b border-slate-100 pb-3">{title}</h2>
      {children}
    </div>
  );
}
