import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Plus, Edit2, Trash2, ChevronLeft, Loader2, X, Save, Eye, EyeOff } from 'lucide-react';
import { COLLECTION_LABELS, COLLECTION_SCHEMAS } from '../collectionSchemas';
import api from '../api';

function ItemForm({ schema, initial, onSave, onClose, saving }) {
  const [form, setForm] = useState(() => {
    const base = {};
    schema.forEach((f) => {
      const raw = initial?.[f.key];
      if (f.type === 'json') {
        // Pretty-print arrays/objects for editing; keep strings as-is.
        base[f.key] = raw == null ? '' : (typeof raw === 'string' ? raw : JSON.stringify(raw, null, 2));
      } else {
        base[f.key] = raw ?? (f.type === 'toggle' ? true : f.type === 'number' ? '' : '');
      }
    });
    return base;
  });
  const [jsonErrors, setJsonErrors] = useState({});

  const set = (key, val) => setForm((p) => ({ ...p, [key]: val }));

  const handleSave = () => {
    // Parse json fields before save
    const errors = {};
    const out = { ...form };
    schema.forEach((f) => {
      if (f.type !== 'json') return;
      const v = (out[f.key] ?? '').trim();
      if (!v) {
        out[f.key] = null;
        return;
      }
      try {
        out[f.key] = JSON.parse(v);
      } catch (e) {
        errors[f.key] = e.message;
      }
    });
    if (Object.keys(errors).length) {
      setJsonErrors(errors);
      return;
    }
    setJsonErrors({});
    onSave(out);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
          <h2 className="font-bold text-[#1F2D45]">{initial ? 'Edit Item' : 'Add Item'}</h2>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-slate-100 text-slate-500">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {schema.map((field) => (
            <div key={field.key}>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                {field.label}{field.required && <span className="text-red-500 ml-0.5">*</span>}
              </label>
              {field.type === 'toggle' ? (
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => set(field.key, !form[field.key])}
                    data-testid={`field-toggle-${field.key}`}
                    className={`relative w-10 h-6 rounded-full transition-colors ${form[field.key] ? 'bg-emerald-500' : 'bg-slate-300'}`}
                  >
                    <span className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-transform ${form[field.key] ? 'translate-x-5' : 'translate-x-1'}`} />
                  </button>
                  <span className="text-sm text-slate-600">{form[field.key] ? 'Visible' : 'Hidden'}</span>
                </div>
              ) : field.type === 'textarea' ? (
                <textarea
                  value={form[field.key]}
                  onChange={(e) => set(field.key, e.target.value)}
                  rows={field.rows || 3}
                  data-testid={`field-${field.key}`}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#C9962E]/40 resize-y"
                />
              ) : field.type === 'json' ? (
                <>
                  <textarea
                    value={form[field.key]}
                    onChange={(e) => set(field.key, e.target.value)}
                    rows={6}
                    data-testid={`field-${field.key}`}
                    placeholder='e.g. [{"title": "...", "desc": "..."}]'
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-[#C9962E]/40 resize-y"
                  />
                  {jsonErrors[field.key] && (
                    <p className="mt-1 text-[11px] text-red-600">JSON error: {jsonErrors[field.key]}</p>
                  )}
                </>
              ) : (
                <input
                  type={field.type === 'number' ? 'number' : 'text'}
                  value={form[field.key]}
                  onChange={(e) => set(field.key, field.type === 'number' ? Number(e.target.value) : e.target.value)}
                  data-testid={`field-${field.key}`}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#C9962E]/40"
                />
              )}
              {field.type === 'url' && form[field.key] && (
                <img src={form[field.key]} alt="" className="mt-2 h-12 w-12 rounded object-cover border border-slate-200" onError={(e) => e.target.style.display = 'none'} />
              )}
            </div>
          ))}
        </div>
        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-slate-100">
          <button onClick={onClose} className="px-4 py-2 rounded-lg border border-slate-300 text-sm text-slate-600 hover:bg-slate-50">Cancel</button>
          <button
            onClick={handleSave}
            disabled={saving}
            data-testid="save-item-btn"
            className="flex items-center gap-2 px-5 py-2 rounded-lg bg-[#1F2D45] text-white text-sm font-semibold hover:bg-[#2a3d5e] disabled:opacity-60"
          >
            {saving && <Loader2 className="w-4 h-4 animate-spin" />}
            <Save className="w-4 h-4" /> {initial ? 'Update' : 'Add'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function CollectionEditor() {
  const { name } = useParams();
  const qc = useQueryClient();
  const label = COLLECTION_LABELS[name] || name;
  const schema = COLLECTION_SCHEMAS[name] || [];

  const [modal, setModal] = useState(null); // null | { mode: 'add'|'edit', item? }
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(null);

  const { data: items = [], isLoading } = useQuery({
    queryKey: ['admin-col', name],
    queryFn: () => api.get(`/admin/${name}`).then((r) => r.data),
  });

  const handleSave = async (form) => {
    setSaving(true);
    try {
      if (modal.mode === 'edit') {
        await api.put(`/admin/${name}/${modal.item.id}`, form);
        toast.success('Item updated');
      } else {
        await api.post(`/admin/${name}`, form);
        toast.success('Item added');
      }
      qc.invalidateQueries({ queryKey: ['admin-col', name] });
      setModal(null);
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Failed to save');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this item?')) return;
    setDeleting(id);
    try {
      await api.delete(`/admin/${name}/${id}`);
      qc.invalidateQueries({ queryKey: ['admin-col', name] });
      toast.success('Item deleted');
    } catch {
      toast.error('Could not delete item');
    } finally {
      setDeleting(null);
    }
  };

  const handleToggle = async (item) => {
    try {
      await api.put(`/admin/${name}/${item.id}`, { visible: !item.visible });
      qc.invalidateQueries({ queryKey: ['admin-col', name] });
    } catch { toast.error('Could not update visibility'); }
  };

  // Display keys: first 3 non-system fields
  const displayKeys = schema.filter((f) => !['visible', 'order'].includes(f.key)).slice(0, 3).map((f) => f.key);

  return (
    <div className="space-y-6" data-testid={`collection-editor-${name}`}>
      <div className="flex items-center justify-between">
        <div>
          <Link to="/admin/collections" className="flex items-center gap-1 text-sm text-slate-400 hover:text-slate-600 mb-2">
            <ChevronLeft className="w-4 h-4" /> Collections
          </Link>
          <h1 className="text-2xl font-bold text-[#1F2D45]">{label}</h1>
          <p className="text-slate-500 text-sm mt-1">{items.length} item{items.length !== 1 ? 's' : ''}</p>
        </div>
        <button
          onClick={() => setModal({ mode: 'add' })}
          data-testid="add-item-btn"
          className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#1F2D45] text-white text-sm font-semibold hover:bg-[#2a3d5e] transition-colors"
        >
          <Plus className="w-4 h-4" /> Add Item
        </button>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        {isLoading ? (
          <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-slate-400" /></div>
        ) : items.length === 0 ? (
          <div className="text-center py-16 text-slate-400 text-sm">No items yet. Add your first one.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="text-left px-5 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wide">#</th>
                  {displayKeys.map((k) => (
                    <th key={k} className="text-left px-5 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wide capitalize">{k}</th>
                  ))}
                  <th className="text-left px-5 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wide">Visible</th>
                  <th className="px-5 py-3.5"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {items.map((item, idx) => (
                  <tr key={item.id} className="hover:bg-slate-50/50" data-testid={`item-row-${item.id}`}>
                    <td className="px-5 py-4 text-slate-400 text-xs">{idx + 1}</td>
                    {displayKeys.map((k) => (
                      <td key={k} className="px-5 py-4 text-slate-700 max-w-xs truncate">
                        {k.includes('img') || k.includes('photo') || k.includes('avatar') || k.includes('url')
                          ? item[k] ? <img src={item[k]} alt="" className="h-8 w-8 rounded object-cover" onError={(e) => e.target.style.display = 'none'} /> : '—'
                          : String(item[k] ?? '—')}
                      </td>
                    ))}
                    <td className="px-5 py-4">
                      <button onClick={() => handleToggle(item)} data-testid={`toggle-item-${item.id}`} className="p-1 rounded transition-colors">
                        {item.visible
                          ? <Eye className="w-4 h-4 text-emerald-500" />
                          : <EyeOff className="w-4 h-4 text-slate-400" />}
                      </button>
                    </td>
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-1.5 justify-end">
                        <button onClick={() => setModal({ mode: 'edit', item })} data-testid={`edit-item-${item.id}`} className="p-1.5 rounded-lg text-slate-400 hover:text-[#1F2D45] hover:bg-slate-100 transition-colors">
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button onClick={() => handleDelete(item.id)} disabled={deleting === item.id} data-testid={`delete-item-${item.id}`} className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition-colors disabled:opacity-50">
                          {deleting === item.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {modal && (
        <ItemForm
          schema={schema}
          initial={modal.item}
          onSave={handleSave}
          onClose={() => setModal(null)}
          saving={saving}
        />
      )}
    </div>
  );
}
