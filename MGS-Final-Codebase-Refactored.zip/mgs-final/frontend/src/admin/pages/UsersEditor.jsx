import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Plus, Edit2, Trash2, X, Save, Loader2, Users as UsersIcon } from 'lucide-react';
import api from '../api';
import { useAuth } from '../context/AuthContext';

function UserModal({ initial, onSave, onClose, saving }) {
  const [form, setForm] = useState({
    name: initial?.name || '',
    email: initial?.email || '',
    password: '',
    role: initial?.role || 'editor',
  });
  const set = (k, v) => setForm((p) => ({ ...p, [k]: v }));
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
          <h2 className="font-bold text-[#1F2D45]">{initial ? 'Edit User' : 'New User'}</h2>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-slate-100 text-slate-500"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-6 space-y-4">
          {[
            { key: 'name', label: 'Full Name', type: 'text', placeholder: 'John Smith' },
            { key: 'email', label: 'Email', type: 'email', placeholder: 'john@maxglobalsoft.com' },
            { key: 'password', label: initial ? 'New Password (leave blank to keep)' : 'Password', type: 'password', placeholder: '••••••••' },
          ].map(({ key, label, type, placeholder }) => (
            <div key={key}>
              <label className="block text-xs font-semibold text-slate-500 mb-1.5">{label}</label>
              <input type={type} value={form[key]} onChange={(e) => set(key, e.target.value)}
                placeholder={placeholder} data-testid={`user-field-${key}`}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#C9962E]/40" />
            </div>
          ))}
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-1.5">Role</label>
            <select value={form.role} onChange={(e) => set('role', e.target.value)} data-testid="user-field-role"
              className="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#C9962E]/40 bg-white">
              <option value="editor">Editor</option>
              <option value="super_admin">Super Admin</option>
            </select>
          </div>
        </div>
        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-slate-100">
          <button onClick={onClose} className="px-4 py-2 rounded-lg border border-slate-300 text-sm text-slate-600 hover:bg-slate-50">Cancel</button>
          <button onClick={() => onSave(form)} disabled={saving} data-testid="save-user-btn"
            className="flex items-center gap-2 px-5 py-2 rounded-lg bg-[#1F2D45] text-white text-sm font-semibold hover:bg-[#2a3d5e] disabled:opacity-60">
            {saving && <Loader2 className="w-4 h-4 animate-spin" />}
            <Save className="w-4 h-4" /> {initial ? 'Update' : 'Create'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function UsersEditor() {
  const qc = useQueryClient();
  const { user: me } = useAuth();
  const [modal, setModal] = useState(null);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(null);

  const { data: users = [], isLoading } = useQuery({
    queryKey: ['admin-users'],
    queryFn: () => api.get('/admin/users').then((r) => r.data),
  });

  const handleSave = async (form) => {
    setSaving(true);
    try {
      const payload = { ...form };
      if (!payload.password) delete payload.password;
      if (modal.user) {
        await api.put(`/admin/users/${modal.user.id}`, payload);
        toast.success('User updated');
      } else {
        await api.post('/admin/users', payload);
        toast.success('User created');
      }
      qc.invalidateQueries({ queryKey: ['admin-users'] });
      setModal(null);
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Failed to save user');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    if (id === me?.id) { toast.error("You can't delete your own account"); return; }
    if (!window.confirm('Delete this user?')) return;
    setDeleting(id);
    try {
      await api.delete(`/admin/users/${id}`);
      qc.invalidateQueries({ queryKey: ['admin-users'] });
      toast.success('User deleted');
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Could not delete user');
    } finally {
      setDeleting(null);
    }
  };

  return (
    <div className="space-y-6" data-testid="users-editor">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#1F2D45]">Users</h1>
          <p className="text-slate-500 text-sm mt-1">{users.length} user{users.length !== 1 ? 's' : ''}</p>
        </div>
        <button onClick={() => setModal({ user: null })} data-testid="add-user-btn"
          className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#1F2D45] text-white text-sm font-semibold hover:bg-[#2a3d5e] transition-colors">
          <Plus className="w-4 h-4" /> Add User
        </button>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        {isLoading ? (
          <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-slate-400" /></div>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                {['Name', 'Email', 'Role', 'Created', ''].map((h) => (
                  <th key={h} className="text-left px-5 py-3.5 text-xs font-semibold text-slate-500 uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {users.map((u) => (
                <tr key={u.id} className="hover:bg-slate-50/50" data-testid={`user-row-${u.id}`}>
                  <td className="px-5 py-4 font-medium text-slate-800">{u.name}</td>
                  <td className="px-5 py-4 text-slate-600">{u.email}</td>
                  <td className="px-5 py-4">
                    <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${u.role === 'super_admin' ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-600'}`}>
                      {u.role === 'super_admin' ? 'Super Admin' : 'Editor'}
                    </span>
                  </td>
                  <td className="px-5 py-4 text-slate-400 text-xs">
                    {u.created_at ? new Date(u.created_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '—'}
                  </td>
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-1.5 justify-end">
                      <button onClick={() => setModal({ user: u })} data-testid={`edit-user-${u.id}`} className="p-1.5 rounded-lg text-slate-400 hover:text-[#1F2D45] hover:bg-slate-100 transition-colors">
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button onClick={() => handleDelete(u.id)} disabled={deleting === u.id || u.id === me?.id} data-testid={`delete-user-${u.id}`}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-red-500 hover:bg-red-50 transition-colors disabled:opacity-30">
                        {deleting === u.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {modal && <UserModal initial={modal.user} onSave={handleSave} onClose={() => setModal(null)} saving={saving} />}
    </div>
  );
}
