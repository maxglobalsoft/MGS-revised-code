import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Edit2, Eye, EyeOff, Save, Loader2, X } from 'lucide-react';
import api from '../api';

const SECTION_LABELS = {
  hero: 'Hero Banner',
  achievements: 'Achievements',
  servicesIntro: 'Services Introduction',
  industriesIntro: 'Industries Introduction',
  portfolioIntro: 'Portfolio Introduction',
  caseStudyIntro: 'Case Study Introduction',
  technologiesIntro: 'Technologies Introduction',
  testimonialsIntro: 'Testimonials Introduction',
  clientsIntro: 'Clients Introduction',
  values: 'Our Values',
  cta: 'CTA Band',
  // Services page sections
  servicesHeader: 'Services Page · Header',
  servicesIndustriesIntro: 'Services Page · Industries Intro',
  recentProjectsIntro: 'Services Page · Recent Projects Intro',
  // Industries page sections
  industriesHeader: 'Industries Page · Header',
  // Case Studies page sections
  caseStudiesHeader: 'Case Studies Page · Header',
  // Why MGS page sections
  whyMgsHeader: 'Why MGS · Header',
  whyMgsStats: 'Why MGS · Stats Strip',
  // Portfolio page sections
  portfolioHeader: 'Portfolio Page · Header',
  // Our Team page sections
  teamHeader: 'Our Team · Header',
  // Reviews page sections
  reviewsHeader: 'Reviews Page · Header',
  // Career page sections
  careerHeader: 'Career Page · Header',
  careerNote: 'Career Page · Side Note + CTA',
  // Contact page sections
  contactHeader: 'Contact Page · Header',
};

function SectionCard({ section, onEdit, onToggleVisible }) {
  const [toggling, setToggling] = useState(false);
  const handleToggle = async () => {
    setToggling(true);
    await onToggleVisible(section);
    setToggling(false);
  };
  return (
    <div
      className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 flex items-center justify-between gap-4"
      data-testid={`section-card-${section.key}`}
    >
      <div>
        <p className="font-semibold text-slate-800 text-sm">{SECTION_LABELS[section.key] || section.key}</p>
        <p className="text-xs text-slate-400 mt-0.5 font-mono">{section.key}</p>
      </div>
      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={handleToggle}
          disabled={toggling}
          data-testid={`toggle-section-${section.key}`}
          title={section.visible ? 'Hide section' : 'Show section'}
          className={`p-2 rounded-lg transition-colors ${
            section.visible
              ? 'text-emerald-600 bg-emerald-50 hover:bg-emerald-100'
              : 'text-slate-400 bg-slate-100 hover:bg-slate-200'
          }`}
        >
          {toggling ? <Loader2 className="w-4 h-4 animate-spin" /> : section.visible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
        </button>
        <button
          onClick={() => onEdit(section)}
          data-testid={`edit-section-${section.key}`}
          className="p-2 rounded-lg text-[#1F2D45] bg-slate-100 hover:bg-slate-200 transition-colors"
        >
          <Edit2 className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

export default function SectionsEditor() {
  const qc = useQueryClient();
  const [editing, setEditing] = useState(null);
  const [jsonText, setJsonText] = useState('');
  const [jsonError, setJsonError] = useState('');
  const [saving, setSaving] = useState(false);

  const { data: sections = [], isLoading } = useQuery({
    queryKey: ['admin-sections'],
    queryFn: () => api.get('/admin/sections').then((r) => r.data),
  });

  const handleEdit = (section) => {
    setEditing(section);
    setJsonText(JSON.stringify(section.data, null, 2));
    setJsonError('');
  };

  const handleJsonChange = (val) => {
    setJsonText(val);
    try { JSON.parse(val); setJsonError(''); }
    catch { setJsonError('Invalid JSON'); }
  };

  const handleSave = async () => {
    try {
      const parsed = JSON.parse(jsonText);
      setSaving(true);
      await api.put(`/admin/sections/${editing.key}`, { data: parsed });
      qc.invalidateQueries({ queryKey: ['admin-sections'] });
      toast.success(`"${SECTION_LABELS[editing.key] || editing.key}" updated`);
      setEditing(null);
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Failed to save');
    } finally {
      setSaving(false);
    }
  };

  const handleToggleVisible = async (section) => {
    try {
      await api.put(`/admin/sections/${section.key}`, { visible: !section.visible });
      qc.invalidateQueries({ queryKey: ['admin-sections'] });
      toast.success(`Section ${section.visible ? 'hidden' : 'shown'}`);
    } catch {
      toast.error('Could not update visibility');
    }
  };

  if (isLoading) return <div className="flex justify-center py-20"><Loader2 className="w-6 h-6 animate-spin text-slate-400" /></div>;

  return (
    <div className="space-y-6" data-testid="sections-editor">
      <div>
        <h1 className="text-2xl font-bold text-[#1F2D45]">Sections</h1>
        <p className="text-slate-500 text-sm mt-1">Toggle visibility and edit each page section's content.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {sections.map((s) => (
          <SectionCard key={s.key} section={s} onEdit={handleEdit} onToggleVisible={handleToggleVisible} />
        ))}
      </div>

      {/* Edit modal */}
      {editing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
              <div>
                <h2 className="font-bold text-[#1F2D45]">Edit: {SECTION_LABELS[editing.key] || editing.key}</h2>
                <p className="text-xs text-slate-400 font-mono mt-0.5">{editing.key}</p>
              </div>
              <button onClick={() => setEditing(null)} className="p-2 rounded-lg hover:bg-slate-100 text-slate-500">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-auto p-6">
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">
                Section Data (JSON)
              </label>
              <textarea
                data-testid="section-json-editor"
                value={jsonText}
                onChange={(e) => handleJsonChange(e.target.value)}
                className={`w-full h-80 font-mono text-sm rounded-lg border p-4 focus:outline-none focus:ring-2 resize-none ${
                  jsonError ? 'border-red-400 focus:ring-red-300' : 'border-slate-300 focus:ring-[#C9962E]/40'
                }`}
              />
              {jsonError && <p className="text-red-500 text-xs mt-1">{jsonError}</p>}
            </div>
            <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-slate-100">
              <button onClick={() => setEditing(null)} className="px-4 py-2 rounded-lg border border-slate-300 text-sm text-slate-600 hover:bg-slate-50">
                Cancel
              </button>
              <button
                onClick={handleSave}
                disabled={saving || !!jsonError}
                data-testid="save-section-btn"
                className="flex items-center gap-2 px-5 py-2 rounded-lg bg-[#1F2D45] text-white text-sm font-semibold hover:bg-[#2a3d5e] disabled:opacity-60 transition-colors"
              >
                {saving && <Loader2 className="w-4 h-4 animate-spin" />}
                <Save className="w-4 h-4" /> Save
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
