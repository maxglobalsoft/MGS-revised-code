import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { COLLECTION_LABELS } from '../collectionSchemas';
import api from '../api';
import { ArrowRight, Database, Loader2 } from 'lucide-react';

const BG_COLORS = [
  'bg-blue-500', 'bg-amber-500', 'bg-emerald-500', 'bg-purple-500',
  'bg-rose-500', 'bg-cyan-500', 'bg-indigo-500', 'bg-teal-500',
  'bg-orange-500', 'bg-pink-500', 'bg-lime-500', 'bg-sky-500',
];

function CollectionCard({ name, label, index }) {
  const { data = [], isLoading } = useQuery({
    queryKey: ['admin-col', name],
    queryFn: () => api.get(`/admin/${name}`).then((r) => r.data),
  });
  return (
    <Link
      to={`/admin/collections/${name}`}
      data-testid={`collection-card-${name}`}
      className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 flex items-center gap-4 hover:shadow-md transition-shadow group"
    >
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${BG_COLORS[index % BG_COLORS.length]}`}>
        <Database className="w-5 h-5 text-white" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-semibold text-slate-800 text-sm truncate">{label}</p>
        <p className="text-xs text-slate-400 mt-0.5">
          {isLoading ? '—' : `${data.length} item${data.length !== 1 ? 's' : ''}`}
        </p>
      </div>
      <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-[#C9962E] transition-colors shrink-0" />
    </Link>
  );
}

export default function CollectionsPage() {
  const collections = Object.entries(COLLECTION_LABELS);
  return (
    <div className="space-y-6" data-testid="collections-page">
      <div>
        <h1 className="text-2xl font-bold text-[#1F2D45]">Collections</h1>
        <p className="text-slate-500 text-sm mt-1">Manage list-based content items.</p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {collections.map(([name, label], i) => (
          <CollectionCard key={name} name={name} label={label} index={i} />
        ))}
      </div>
    </div>
  );
}
