import React, { useRef, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Upload, Trash2, Image as ImageIcon, Copy, Loader2 } from 'lucide-react';
import api from '../api';

export default function MediaLibrary() {
  const qc = useQueryClient();
  const fileRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  const [deleting, setDeleting] = useState(null);

  const { data: media = [], isLoading } = useQuery({
    queryKey: ['admin-media'],
    queryFn: () => api.get('/admin/media').then((r) => r.data),
  });

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const formData = new FormData();
    formData.append('file', file);
    setUploading(true);
    try {
      await api.post('/admin/media/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } });
      qc.invalidateQueries({ queryKey: ['admin-media'] });
      toast.success('File uploaded');
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Upload failed');
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this file?')) return;
    setDeleting(id);
    try {
      await api.delete(`/admin/media/${id}`);
      qc.invalidateQueries({ queryKey: ['admin-media'] });
      toast.success('File deleted');
    } catch {
      toast.error('Could not delete file');
    } finally {
      setDeleting(null);
    }
  };

  const copyUrl = (url) => {
    navigator.clipboard.writeText(url);
    toast.success('URL copied to clipboard');
  };

  return (
    <div className="space-y-6" data-testid="media-library">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#1F2D45]">Media Library</h1>
          <p className="text-slate-500 text-sm mt-1">{media.length} file{media.length !== 1 ? 's' : ''} — PNG, JPG, WebP, SVG (max 10 MB)</p>
        </div>
        <div>
          <input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" onChange={handleUpload} className="hidden" id="media-upload" data-testid="media-upload-input" />
          <label
            htmlFor="media-upload"
            data-testid="media-upload-btn"
            className={`flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#1F2D45] text-white text-sm font-semibold cursor-pointer hover:bg-[#2a3d5e] transition-colors ${uploading ? 'opacity-60 pointer-events-none' : ''}`}
          >
            {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
            {uploading ? 'Uploading…' : 'Upload File'}
          </label>
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-20"><Loader2 className="w-6 h-6 animate-spin text-slate-400" /></div>
      ) : media.length === 0 ? (
        <div className="bg-white rounded-xl border-2 border-dashed border-slate-200 py-20 text-center">
          <ImageIcon className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <p className="text-slate-400 text-sm">No files uploaded yet.</p>
          <label htmlFor="media-upload" className="mt-3 inline-block text-sm text-[#C9962E] cursor-pointer hover:underline">Upload your first file</label>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {media.map((item) => (
            <div key={item.id} className="group relative bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden" data-testid={`media-item-${item.id}`}>
              <div className="aspect-square bg-slate-100">
                <img src={item.url} alt={item.original_name} className="w-full h-full object-cover" onError={(e) => { e.target.style.display = 'none'; e.target.nextSibling.style.display = 'flex'; }} />
                <div className="w-full h-full hidden items-center justify-center">
                  <ImageIcon className="w-8 h-8 text-slate-300" />
                </div>
              </div>
              <div className="p-2.5">
                <p className="text-xs text-slate-600 font-medium truncate">{item.original_name}</p>
                <p className="text-xs text-slate-400">{(item.size / 1024).toFixed(0)} KB</p>
              </div>
              {/* Actions overlay */}
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                <button onClick={() => copyUrl(item.url)} data-testid={`copy-url-${item.id}`} title="Copy URL" className="p-2 bg-white rounded-lg text-slate-700 hover:bg-slate-100 transition-colors">
                  <Copy className="w-4 h-4" />
                </button>
                <button onClick={() => handleDelete(item.id)} disabled={deleting === item.id} data-testid={`delete-media-${item.id}`} title="Delete" className="p-2 bg-white rounded-lg text-red-500 hover:bg-red-50 transition-colors disabled:opacity-50">
                  {deleting === item.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
