import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('mgs_admin_token');
    if (!token) { setLoading(false); return; }
    // GET /api/v1/auth/me — verify token is still valid
    api.get('/auth/me')
      .then((res) => setUser(res.data?.data ?? res.data ?? null))
      .catch(() => localStorage.removeItem('mgs_admin_token'))
      .finally(() => setLoading(false));
  }, []);

  const login = async (email, password) => {
    // POST /api/v1/auth/login → { success: true, data: { token, user } }
    const { data } = await api.post('/auth/login', { email, password });
    const token = data?.data?.token ?? data?.token;
    const userData = data?.data?.user ?? data?.user;
    localStorage.setItem('mgs_admin_token', token);
    setUser(userData);
    return userData;
  };

  const logout = () => {
    localStorage.removeItem('mgs_admin_token');
    api.post('/auth/logout').catch(() => {});
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{
      user,
      loading,
      login,
      logout,
      // New backend uses SUPER_ADMIN (uppercase) — support both for safety
      isSuperAdmin: user?.role === 'SUPER_ADMIN' || user?.role === 'super_admin',
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
