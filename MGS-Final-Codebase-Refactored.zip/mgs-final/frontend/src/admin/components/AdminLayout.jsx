import React from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  LayoutDashboard, Mail, Layers, Database, Image, Settings,
  Users, LogOut, ChevronRight, Briefcase
} from 'lucide-react';

const NAV = [
  { icon: LayoutDashboard, label: 'Dashboard', to: '/admin' },
  { icon: Mail, label: 'Contact Inbox', to: '/admin/contacts', superAdminOnly: true },
  { icon: Briefcase, label: 'Applications', to: '/admin/applications', superAdminOnly: true },
  { icon: Layers, label: 'Sections', to: '/admin/sections' },
  { icon: Database, label: 'Collections', to: '/admin/collections' },
  { icon: Image, label: 'Media', to: '/admin/media' },
  { icon: Settings, label: 'Site Settings', to: '/admin/settings', superAdminOnly: true },
  { icon: Users, label: 'Users', to: '/admin/users', superAdminOnly: true },
];

export default function AdminLayout() {
  const { user, logout, isSuperAdmin } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => { logout(); navigate('/admin/login'); };

  const roleLabel = user?.role === 'super_admin' ? 'Super Admin' : 'Editor';

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50 font-sans">
      {/* Sidebar */}
      <aside className="w-60 shrink-0 flex flex-col bg-[#1F2D45] h-full overflow-y-auto">
        {/* Brand */}
        <div className="px-5 py-5 border-b border-white/10">
          <div className="flex items-center gap-3">
            <img
              src="/mgs-logo.png"
              alt="Max Global Software"
              data-testid="admin-sidebar-logo"
              className="h-10 w-auto object-contain bg-white/95 rounded-md px-1.5 py-0.5"
            />
            <div className="leading-tight">
              <div className="text-white font-bold text-sm tracking-wide">MGS</div>
              <div className="text-white/55 text-[10px] font-semibold uppercase tracking-wider">CMS</div>
            </div>
          </div>
          <p className="text-slate-400 text-xs mt-2 truncate">{user?.email}</p>
        </div>

        {/* Nav */}
        <nav className="flex-1 py-4 px-3 space-y-0.5">
          {NAV.filter((n) => !n.superAdminOnly || isSuperAdmin).map(({ icon: Icon, label, to }) => (
            <NavLink
              key={to}
              to={to}
              end={to === '/admin'}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-[#C9962E]/20 text-[#C9962E]'
                    : 'text-slate-300 hover:bg-white/5 hover:text-white'
                }`
              }
            >
              <Icon className="w-4 h-4 shrink-0" />
              {label}
            </NavLink>
          ))}
        </nav>

        {/* Logout */}
        <div className="p-3 border-t border-white/10">
          <button
            onClick={handleLogout}
            data-testid="admin-logout-btn"
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-slate-300 hover:bg-white/5 hover:text-white transition-colors"
          >
            <LogOut className="w-4 h-4 shrink-0" />
            Log out
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-y-auto">
        {/* Top bar */}
        <header className="sticky top-0 z-10 bg-white border-b border-slate-200 px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-1 text-slate-400 text-sm">
            <span>Admin</span>
            <ChevronRight className="w-4 h-4" />
            <span className="text-slate-700 font-medium capitalize">
              {window.location.pathname.split('/admin/')[1]?.split('/')[0] || 'Dashboard'}
            </span>
          </div>
          <span data-testid="admin-role-badge" className="text-xs bg-slate-100 text-slate-600 px-2.5 py-1 rounded-full font-medium">
            {roleLabel}
          </span>
        </header>
        <div className="p-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
