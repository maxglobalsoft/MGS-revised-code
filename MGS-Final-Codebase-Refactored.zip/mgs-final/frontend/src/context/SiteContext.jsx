import React, { createContext, useContext, useEffect, useState } from 'react';
import api from '@/lib/api';

const SiteContext = createContext(null);

/**
 * Fetches GET /api/site once on mount and supplies the site-wide settings
 * (logo, contact info, socials, nav links, footer columns, copyright)
 * to consumers like Navbar and Footer.
 *
 * Consumers should always treat `data` as nullable and provide their own
 * hardcoded fallback values so the marketing site keeps rendering when
 * the CMS is unreachable.
 */
export function SiteProvider({ children }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    api
      .get('/site')
      .then((res) => {
        if (cancelled) return;
        setData(res.data || null);
      })
      .catch(() => {
        if (cancelled) return;
        setData(null);
      })
      .finally(() => {
        if (cancelled) return;
        setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return <SiteContext.Provider value={{ data, loading }}>{children}</SiteContext.Provider>;
}

export function useSite() {
  return useContext(SiteContext) || { data: null, loading: false };
}
