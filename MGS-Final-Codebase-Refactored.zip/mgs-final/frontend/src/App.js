import "@/App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { LazyMotion, domAnimation } from "framer-motion";
import { Toaster } from "sonner";

import Layout from "@/components/layout/Layout";
import AdminApp from "@/admin/AdminApp";
import { SiteProvider } from "@/context/SiteContext";

import Home from "@/pages/Home";
import Services from "@/pages/Services";
import IndustriesPage from "@/pages/Industries";
import CaseStudies from "@/pages/CaseStudies";
import CaseStudyDetail from "@/pages/CaseStudyDetail";
import Portfolio from "@/pages/Portfolio";
import PortfolioDetail from "@/pages/PortfolioDetail";
import WhyMgs from "@/pages/WhyMgs";
import OurTeam from "@/pages/OurTeam";
import Reviews from "@/pages/Reviews";
import Career from "@/pages/Career";
import Contact from "@/pages/Contact";
import StaticPage from "@/pages/StaticPage";
import NotFound from "@/pages/NotFound";

function App() {
  return (
    <div className="App">
      <Toaster position="top-right" richColors />
      <LazyMotion features={domAnimation} strict={false}>
        <BrowserRouter>
          <Routes>
            {/* Admin CMS — no marketing layout */}
            <Route path="/admin/*" element={<AdminApp />} />

            {/* Marketing site — ScrollProgress + meta updates live in Layout */}
            <Route
              element={
                <SiteProvider>
                  <Layout />
                </SiteProvider>
              }
            >
              <Route path="/" element={<Home />} />
              <Route path="/services" element={<Services />} />
              <Route path="/industries" element={<IndustriesPage />} />
              <Route path="/case-studies" element={<CaseStudies />} />
              <Route path="/case-studies/:slug" element={<CaseStudyDetail />} />
              <Route path="/portfolio" element={<Portfolio />} />
              <Route path="/portfolio/:slug" element={<PortfolioDetail />} />
              <Route path="/why-mgs" element={<WhyMgs />} />
              <Route path="/our-team" element={<OurTeam />} />
              <Route path="/reviews" element={<Reviews />} />
              <Route path="/career" element={<Career />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/p/:slug" element={<StaticPage />} />
              <Route path="*" element={<NotFound />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </LazyMotion>
    </div>
  );
}

export default App;
