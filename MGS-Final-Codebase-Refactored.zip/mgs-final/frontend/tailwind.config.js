/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: ["./src/**/*.{js,jsx,ts,tsx}", "./public/index.html"],
  theme: {
    container: {
      center: true,
      padding: "1.25rem",
      screens: { "2xl": "1280px" },
    },
    extend: {
      fontFamily: {
        sans: ['Poppins', 'system-ui', 'sans-serif'],
        display: ['Poppins', 'system-ui', 'sans-serif'],
      },
      colors: {
        // MGS brand tokens
        navy: {
          DEFAULT: '#374965',
          deep: '#1F2D45',
        },
        brandblue: {
          DEFAULT: '#2F6FB0',
          steel: '#537EA8',
        },
        teal: {
          DEFAULT: '#2BA8E0',
        },
        sky: {
          50: '#FAFCFF',
          100: '#F2F8FE',
          200: '#E7F2FF',
        },
        slatebody: '#5A6B82',
        mute: '#939190',
        hairline: '#DAE2E9',
        hairline2: '#B7CCE0',
        // shadcn aliases
        background: 'hsl(var(--background))',
        foreground: 'hsl(var(--foreground))',
        card: {
          DEFAULT: 'hsl(var(--card))',
          foreground: 'hsl(var(--card-foreground))',
        },
        popover: {
          DEFAULT: 'hsl(var(--popover))',
          foreground: 'hsl(var(--popover-foreground))',
        },
        primary: {
          DEFAULT: 'hsl(var(--primary))',
          foreground: 'hsl(var(--primary-foreground))',
        },
        secondary: {
          DEFAULT: 'hsl(var(--secondary))',
          foreground: 'hsl(var(--secondary-foreground))',
        },
        muted: {
          DEFAULT: 'hsl(var(--muted))',
          foreground: 'hsl(var(--muted-foreground))',
        },
        accent: {
          DEFAULT: 'hsl(var(--accent))',
          foreground: 'hsl(var(--accent-foreground))',
        },
        destructive: {
          DEFAULT: 'hsl(var(--destructive))',
          foreground: 'hsl(var(--destructive-foreground))',
        },
        border: 'hsl(var(--border))',
        input: 'hsl(var(--input))',
        ring: 'hsl(var(--ring))',
      },
      borderRadius: {
        lg: 'var(--radius)',
        md: 'calc(var(--radius) - 2px)',
        sm: 'calc(var(--radius) - 4px)',
      },
      backgroundImage: {
        'gold-gradient': 'linear-gradient(95deg, #E8C25A 0%, #C9962E 45%, #8A6A2B 100%)',
        'gold-sheen': 'linear-gradient(110deg, transparent 25%, rgba(255,255,255,0.55) 50%, transparent 75%)',
        'hero-mesh': 'radial-gradient(80% 60% at 15% 20%, rgba(43,168,224,0.18) 0%, transparent 60%), radial-gradient(60% 50% at 95% 30%, rgba(47,111,176,0.16) 0%, transparent 65%), radial-gradient(50% 50% at 50% 100%, rgba(232,194,90,0.10) 0%, transparent 70%)',
      },
      keyframes: {
        'accordion-down': { from: { height: '0' }, to: { height: 'var(--radix-accordion-content-height)' } },
        'accordion-up': { from: { height: 'var(--radix-accordion-content-height)' }, to: { height: '0' } },
        'marquee': { from: { transform: 'translateX(0)' }, to: { transform: 'translateX(-50%)' } },
        'sheen': { '0%': { transform: 'translateX(-120%)' }, '100%': { transform: 'translateX(120%)' } },
        'float-y': { '0%,100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(-10px)' } },
        'drift': { '0%,100%': { transform: 'translate(0,0)' }, '50%': { transform: 'translate(6px,-8px)' } },
        'mesh-pan': { '0%,100%': { backgroundPosition: '0% 50%' }, '50%': { backgroundPosition: '100% 50%' } },
      },
      animation: {
        'accordion-down': 'accordion-down 0.2s ease-out',
        'accordion-up': 'accordion-up 0.2s ease-out',
        'marquee-slow': 'marquee 40s linear infinite',
        'marquee-med': 'marquee 28s linear infinite',
        'float-slow': 'float-y 6s ease-in-out infinite',
        'drift-slow': 'drift 7s ease-in-out infinite',
        'mesh-pan': 'mesh-pan 14s ease-in-out infinite',
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};
